# Moments Feature

<cite>
**Referenced Files in This Document**
- [MomentsScreen.kt](file://feature/feature-moments/src/main/java/com/uit20years/feature/moments/MomentsScreen.kt)
- [MomentsNavigation.kt](file://feature/feature-moments/src/main/java/com/uit20years/feature/moments/navigation/MomentsNavigation.kt)
- [AppNavHost.kt](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt)
- [Route.kt](file://app/src/main/java/com/uit20years/app/navigation/Route.kt)
- [PostRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/PostRepository.kt)
- [PostRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/PostRepositoryImpl.kt)
- [Post.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Post.kt)
- [User.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt)
- [Reaction.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Reaction.kt)
- [UitButton.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitButton.kt)
- [UitTopBar.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTopBar.kt)
- [Theme.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Theme.kt)
- [AuthNavigation.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/navigation/AuthNavigation.kt)
- [IMPLEMENTATION_COMPLETE.md](file://IMPLEMENTATION_COMPLETE.md)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document describes the Moments feature module that implements the social feed functionality in the UIT20Years application. Currently, the feature exists as a placeholder with a "Coming Soon" screen and basic navigation scaffolding. The documentation outlines how the feature will integrate with the core social feed infrastructure, including data fetching patterns, pagination, and UI components. It also provides guidance for extending the feature with real-time updates, post interactions, and additional social features following the established architectural patterns.

## Project Structure
The Moments feature is organized as a feature module with a dedicated screen and navigation graph. The app module wires navigation and integrates authentication flows. Core modules provide the domain, data, models, and UI foundation used by features.

```mermaid
graph TB
subgraph "App Module"
APP_NAV["AppNavHost.kt"]
ROUTE["Route.kt"]
end
subgraph "Feature: Moments"
MOM_SCREEN["MomentsScreen.kt"]
MOM_NAV["MomentsNavigation.kt"]
end
subgraph "Core: Domain"
POST_REPO_IF["PostRepository.kt"]
end
subgraph "Core: Data"
POST_REPO_IMPL["PostRepositoryImpl.kt"]
end
subgraph "Core: Model"
MODEL_POST["Post.kt"]
MODEL_USER["User.kt"]
MODEL_REACTION["Reaction.kt"]
end
subgraph "Core: UI"
UI_BUTTON["UitButton.kt"]
UI_TOPBAR["UitTopBar.kt"]
THEME["Theme.kt"]
end
APP_NAV --> MOM_NAV
MOM_NAV --> MOM_SCREEN
MOM_SCREEN --> UI_BUTTON
MOM_SCREEN --> UI_TOPBAR
MOM_SCREEN --> THEME
POST_REPO_IF --> POST_REPO_IMPL
POST_REPO_IMPL --> MODEL_POST
POST_REPO_IMPL --> MODEL_USER
POST_REPO_IMPL --> MODEL_REACTION
```

**Diagram sources**
- [AppNavHost.kt:1-26](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L1-L26)
- [Route.kt:1-13](file://app/src/main/java/com/uit20years/app/navigation/Route.kt#L1-L13)
- [MomentsScreen.kt:1-27](file://feature/feature-moments/src/main/java/com/uit20years/feature/moments/MomentsScreen.kt#L1-L27)
- [MomentsNavigation.kt:1-25](file://feature/feature-moments/src/main/java/com/uit20years/feature/moments/navigation/MomentsNavigation.kt#L1-L25)
- [PostRepository.kt:1-18](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/PostRepository.kt#L1-L18)
- [PostRepositoryImpl.kt:1-48](file://core/core-data/src/main/java/com/uit20years/core/data/repository/PostRepositoryImpl.kt#L1-L48)
- [Post.kt:1-23](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Post.kt#L1-L23)
- [User.kt:1-23](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt#L1-L23)
- [Reaction.kt:1-14](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Reaction.kt#L1-L14)
- [UitButton.kt:1-42](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitButton.kt#L1-L42)
- [UitTopBar.kt:1-43](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTopBar.kt#L1-L43)
- [Theme.kt:1-83](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Theme.kt#L1-L83)

**Section sources**
- [IMPLEMENTATION_COMPLETE.md:53-71](file://IMPLEMENTATION_COMPLETE.md#L53-L71)
- [IMPLEMENTATION_COMPLETE.md:119-122](file://IMPLEMENTATION_COMPLETE.md#L119-L122)

## Core Components
- MomentsScreen: Placeholder screen displaying a "Coming Soon" message centered in the UI.
- MomentsNavigation: Defines the type-safe route and navigation graph for the Moments feature.
- AppNavHost: Hosts navigation and currently wires the authentication graph; future home graph will be integrated here.
- PostRepository and PostRepositoryImpl: Define the social feed contract and provide a stubbed implementation for global and personal feeds, likes, comments, and post creation/deletion.
- Core models: Post, User, and Reaction define the data structures used by the feed and interactions.
- Core UI components: UitButton and UitTopBar provide reusable UI elements that can be adapted for feed interactions.

**Section sources**
- [MomentsScreen.kt:13-26](file://feature/feature-moments/src/main/java/com/uit20years/feature/moments/MomentsScreen.kt#L13-L26)
- [MomentsNavigation.kt:10-25](file://feature/feature-moments/src/main/java/com/uit20years/feature/moments/navigation/MomentsNavigation.kt#L10-L25)
- [AppNavHost.kt:10-25](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L10-L25)
- [PostRepository.kt:8-17](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/PostRepository.kt#L8-L17)
- [PostRepositoryImpl.kt:12-47](file://core/core-data/src/main/java/com/uit20years/core/data/repository/PostRepositoryImpl.kt#L12-L47)
- [Post.kt:3-17](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Post.kt#L3-L17)
- [User.kt:3-15](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt#L3-L15)
- [Reaction.kt:3-13](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Reaction.kt#L3-L13)
- [UitButton.kt:14-41](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitButton.kt#L14-L41)
- [UitTopBar.kt:17-42](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTopBar.kt#L17-L42)

## Architecture Overview
The Moments feature follows the established unidirectional data flow and modular architecture. The app module hosts navigation and integrates authentication. Features consume domain repositories via Hilt DI and present UI using core components. The social feed will rely on PostRepository for data operations and UitResult for error handling.

```mermaid
sequenceDiagram
participant User as "User"
participant AppNav as "AppNavHost"
participant NavGraph as "MomentsNavigation"
participant Screen as "MomentsScreen"
participant Repo as "PostRepositoryImpl"
User->>AppNav : Open app
AppNav->>NavGraph : Navigate to MomentsRoute
NavGraph->>Screen : Compose MomentsScreen
Screen->>Repo : getGlobalFeed(pageSize, lastPostId)
Repo-->>Screen : Flow<UitResult<List<Post>>
Screen-->>User : Render feed UI or placeholder
```

**Diagram sources**
- [AppNavHost.kt:10-25](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L10-L25)
- [MomentsNavigation.kt:13-21](file://feature/feature-moments/src/main/java/com/uit20years/feature/moments/navigation/MomentsNavigation.kt#L13-L21)
- [MomentsScreen.kt:13-26](file://feature/feature-moments/src/main/java/com/uit20years/feature/moments/MomentsScreen.kt#L13-L26)
- [PostRepositoryImpl.kt:14-18](file://core/core-data/src/main/java/com/uit20years/core/data/repository/PostRepositoryImpl.kt#L14-L18)

## Detailed Component Analysis

### MomentsScreen
- Purpose: Placeholder screen for the Moments feature.
- UI: Centers a "Coming Soon" message using a Box and Text.
- Extensibility: Can be extended to render a feed list, handle user interactions, and integrate with PostRepository.

```mermaid
flowchart TD
Start(["Compose MomentsScreen"]) --> Layout["Centered Box Layout"]
Layout --> Text["Display 'Moments\\nComing Soon'"]
Text --> End(["Render"])
```

**Diagram sources**
- [MomentsScreen.kt:13-26](file://feature/feature-moments/src/main/java/com/uit20years/feature/moments/MomentsScreen.kt#L13-L26)

**Section sources**
- [MomentsScreen.kt:13-26](file://feature/feature-moments/src/main/java/com/uit20years/feature/moments/MomentsScreen.kt#L13-L26)

### Navigation Structure and Route Definitions
- Route definition: MomentsRoute and MomentsScreen are serializable data objects enabling type-safe navigation.
- Graph construction: momentsGraph defines a nested navigation graph with a single composable screen.
- Integration: AppNavHost currently wires authentication; home graph will be added later to host the main app shell.

```mermaid
classDiagram
class MomentsRoute {
+serializable
}
class MomentsScreen {
+serializable
}
class NavGraphBuilder {
+momentsGraph(navController)
}
class AppNavHost {
+rememberNavController()
+NavHost(startDestination)
}
NavGraphBuilder --> MomentsScreen : "composable"
AppNavHost --> NavGraphBuilder : "authGraph()"
AppNavHost --> NavGraphBuilder : "TODO : homeGraph()"
```

**Diagram sources**
- [MomentsNavigation.kt:10-25](file://feature/feature-moments/src/main/java/com/uit20years/feature/moments/navigation/MomentsNavigation.kt#L10-L25)
- [AppNavHost.kt:10-25](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L10-L25)

**Section sources**
- [MomentsNavigation.kt:10-25](file://feature/feature-moments/src/main/java/com/uit20years/feature/moments/navigation/MomentsNavigation.kt#L10-L25)
- [AppNavHost.kt:10-25](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L10-L25)
- [Route.kt:5-12](file://app/src/main/java/com/uit20years/app/navigation/Route.kt#L5-L12)

### Integration with Core Social Feed Functionality
- Data contract: PostRepository defines methods for global/personal feeds, post retrieval, creation/deletion, likes, comments, and comment addition.
- Current implementation: PostRepositoryImpl provides stubbed flows emitting Loading and Success states with empty data.
- Future implementation: Replace stubs with Firestore-backed flows using callbackFlow and repository patterns.

```mermaid
classDiagram
class PostRepository {
+getGlobalFeed(pageSize, lastPostId)
+getPersonalFeed(uid)
+getPostById(postId)
+createPost(post, mediaBytes)
+deletePost(postId)
+toggleLike(postId, userId)
+getComments(postId)
+addComment(postId, comment)
}
class PostRepositoryImpl {
+getPosts(limit)
+createPost(authorId, content, mediaUrls)
+likePost(postId, userId)
+unlikePost(postId, userId)
+deletePost(postId, authorId)
}
PostRepository <|.. PostRepositoryImpl : "implements"
```

**Diagram sources**
- [PostRepository.kt:8-17](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/PostRepository.kt#L8-L17)
- [PostRepositoryImpl.kt:12-47](file://core/core-data/src/main/java/com/uit20years/core/data/repository/PostRepositoryImpl.kt#L12-L47)

**Section sources**
- [PostRepository.kt:8-17](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/PostRepository.kt#L8-L17)
- [PostRepositoryImpl.kt:12-47](file://core/core-data/src/main/java/com/uit20years/core/data/repository/PostRepositoryImpl.kt#L12-L47)

### UI Components for Posts, Avatars, Reactions, and Comments
- Post model: Includes author metadata, content, media URLs, counts, visibility, timestamps, and like state.
- Reaction model: Supports reaction types (LIKE, LOVE, CELEBRATE) with user ID and timestamp.
- User model: Provides user identity and profile attributes.
- UI components: UitButton supports loading states and icons; UitTopBar offers a branded top app bar.

```mermaid
classDiagram
class Post {
+id : String
+authorId : String
+authorName : String
+authorAvatarUrl : String?
+content : String
+mediaUrls : List<String>
+hashtags : List<String>
+likeCount : Int
+commentCount : Int
+isLikedByCurrentUser : Boolean
+visibility : PostVisibility
+createdAt : Long
+updatedAt : Long
}
class Reaction {
+userId : String
+type : ReactionType
+createdAt : Long
}
class User {
+uid : String
+email : String
+displayName : String
+avatarUrl : String?
+bio : String?
+faculty : String?
+graduationYear : Int?
+role : UserRole
+followerCount : Int
+followingCount : Int
+createdAt : Long
}
class UitButton {
+text : String
+onClick()
+enabled : Boolean
+isLoading : Boolean
}
class UitTopBar {
+title : String
+onBackClick()
+actions()
}
```

**Diagram sources**
- [Post.kt:3-17](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Post.kt#L3-L17)
- [Reaction.kt:3-13](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Reaction.kt#L3-L13)
- [User.kt:3-15](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt#L3-L15)
- [UitButton.kt:14-41](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitButton.kt#L14-L41)
- [UitTopBar.kt:17-42](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTopBar.kt#L17-L42)

**Section sources**
- [Post.kt:3-17](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Post.kt#L3-L17)
- [Reaction.kt:3-13](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Reaction.kt#L3-L13)
- [User.kt:3-15](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt#L3-L15)
- [UitButton.kt:14-41](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitButton.kt#L14-L41)
- [UitTopBar.kt:17-42](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTopBar.kt#L17-L42)

### Data Fetching Patterns, Pagination, and Real-Time Updates
- Current pattern: PostRepositoryImpl emits Loading then Success with empty lists for feed queries.
- Recommended approach:
  - Use callbackFlow to expose real-time Firestore streams as Flow<UitResult<T>>.
  - Implement pagination by tracking last document snapshots and using limit/pageSize parameters.
  - Support offline-first caching and refresh triggers.
- Error handling: Wrap results in UitResult to propagate Loading/Success/Error states to the UI.

```mermaid
flowchart TD
Start(["Call getGlobalFeed"]) --> EmitLoading["Emit Loading"]
EmitLoading --> QueryFirestore["Query Firestore with pageSize and lastDoc"]
QueryFirestore --> QuerySuccess{"Query Success?"}
QuerySuccess --> |Yes| EmitSuccess["Emit Success(list)"]
QuerySuccess --> |No| EmitError["Emit Error(message)"]
EmitSuccess --> End(["UI renders feed"])
EmitError --> End
```

**Diagram sources**
- [PostRepositoryImpl.kt:14-18](file://core/core-data/src/main/java/com/uit20years/core/data/repository/PostRepositoryImpl.kt#L14-L18)

**Section sources**
- [PostRepositoryImpl.kt:14-18](file://core/core-data/src/main/java/com/uit20years/core/data/repository/PostRepositoryImpl.kt#L14-L18)
- [PostRepository.kt:9-16](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/PostRepository.kt#L9-L16)

### Customization Guidance and Extending the Feature
- Feed layout customization:
  - Replace the placeholder screen with a LazyColumn or LazyGrid of PostCard items.
  - Use UitTopBar for navigation and actions.
- Adding new post types:
  - Extend PostVisibility or introduce a PostContentType enum in Post.kt.
  - Update mappers and repository methods to support new content variants.
- Additional social interactions:
  - Implement toggleLike via PostRepository.toggleLike and update UI state.
  - Add comment composition using getComments and addComment.
- Following established patterns:
  - Use UitButton for actions and LoadingIndicator for async operations.
  - Apply UIT20YearsTheme for consistent theming.

[No sources needed since this section provides general guidance]

## Dependency Analysis
The Moments feature depends on core models and UI components. The app module orchestrates navigation and integrates authentication. The feature will depend on PostRepository for data operations.

```mermaid
graph LR
MOM_SCREEN["MomentsScreen.kt"] --> UI_BUTTON["UitButton.kt"]
MOM_SCREEN --> UI_TOPBAR["UitTopBar.kt"]
MOM_SCREEN --> THEME["Theme.kt"]
APP_NAV["AppNavHost.kt"] --> MOM_NAV["MomentsNavigation.kt"]
MOM_NAV --> MOM_SCREEN
POST_REPO_IF["PostRepository.kt"] --> POST_REPO_IMPL["PostRepositoryImpl.kt"]
POST_REPO_IMPL --> MODEL_POST["Post.kt"]
POST_REPO_IMPL --> MODEL_USER["User.kt"]
POST_REPO_IMPL --> MODEL_REACTION["Reaction.kt"]
```

**Diagram sources**
- [MomentsScreen.kt:13-26](file://feature/feature-moments/src/main/java/com/uit20years/feature/moments/MomentsScreen.kt#L13-L26)
- [UitButton.kt:14-41](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitButton.kt#L14-L41)
- [UitTopBar.kt:17-42](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTopBar.kt#L17-L42)
- [Theme.kt:58-82](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Theme.kt#L58-L82)
- [AppNavHost.kt:10-25](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L10-L25)
- [MomentsNavigation.kt:13-21](file://feature/feature-moments/src/main/java/com/uit20years/feature/moments/navigation/MomentsNavigation.kt#L13-L21)
- [PostRepository.kt:8-17](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/PostRepository.kt#L8-L17)
- [PostRepositoryImpl.kt:12-47](file://core/core-data/src/main/java/com/uit20years/core/data/repository/PostRepositoryImpl.kt#L12-L47)
- [Post.kt:3-17](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Post.kt#L3-L17)
- [User.kt:3-15](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt#L3-L15)
- [Reaction.kt:3-13](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Reaction.kt#L3-L13)

**Section sources**
- [IMPLEMENTATION_COMPLETE.md:74-85](file://IMPLEMENTATION_COMPLETE.md#L74-L85)

## Performance Considerations
- Pagination: Use Firestore cursors and limit parameters to avoid loading excessive data.
- Caching: Store recent feed pages locally to reduce network requests.
- Composition: Prefer lazy lists for large feeds to minimize recompositions.
- Loading states: Use Loading indicators sparingly and ensure UI remains responsive during fetches.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
- Navigation issues:
  - Verify type-safe routes are properly serialized and referenced in AppNavHost.
  - Ensure momentsGraph is wired after authentication completes.
- Data loading:
  - Confirm PostRepositoryImpl emits Loading before Success/Error.
  - Check that UitResult states are handled in the UI to prevent blank screens.
- UI rendering:
  - Validate that UitTopBar and UitButton are themed correctly via UIT20YearsTheme.

**Section sources**
- [AppNavHost.kt:10-25](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L10-L25)
- [PostRepositoryImpl.kt:14-18](file://core/core-data/src/main/java/com/uit20years/core/data/repository/PostRepositoryImpl.kt#L14-L18)
- [Theme.kt:58-82](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Theme.kt#L58-L82)

## Conclusion
The Moments feature is currently a placeholder with navigation scaffolding. By integrating PostRepository, adopting the UDF pattern, and leveraging core UI components, the feature can evolve into a robust social feed supporting pagination, real-time updates, and rich interactions. The established architecture and patterns provide a clear path to implementation while maintaining consistency across the application.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices
- Authentication integration reference: AuthNavigation demonstrates type-safe routing and navigation transitions that can be mirrored in the home graph and Moments feature.
- Implementation roadmap: The project outline identifies replacing stub repositories and adding the home screen, aligning with the next steps for the Moments feature.

**Section sources**
- [AuthNavigation.kt:20-48](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/navigation/AuthNavigation.kt#L20-L48)
- [IMPLEMENTATION_COMPLETE.md:132-148](file://IMPLEMENTATION_COMPLETE.md#L132-L148)
# Authentication Feature

<cite>
**Referenced Files in This Document**
- [LoginScreen.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginScreen.kt)
- [LoginViewModel.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt)
- [LoginUiState.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginUiState.kt)
- [LoginEvent.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginEvent.kt)
- [RegisterScreen.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterScreen.kt)
- [RegisterViewModel.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt)
- [RegisterUiState.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterUiState.kt)
- [RegisterEvent.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterEvent.kt)
- [AuthNavigation.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/navigation/AuthNavigation.kt)
- [LoginUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt)
- [RegisterUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt)
- [LogoutUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LogoutUseCase.kt)
- [ObserveAuthStateUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/ObserveAuthStateUseCase.kt)
- [AuthRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt)
- [AuthRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt)
- [FirebaseAuthService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document describes the authentication feature module for the UIT20Years application. It covers the complete authentication flow for login, registration, and navigation between authentication screens. The implementation follows the Unidirectional Data Flow (UDF) pattern, using Compose UI, ViewModel state management, sealed events, and domain-driven use cases backed by Firebase Authentication and Firestore. The documentation explains form validation, error handling, loading states, success navigation, and integration with the core authentication repository. Guidance is also provided for extending the authentication feature and adding new authentication-related screens.

## Project Structure
The authentication feature is organized into two primary screens (Login and Register), each with its own ViewModel, UiState, and events. Navigation is centralized under the authentication graph, and the domain layer encapsulates business logic via use cases. The data layer integrates Firebase services for authentication and Firestore for user profiles.

```mermaid
graph TB
subgraph "feature-auth"
A["login/LoginScreen.kt"]
B["login/LoginViewModel.kt"]
C["login/LoginUiState.kt"]
D["login/LoginEvent.kt"]
E["register/RegisterScreen.kt"]
F["register/RegisterViewModel.kt"]
G["register/RegisterUiState.kt"]
H["register/RegisterEvent.kt"]
I["navigation/AuthNavigation.kt"]
end
subgraph "core-domain"
J["usecase/auth/LoginUseCase.kt"]
K["usecase/auth/RegisterUseCase.kt"]
L["usecase/auth/LogoutUseCase.kt"]
M["usecase/auth/ObserveAuthStateUseCase.kt"]
N["repository/AuthRepository.kt"]
end
subgraph "core-data"
O["repository/AuthRepositoryImpl.kt"]
end
subgraph "core-firebase"
P["auth/FirebaseAuthService.kt"]
end
A --> B
E --> F
B --> J
F --> K
J --> N
K --> N
N --> O
O --> P
I --> A
I --> E
```

**Diagram sources**
- [LoginScreen.kt:30-126](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginScreen.kt#L30-L126)
- [LoginViewModel.kt:20-99](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L20-L99)
- [LoginUiState.kt:3-10](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginUiState.kt#L3-L10)
- [LoginEvent.kt:3-8](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginEvent.kt#L3-L8)
- [RegisterScreen.kt:30-144](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterScreen.kt#L30-L144)
- [RegisterViewModel.kt:20-139](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt#L20-L139)
- [RegisterUiState.kt:3-14](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterUiState.kt#L3-L14)
- [RegisterEvent.kt:3-10](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterEvent.kt#L3-L10)
- [AuthNavigation.kt:20-48](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/navigation/AuthNavigation.kt#L20-L48)
- [LoginUseCase.kt:9-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L9-L14)
- [RegisterUseCase.kt:9-17](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt#L9-L17)
- [AuthRepository.kt:7-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L7-L13)
- [AuthRepositoryImpl.kt:23-146](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L23-L146)
- [FirebaseAuthService.kt:13-36](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L13-L36)

**Section sources**
- [AuthNavigation.kt:20-48](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/navigation/AuthNavigation.kt#L20-L48)
- [LoginScreen.kt:30-126](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginScreen.kt#L30-L126)
- [RegisterScreen.kt:30-144](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterScreen.kt#L30-L144)

## Core Components
- LoginScreen: Renders the login UI, collects UiState from LoginViewModel, handles effects for navigation, displays errors via Snackbar, and shows a global loading indicator when appropriate.
- LoginViewModel: Manages UiState and effects, validates input, triggers LoginUseCase, and emits navigation effects upon success.
- LoginUiState: Holds transient UI state including input values, loading flags, and error indicators.
- LoginEvent: Sealed events for user actions and form updates.
- RegisterScreen: Similar to LoginScreen but for registration, validating display name, email, password, and confirmation.
- RegisterViewModel: Manages UiState and effects for registration, validates input, triggers RegisterUseCase, and emits navigation effects upon success.
- RegisterUiState: Holds registration-specific UiState.
- RegisterEvent: Sealed events for registration actions.
- AuthNavigation: Defines the authentication graph with LoginRoute and RegisterRoute, and orchestrates navigation between screens and to the home destination.

**Section sources**
- [LoginScreen.kt:30-126](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginScreen.kt#L30-L126)
- [LoginViewModel.kt:20-99](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L20-L99)
- [LoginUiState.kt:3-10](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginUiState.kt#L3-L10)
- [LoginEvent.kt:3-8](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginEvent.kt#L3-L8)
- [RegisterScreen.kt:30-144](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterScreen.kt#L30-L144)
- [RegisterViewModel.kt:20-139](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt#L20-L139)
- [RegisterUiState.kt:3-14](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterUiState.kt#L3-L14)
- [RegisterEvent.kt:3-10](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterEvent.kt#L3-L10)
- [AuthNavigation.kt:20-48](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/navigation/AuthNavigation.kt#L20-L48)

## Architecture Overview
The authentication feature adheres to UDF:
- UI emits events (LoginEvent/RegisterEvent).
- ViewModel updates UiState and effects.
- Use cases orchestrate repository operations.
- Repository integrates Firebase Authentication and Firestore.
- Effects trigger navigation; UiState drives rendering and loading/error display.

```mermaid
sequenceDiagram
participant UI as "LoginScreen"
participant VM as "LoginViewModel"
participant UC as "LoginUseCase"
participant Repo as "AuthRepositoryImpl"
participant FB as "FirebaseAuthService"
UI->>VM : "onEvent(Submit)"
VM->>VM : "validateAndLogin()"
VM->>UC : "invoke(email, password)"
UC->>Repo : "login(email, password)"
Repo->>FB : "signInWithEmail(...)"
FB-->>Repo : "AuthResult"
Repo-->>UC : "UitResult<User>"
UC-->>VM : "UitResult<User>"
VM->>VM : "update UiState / send effect"
VM-->>UI : "effects : NavigateToHome"
UI->>UI : "navigate('home')"
```

**Diagram sources**
- [LoginScreen.kt:39-47](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginScreen.kt#L39-L47)
- [LoginViewModel.kt:31-94](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L31-L94)
- [LoginUseCase.kt:9-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L9-L14)
- [AuthRepositoryImpl.kt:29-55](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L29-L55)
- [FirebaseAuthService.kt:17-18](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L17-L18)

## Detailed Component Analysis

### Login Feature
- Form fields: email, password.
- Validation: email format check and minimum password length.
- Loading state: set during repository operation.
- Error handling: localized messages mapped from exceptions.
- Success navigation: effect triggers navigation to the home route after successful login.

```mermaid
flowchart TD
Start(["Submit"]) --> Validate["Validate email and password"]
Validate --> HasError{"Has validation error?"}
HasError --> |Yes| ShowError["Set UiState.errorMessage and error flags"]
HasError --> |No| CallUseCase["Call LoginUseCase"]
CallUseCase --> Loading["Emit Loading via UitResult"]
Loading --> Result{"Result"}
Result --> |Success| EmitEffect["Send NavigateToHome effect"]
Result --> |Error| SetError["Set UiState.errorMessage and isLoading=false"]
EmitEffect --> End(["Navigate to Home"])
SetError --> End
```

**Diagram sources**
- [LoginViewModel.kt:48-94](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L48-L94)
- [LoginUseCase.kt:9-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L9-L14)
- [AuthRepositoryImpl.kt:29-55](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L29-L55)

**Section sources**
- [LoginScreen.kt:39-54](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginScreen.kt#L39-L54)
- [LoginViewModel.kt:31-94](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L31-L94)
- [LoginUiState.kt:3-10](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginUiState.kt#L3-L10)
- [LoginEvent.kt:3-8](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginEvent.kt#L3-L8)

### Register Feature
- Form fields: display name, email, password, confirm password.
- Validation: email format, password length, password confirmation match, non-empty display name.
- Loading state: set during repository operation.
- Error handling: localized messages mapped from exceptions.
- Success navigation: effect triggers navigation back to the login screen after successful registration.

```mermaid
flowchart TD
Start(["Submit"]) --> Validate["Validate all fields"]
Validate --> HasError{"Has validation error?"}
HasError --> |Yes| ShowError["Set UiState.errorMessage and error flags"]
HasError --> |No| CallUseCase["Call RegisterUseCase"]
CallUseCase --> Loading["Emit Loading via UitResult"]
Loading --> Result{"Result"}
Result --> |Success| EmitEffect["Send NavigateToLogin effect"]
Result --> |Error| SetError["Set UiState.errorMessage and isLoading=false"]
EmitEffect --> End(["Navigate to Login"])
SetError --> End
```

**Diagram sources**
- [RegisterViewModel.kt:64-134](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt#L64-L134)
- [RegisterUseCase.kt:9-17](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt#L9-L17)
- [AuthRepositoryImpl.kt:61-88](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L61-L88)

**Section sources**
- [RegisterScreen.kt:39-54](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterScreen.kt#L39-L54)
- [RegisterViewModel.kt:31-134](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt#L31-L134)
- [RegisterUiState.kt:3-14](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterUiState.kt#L3-L14)
- [RegisterEvent.kt:3-10](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterEvent.kt#L3-L10)

### Authentication Navigation
- Routes: AuthRoute (graph container), LoginRoute, RegisterRoute.
- Graph: Start destination is LoginRoute; RegisterRoute is reachable from LoginRoute; navigating to home pops the AuthRoute stack.

```mermaid
graph LR
Auth["AuthRoute"] --> Login["LoginRoute"]
Auth --> Register["RegisterRoute"]
Login -- "navigate(RegisterRoute)" --> Register
Login -- "navigate('home')<br/>popUpTo(AuthRoute)" --> Home["Home Destination"]
```

**Diagram sources**
- [AuthNavigation.kt:20-48](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/navigation/AuthNavigation.kt#L20-L48)

**Section sources**
- [AuthNavigation.kt:11-48](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/navigation/AuthNavigation.kt#L11-L48)

### Domain and Data Layer Integration
- Use cases: LoginUseCase, RegisterUseCase, LogoutUseCase, ObserveAuthStateUseCase delegate to AuthRepository.
- AuthRepositoryImpl: Implements login, register, logout, observeAuthState, and getCurrentUser using FirebaseAuthService and FirestoreService.
- FirebaseAuthService: Wraps FirebaseAuth operations and auth state observation.

```mermaid
classDiagram
class LoginUseCase {
+invoke(email, password) Flow~UitResult~User~~
}
class RegisterUseCase {
+invoke(email, password, displayName) Flow~UitResult~User~~
}
class LogoutUseCase {
+invoke() Flow~UitResult~Unit~~
}
class ObserveAuthStateUseCase {
+invoke() Flow~User?~
}
class AuthRepository {
<<interface>>
+login(email, password) Flow~UitResult~User~~
+register(email, password, displayName) Flow~UitResult~User~~
+logout() Flow~UitResult~Unit~~
+observeAuthState() Flow~User?~
+getCurrentUser() suspend User?
}
class AuthRepositoryImpl {
+login(...)
+register(...)
+logout()
+observeAuthState()
+getCurrentUser()
}
class FirebaseAuthService {
+signInWithEmail(...)
+createUser(...)
+signOut()
+getCurrentUser()
+observeAuthState() Flow~FirebaseUser?~
}
LoginUseCase --> AuthRepository
RegisterUseCase --> AuthRepository
LogoutUseCase --> AuthRepository
ObserveAuthStateUseCase --> AuthRepository
AuthRepositoryImpl ..|> AuthRepository
AuthRepositoryImpl --> FirebaseAuthService
```

**Diagram sources**
- [LoginUseCase.kt:9-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L9-L14)
- [RegisterUseCase.kt:9-17](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt#L9-L17)
- [LogoutUseCase.kt:8-12](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LogoutUseCase.kt#L8-L12)
- [ObserveAuthStateUseCase.kt:8-12](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/ObserveAuthStateUseCase.kt#L8-L12)
- [AuthRepository.kt:7-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L7-L13)
- [AuthRepositoryImpl.kt:23-146](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L23-L146)
- [FirebaseAuthService.kt:13-36](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L13-L36)

**Section sources**
- [AuthRepository.kt:7-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L7-L13)
- [AuthRepositoryImpl.kt:23-146](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L23-L146)
- [FirebaseAuthService.kt:13-36](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L13-L36)

## Dependency Analysis
- UI depends on ViewModels via Hilt-provided instances.
- ViewModels depend on UseCases.
- UseCases depend on AuthRepository interface.
- AuthRepositoryImpl depends on FirebaseAuthService and FirestoreService.
- Navigation routes are serializable and orchestrated by NavGraphBuilder.

```mermaid
graph TD
LS["LoginScreen"] --> LVM["LoginViewModel"]
RS["RegisterScreen"] --> RVM["RegisterViewModel"]
LVM --> LU["LoginUseCase"]
RVM --> RU["RegisterUseCase"]
LU --> AR["AuthRepository"]
RU --> AR
AR --> ARI["AuthRepositoryImpl"]
ARI --> FBA["FirebaseAuthService"]
```

**Diagram sources**
- [LoginScreen.kt:34-34](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginScreen.kt#L34-L34)
- [RegisterScreen.kt:34-34](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterScreen.kt#L34-L34)
- [LoginViewModel.kt:21-22](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L21-L22)
- [RegisterViewModel.kt:21-22](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt#L21-L22)
- [LoginUseCase.kt:9-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L9-L14)
- [RegisterUseCase.kt:9-17](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt#L9-L17)
- [AuthRepository.kt:7-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L7-L13)
- [AuthRepositoryImpl.kt:23-27](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L23-L27)
- [FirebaseAuthService.kt:13-16](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L13-L16)

**Section sources**
- [LoginViewModel.kt:21-22](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L21-L22)
- [RegisterViewModel.kt:21-22](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt#L21-L22)
- [AuthRepository.kt:7-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L7-L13)
- [AuthRepositoryImpl.kt:23-27](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L23-L27)

## Performance Considerations
- Prefer collecting UiState with lifecycle-aware collectors to avoid unnecessary recompositions.
- Debounce or coalesce rapid input changes to reduce validation churn.
- Use immutable state updates to minimize UI work.
- Keep loading states minimal and dismiss only when appropriate to avoid flickering.
- Offload heavy operations to background dispatchers via use cases and repositories.

## Troubleshooting Guide
Common issues and resolutions:
- Email format errors: Ensure email validation is applied before invoking use cases.
- Password length errors: Enforce minimum length checks and clear error flags on subsequent edits.
- Password confirmation mismatch: Clear confirmation error flag when either password or confirmation changes.
- Display name empty: Validate non-blank display name and clear error flags on change.
- Network/database errors: Catch Firebase exceptions and map to user-friendly messages; ensure loading state is cleared on error.
- Navigation not triggering: Verify effects are collected in Composables and navigation lambdas are invoked correctly.
- Auth state observation: Confirm Firebase auth state listener is registered and Firestore queries handle missing documents gracefully.

**Section sources**
- [LoginViewModel.kt:48-94](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L48-L94)
- [RegisterViewModel.kt:64-134](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt#L64-L134)
- [AuthRepositoryImpl.kt:48-54](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L48-L54)
- [AuthRepositoryImpl.kt:81-87](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L81-L87)

## Conclusion
The authentication feature implements a clean UDF architecture with clear separation of concerns. UI components focus on rendering and emitting events, ViewModels manage state and effects, use cases encapsulate business logic, and repositories integrate Firebase services. The design supports robust validation, error handling, loading states, and seamless navigation. Extending the feature involves adding new screens with matching ViewModels, UiStates, and events, integrating new use cases, and updating navigation routes accordingly.

## Appendices

### Authentication State Persistence and Session Management
- Auth state observation: ObserveAuthStateUseCase streams current user state derived from Firebase auth and Firestore.
- Current user retrieval: getCurrentUser provides synchronous access to the cached user profile.
- Logout: LogoutUseCase delegates to FirebaseAuthService.signOut and emits success.

**Section sources**
- [ObserveAuthStateUseCase.kt:8-12](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/ObserveAuthStateUseCase.kt#L8-L12)
- [AuthRepositoryImpl.kt:100-114](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L100-L114)
- [LogoutUseCase.kt:8-12](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LogoutUseCase.kt#L8-L12)
- [FirebaseAuthService.kt:23-25](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L23-L25)

### Adding New Authentication Screens
Steps to extend:
- Create a new screen Composable and ViewModel with dedicated UiState and events.
- Implement validation logic mirroring existing patterns.
- Wire up use cases and handle UitResult states.
- Define a new route and add a composable within the authGraph.
- Connect navigation via lambda callbacks to the parent NavHostController.
- Ensure effects are collected and navigation is triggered appropriately.

**Section sources**
- [AuthNavigation.kt:20-48](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/navigation/AuthNavigation.kt#L20-L48)
- [LoginViewModel.kt:31-46](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L31-L46)
- [RegisterViewModel.kt:31-62](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt#L31-L62)
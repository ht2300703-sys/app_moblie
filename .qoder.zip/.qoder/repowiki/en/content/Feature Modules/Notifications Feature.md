# Notifications Feature

<cite>
**Referenced Files in This Document**
- [NotificationsScreen.kt](file://feature/feature-notifications/src/main/java/com/uit20years/feature/notifications/NotificationsScreen.kt)
- [NotificationsNavigation.kt](file://feature/feature-notifications/src/main/java/com/uit20years/feature/notifications/navigation/NotificationsNavigation.kt)
- [Notification.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Notification.kt)
- [NotificationDto.kt](file://core/core-data/src/main/java/com/uit20years/core/data/dto/NotificationDto.kt)
- [NotificationRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/NotificationRepository.kt)
- [NotificationRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/NotificationRepositoryImpl.kt)
- [UitMessagingService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/fcm/UitMessagingService.kt)
- [AppNavHost.kt](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt)
- [Route.kt](file://app/src/main/java/com/uit20years/app/navigation/Route.kt)
- [EmptyView.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/EmptyView.kt)
- [ErrorView.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/ErrorView.kt)
- [DateExt.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/DateExt.kt)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document describes the Notifications Feature module in the UIT20Years application. It focuses on the current implementation of the notification center screen, the navigation structure, and the integration points with the core notification domain models and repositories. It also outlines the Firebase Cloud Messaging integration and provides guidance for extending the feature to support notification listing, types, actions, real-time updates, and dismissal handling.

## Project Structure
The Notifications Feature is organized as a Compose-based feature module with a dedicated screen and navigation graph. It integrates with the core domain model and repository interfaces, while the actual persistence and FCM handling are implemented in separate core modules.

```mermaid
graph TB
subgraph "Feature Layer"
NS["NotificationsScreen.kt"]
NN["NotificationsNavigation.kt"]
end
subgraph "Core Domain"
NModel["Notification.kt"]
NRepo["NotificationRepository.kt"]
end
subgraph "Core Data"
NRepoImpl["NotificationRepositoryImpl.kt"]
NDto["NotificationDto.kt"]
end
subgraph "Core Firebase"
FCM["UitMessagingService.kt"]
end
subgraph "UI Components"
Empty["EmptyView.kt"]
Error["ErrorView.kt"]
end
NS --> NN
NS --> NRepo
NRepo --> NModel
NRepoImpl --> NRepo
NRepoImpl --> NDto
FCM --> NS
NS --> Empty
NS --> Error
```

**Diagram sources**
- [NotificationsScreen.kt:1-27](file://feature/feature-notifications/src/main/java/com/uit20years/feature/notifications/NotificationsScreen.kt#L1-L27)
- [NotificationsNavigation.kt:1-25](file://feature/feature-notifications/src/main/java/com/uit20years/feature/notifications/navigation/NotificationsNavigation.kt#L1-L25)
- [Notification.kt:1-22](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Notification.kt#L1-L22)
- [NotificationRepository.kt:1-12](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/NotificationRepository.kt#L1-L12)
- [NotificationRepositoryImpl.kt:1-32](file://core/core-data/src/main/java/com/uit20years/core/data/repository/NotificationRepositoryImpl.kt#L1-L32)
- [NotificationDto.kt:1-17](file://core/core-data/src/main/java/com/uit20years/core/data/dto/NotificationDto.kt#L1-L17)
- [UitMessagingService.kt:1-21](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/fcm/UitMessagingService.kt#L1-L21)
- [EmptyView.kt:1-31](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/EmptyView.kt#L1-L31)
- [ErrorView.kt:1-41](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/ErrorView.kt#L1-L41)

**Section sources**
- [NotificationsScreen.kt:1-27](file://feature/feature-notifications/src/main/java/com/uit20years/feature/notifications/NotificationsScreen.kt#L1-L27)
- [NotificationsNavigation.kt:1-25](file://feature/feature-notifications/src/main/java/com/uit20years/feature/notifications/navigation/NotificationsNavigation.kt#L1-L25)

## Core Components
- NotificationsScreen: A placeholder screen indicating that notifications are coming soon. It centers a message and can be extended to render a list of notifications.
- NotificationsNavigation: Defines the route and navigation graph for the notifications feature using Jetpack Navigation Compose.
- Core Notification Model: Defines the notification data structure and supported types used across the application.
- Core Notification Repository: Declares the contract for retrieving notifications and marking them as read.
- Core Notification Repository Implementation: Provides stub implementations for notification retrieval and read operations, emitting loading and success states.
- Firebase Cloud Messaging Service: Handles FCM token refresh and incoming messages, with TODOs for persisting tokens and showing local notifications.
- UI Components: EmptyView and ErrorView provide reusable UI for empty states and error scenarios.

**Section sources**
- [Notification.kt:1-22](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Notification.kt#L1-L22)
- [NotificationRepository.kt:1-12](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/NotificationRepository.kt#L1-L12)
- [NotificationRepositoryImpl.kt:1-32](file://core/core-data/src/main/java/com/uit20years/core/data/repository/NotificationRepositoryImpl.kt#L1-L32)
- [UitMessagingService.kt:1-21](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/fcm/UitMessagingService.kt#L1-L21)
- [EmptyView.kt:1-31](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/EmptyView.kt#L1-L31)
- [ErrorView.kt:1-41](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/ErrorView.kt#L1-L41)

## Architecture Overview
The Notifications Feature follows a layered architecture:
- Feature layer: UI screen and navigation graph.
- Core domain: Repository interface and domain model.
- Core data: Repository implementation and DTO mapping.
- Core firebase: FCM service for push notifications.
- Core ui: Reusable UI components for empty and error states.

```mermaid
graph TB
subgraph "App Shell"
AppNav["AppNavHost.kt"]
Routes["Route.kt"]
end
subgraph "Notifications Feature"
NS["NotificationsScreen"]
NN["NotificationsNavigation"]
end
subgraph "Core Domain"
NRepo["NotificationRepository"]
NModel["Notification"]
end
subgraph "Core Data"
NRepoImpl["NotificationRepositoryImpl"]
NDto["NotificationDto"]
end
subgraph "Core Firebase"
FCM["UitMessagingService"]
end
AppNav --> NN
Routes --> AppNav
NS --> NRepo
NRepoImpl --> NRepo
NRepoImpl --> NDto
NRepo --> NModel
FCM --> NS
```

**Diagram sources**
- [AppNavHost.kt:1-26](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L1-L26)
- [Route.kt:1-13](file://app/src/main/java/com/uit20years/app/navigation/Route.kt#L1-L13)
- [NotificationsScreen.kt:1-27](file://feature/feature-notifications/src/main/java/com/uit20years/feature/notifications/NotificationsScreen.kt#L1-L27)
- [NotificationsNavigation.kt:1-25](file://feature/feature-notifications/src/main/java/com/uit20years/feature/notifications/navigation/NotificationsNavigation.kt#L1-L25)
- [NotificationRepository.kt:1-12](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/NotificationRepository.kt#L1-L12)
- [NotificationRepositoryImpl.kt:1-32](file://core/core-data/src/main/java/com/uit20years/core/data/repository/NotificationRepositoryImpl.kt#L1-L32)
- [Notification.kt:1-22](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Notification.kt#L1-L22)
- [NotificationDto.kt:1-17](file://core/core-data/src/main/java/com/uit20years/core/data/dto/NotificationDto.kt#L1-L17)
- [UitMessagingService.kt:1-21](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/fcm/UitMessagingService.kt#L1-L21)

## Detailed Component Analysis

### NotificationsScreen
- Purpose: Placeholder screen for the notifications center.
- Current behavior: Displays a centered "Coming Soon" message.
- Extension points:
  - Replace the placeholder with a list of notifications using LazyColumn.
  - Integrate with NotificationRepository to fetch notifications for the current user.
  - Render different notification types using appropriate UI components.
  - Add swipe-to-dismiss and mark-as-read actions.

```mermaid
flowchart TD
Start(["Enter NotificationsScreen"]) --> Load["Load notifications for current user"]
Load --> HasData{"Has notifications?"}
HasData --> |Yes| RenderList["Render notification list"]
HasData --> |No| ShowEmpty["Show EmptyView"]
RenderList --> Interact["Handle actions:<br/>- Mark as read<br/>- Dismiss<br/>- Navigate on tap"]
Interact --> End(["Exit"])
ShowEmpty --> End
```

**Diagram sources**
- [NotificationsScreen.kt:1-27](file://feature/feature-notifications/src/main/java/com/uit20years/feature/notifications/NotificationsScreen.kt#L1-L27)
- [EmptyView.kt:1-31](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/EmptyView.kt#L1-L31)

**Section sources**
- [NotificationsScreen.kt:1-27](file://feature/feature-notifications/src/main/java/com/uit20years/feature/notifications/NotificationsScreen.kt#L1-L27)
- [EmptyView.kt:1-31](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/EmptyView.kt#L1-L31)

### NotificationsNavigation
- Purpose: Define the navigation route and graph for the notifications feature.
- Route definition: Uses a serializable route object for type-safe navigation.
- Graph composition: Registers the NotificationsScreen composable within the navigation graph.

```mermaid
sequenceDiagram
participant App as "AppNavHost"
participant Nav as "NavHost"
participant Graph as "notificationsGraph"
participant Screen as "NotificationsScreen"
App->>Nav : Set startDestination
App->>Graph : Register navigation graph
Graph->>Nav : Register composable<NotificationsScreen>
Nav->>Screen : Compose NotificationsScreen
```

**Diagram sources**
- [NotificationsNavigation.kt:1-25](file://feature/feature-notifications/src/main/java/com/uit20years/feature/notifications/navigation/NotificationsNavigation.kt#L1-L25)
- [AppNavHost.kt:1-26](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L1-L26)

**Section sources**
- [NotificationsNavigation.kt:1-25](file://feature/feature-notifications/src/main/java/com/uit20years/feature/notifications/navigation/NotificationsNavigation.kt#L1-L25)
- [AppNavHost.kt:1-26](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L1-L26)

### Core Notification Domain Models
- Notification: Defines the domain representation with fields for id, userId, title, body, type, referenceId, isRead, and createdAt.
- NotificationType: Enumerates supported notification categories such as GENERAL, LIKE, COMMENT, FOLLOW, EVENT_REMINDER, and EVENT_UPDATE.

```mermaid
classDiagram
class Notification {
+String id
+String userId
+String title
+String body
+NotificationType type
+String? referenceId
+Boolean isRead
+Long createdAt
}
class NotificationType {
<<enumeration>>
GENERAL
LIKE
COMMENT
FOLLOW
EVENT_REMINDER
EVENT_UPDATE
}
Notification --> NotificationType : "has type"
```

**Diagram sources**
- [Notification.kt:1-22](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Notification.kt#L1-L22)

**Section sources**
- [Notification.kt:1-22](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Notification.kt#L1-L22)

### Core Notification Repository
- Contract: Declares functions to retrieve notifications for a user, mark a single notification as read, and mark all notifications as read.
- Flow-based API: Returns Flow<UitResult<List<Notification>>> for listing and Flow<UitResult<Unit>> for mutation operations.

```mermaid
classDiagram
class NotificationRepository {
+getNotifications(userId : String) Flow~UitResult~Notification[]~
+markAsRead(notificationId : String) Flow~UitResult~Unit~
+markAllAsRead(userId : String) Flow~UitResult~Unit~
}
class NotificationRepositoryImpl {
+getNotifications(userId : String, limit : Int) Flow~UitResult~Notification[]~
+markAsRead(notificationId : String) Flow~UitResult~Unit~
+deleteNotification(notificationId : String) Flow~UitResult~Unit~
}
NotificationRepositoryImpl ..|> NotificationRepository : "implements"
```

**Diagram sources**
- [NotificationRepository.kt:1-12](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/NotificationRepository.kt#L1-L12)
- [NotificationRepositoryImpl.kt:1-32](file://core/core-data/src/main/java/com/uit20years/core/data/repository/NotificationRepositoryImpl.kt#L1-L32)

**Section sources**
- [NotificationRepository.kt:1-12](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/NotificationRepository.kt#L1-L12)
- [NotificationRepositoryImpl.kt:1-32](file://core/core-data/src/main/java/com/uit20years/core/data/repository/NotificationRepositoryImpl.kt#L1-L32)

### Firebase Cloud Messaging Integration
- Token Management: Logs new FCM tokens and indicates where to persist them to Firestore.
- Message Handling: Logs incoming remote messages and indicates where to show local notifications.

```mermaid
sequenceDiagram
participant FCM as "FirebaseMessagingService"
participant App as "UIT20Years App"
participant Store as "Firestore"
FCM->>App : onNewToken(token)
App->>Store : Persist token under /users/{uid}/fcmTokens
FCM->>App : onMessageReceived(message)
App->>App : Show notification via NotificationManager
```

**Diagram sources**
- [UitMessagingService.kt:1-21](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/fcm/UitMessagingService.kt#L1-L21)

**Section sources**
- [UitMessagingService.kt:1-21](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/fcm/UitMessagingService.kt#L1-L21)

### UI Components for Notifications
- EmptyView: Displays a centered message when no notifications are present.
- ErrorView: Displays an error message and optional retry action.

These components can be integrated into the NotificationsScreen to handle loading, empty, and error states during data fetching.

**Section sources**
- [EmptyView.kt:1-31](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/EmptyView.kt#L1-L31)
- [ErrorView.kt:1-41](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/ErrorView.kt#L1-L41)

### Data Fetching Patterns and Timestamp Formatting
- Data fetching pattern: The repository returns Flow<UitResult<T>> to represent loading, success, and error states. The NotificationsScreen should observe this flow and update UI accordingly.
- Timestamp formatting: The extension function Long.toRelativeTime provides human-readable relative time, useful for displaying notification timestamps.

**Section sources**
- [NotificationRepositoryImpl.kt:1-32](file://core/core-data/src/main/java/com/uit20years/core/data/repository/NotificationRepositoryImpl.kt#L1-L32)
- [DateExt.kt:1-23](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/DateExt.kt#L1-L23)

## Dependency Analysis
- Feature depends on core domain for the Notification model and repository interface.
- Core data implements the repository interface and exposes DTOs for persistence.
- Firebase service handles external push notifications and logs integration points.
- UI components provide reusable views for empty and error states.

```mermaid
graph LR
NS["NotificationsScreen"] --> NRepo["NotificationRepository"]
NRepoImpl["NotificationRepositoryImpl"] --> NRepo
NRepoImpl --> NDto["NotificationDto"]
NRepo --> NModel["Notification"]
FCM["UitMessagingService"] --> NS
NS --> Empty["EmptyView"]
NS --> Error["ErrorView"]
```

**Diagram sources**
- [NotificationsScreen.kt:1-27](file://feature/feature-notifications/src/main/java/com/uit20years/feature/notifications/NotificationsScreen.kt#L1-L27)
- [NotificationRepository.kt:1-12](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/NotificationRepository.kt#L1-L12)
- [NotificationRepositoryImpl.kt:1-32](file://core/core-data/src/main/java/com/uit20years/core/data/repository/NotificationRepositoryImpl.kt#L1-L32)
- [NotificationDto.kt:1-17](file://core/core-data/src/main/java/com/uit20years/core/data/dto/NotificationDto.kt#L1-L17)
- [Notification.kt:1-22](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Notification.kt#L1-L22)
- [UitMessagingService.kt:1-21](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/fcm/UitMessagingService.kt#L1-L21)
- [EmptyView.kt:1-31](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/EmptyView.kt#L1-L31)
- [ErrorView.kt:1-41](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/ErrorView.kt#L1-L41)

**Section sources**
- [NotificationsScreen.kt:1-27](file://feature/feature-notifications/src/main/java/com/uit20years/feature/notifications/NotificationsScreen.kt#L1-L27)
- [NotificationRepository.kt:1-12](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/NotificationRepository.kt#L1-L12)
- [NotificationRepositoryImpl.kt:1-32](file://core/core-data/src/main/java/com/uit20years/core/data/repository/NotificationRepositoryImpl.kt#L1-L32)
- [NotificationDto.kt:1-17](file://core/core-data/src/main/java/com/uit20years/core/data/dto/NotificationDto.kt#L1-L17)
- [Notification.kt:1-22](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Notification.kt#L1-L22)
- [UitMessagingService.kt:1-21](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/fcm/UitMessagingService.kt#L1-L21)
- [EmptyView.kt:1-31](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/EmptyView.kt#L1-L31)
- [ErrorView.kt:1-41](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/ErrorView.kt#L1-L41)

## Performance Considerations
- Flow-based APIs: Using Flow<UitResult<T>> enables reactive UI updates and efficient state management.
- Relative timestamps: Using relative time formatting reduces layout recalculations and improves readability.
- Lazy lists: When rendering notifications, prefer LazyColumn to minimize recompositions and memory usage.
- Caching: Consider caching recent notifications locally to reduce network requests and improve perceived performance.

## Troubleshooting Guide
- Notifications screen shows "Coming Soon": Extend the screen to integrate with the repository and render a notification list.
- No notifications displayed: Verify that the repository emits loading and success states and that the UI observes the Flow correctly.
- FCM token not persisted: Ensure the token refresh handler persists the token to Firestore under the user's document.
- Incoming messages not shown: Implement local notification creation using the message payload and integrate with the notification manager.

**Section sources**
- [NotificationsScreen.kt:1-27](file://feature/feature-notifications/src/main/java/com/uit20years/feature/notifications/NotificationsScreen.kt#L1-L27)
- [NotificationRepositoryImpl.kt:1-32](file://core/core-data/src/main/java/com/uit20years/core/data/repository/NotificationRepositoryImpl.kt#L1-L32)
- [UitMessagingService.kt:1-21](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/fcm/UitMessagingService.kt#L1-L21)

## Conclusion
The Notifications Feature currently provides a placeholder screen and navigation structure. To implement a full notification center, integrate the NotificationRepository to fetch and manage notifications, implement UI components for different notification types, and connect the FCM service to display real-time notifications. Follow the established patterns for data fetching, state management, and UI composition to ensure maintainability and scalability.
# Events Feature

<cite>
**Referenced Files in This Document**
- [EventsScreen.kt](file://feature/feature-events/src/main/java/com/uit20years/feature/events/EventsScreen.kt)
- [EventsNavigation.kt](file://feature/feature-events/src/main/java/com/uit20years/feature/events/navigation/EventsNavigation.kt)
- [AppNavHost.kt](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt)
- [Route.kt](file://app/src/main/java/com/uit20years/app/navigation/Route.kt)
- [EventRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/EventRepository.kt)
- [EventRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/EventRepositoryImpl.kt)
- [Event.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Event.kt)
- [EventDto.kt](file://core/core-data/src/main/java/com/uit20years/core/data/dto/EventDto.kt)
- [EventMapper.kt](file://core/core-data/src/main/java/com/uit20years/core/data/mapper/EventMapper.kt)
- [FirestoreService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt)
- [UitResult.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document describes the Events feature module for the UIT20Years application. It focuses on the current EventsScreen implementation, the navigation structure, and the integration points with the core event domain models and repositories. The Events feature is currently in a placeholder state, displaying a "Coming Soon" message, while the underlying infrastructure for event data retrieval, filtering, and registration is being prepared in the core modules. This guide explains how the feature will evolve to support event listing, calendar integration, event details, categories, and registration, and provides extension guidance aligned with the existing architectural patterns.

## Project Structure
The Events feature is organized as a Compose feature module with a dedicated screen and navigation builder. It integrates with the application's navigation host and depends on core domain models and repositories for data operations.

```mermaid
graph TB
subgraph "App Layer"
AppNav["AppNavHost.kt"]
RouteDef["Route.kt"]
end
subgraph "Feature: Events"
EventsScreen["EventsScreen.kt"]
EventsNav["EventsNavigation.kt"]
end
subgraph "Core Domain"
EventRepo["EventRepository.kt"]
EventModel["Event.kt"]
end
subgraph "Core Data"
EventRepoImpl["EventRepositoryImpl.kt"]
EventDto["EventDto.kt"]
EventMapper["EventMapper.kt"]
Firestore["FirestoreService.kt"]
UitResult["UitResult.kt"]
end
AppNav --> EventsNav
EventsNav --> EventsScreen
EventsScreen --> EventRepo
EventRepo --> EventRepoImpl
EventRepoImpl --> EventModel
EventRepoImpl --> EventDto
EventDto --> EventMapper
EventRepoImpl --> Firestore
EventRepoImpl --> UitResult
```

**Diagram sources**
- [AppNavHost.kt:1-26](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L1-L26)
- [Route.kt:1-13](file://app/src/main/java/com/uit20years/app/navigation/Route.kt#L1-L13)
- [EventsScreen.kt:1-27](file://feature/feature-events/src/main/java/com/uit20years/feature/events/EventsScreen.kt#L1-L27)
- [EventsNavigation.kt:1-25](file://feature/feature-events/src/main/java/com/uit20years/feature/events/navigation/EventsNavigation.kt#L1-L25)
- [EventRepository.kt:1-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/EventRepository.kt#L1-L14)
- [EventRepositoryImpl.kt:1-38](file://core/core-data/src/main/java/com/uit20years/core/data/repository/EventRepositoryImpl.kt#L1-L38)
- [Event.kt:1-28](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Event.kt#L1-L28)
- [EventDto.kt:1-19](file://core/core-data/src/main/java/com/uit20years/core/data/dto/EventDto.kt#L1-L19)
- [EventMapper.kt:1-33](file://core/core-data/src/main/java/com/uit20years/core/data/mapper/EventMapper.kt#L1-L33)
- [FirestoreService.kt:1-107](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt#L1-L107)
- [UitResult.kt:1-37](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L1-L37)

**Section sources**
- [EventsScreen.kt:1-27](file://feature/feature-events/src/main/java/com/uit20years/feature/events/EventsScreen.kt#L1-L27)
- [EventsNavigation.kt:1-25](file://feature/feature-events/src/main/java/com/uit20years/feature/events/navigation/EventsNavigation.kt#L1-L25)
- [AppNavHost.kt:1-26](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L1-L26)
- [Route.kt:1-13](file://app/src/main/java/com/uit20years/app/navigation/Route.kt#L1-L13)

## Core Components
- EventsScreen: A placeholder Compose screen that currently renders a centered "Events\nComing Soon" message. It serves as the entry point for the Events feature and will be extended to show event lists, categories, and details.
- EventsNavigation: Defines the route identifier and a navigation builder that registers the Events screen within a typed navigation graph. The builder sets up a single-screen destination for the Events feature.
- Event domain model: Defines the core event data structure, including identifiers, timing, location, type enumeration, and registration status. This model underpins UI rendering and business logic.
- EventRepository interface: Declares the contract for event operations, including listing, observing, and registration/unregistration actions, returning reactive streams of UitResult.
- EventRepositoryImpl: Provides a stubbed implementation emitting Loading states and placeholder results. Future updates will integrate Firestore via FirestoreService and apply EventMapper for DTO-to-domain conversions.
- EventDto and EventMapper: Bridge Firebase Firestore documents to the domain model, ensuring consistent serialization/deserialization and mapping between DTO and domain representations.
- FirestoreService: Offers Firestore operations and reactive observation APIs used by the repository implementation to fetch and stream event data.
- UitResult: A sealed result type enabling unified handling of Success, Error, and Loading states across asynchronous operations.

**Section sources**
- [EventsScreen.kt:13-26](file://feature/feature-events/src/main/java/com/uit20years/feature/events/EventsScreen.kt#L13-L26)
- [EventsNavigation.kt:10-25](file://feature/feature-events/src/main/java/com/uit20years/feature/events/navigation/EventsNavigation.kt#L10-L25)
- [Event.kt:3-18](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Event.kt#L3-L18)
- [EventRepository.kt:7-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/EventRepository.kt#L7-L13)
- [EventRepositoryImpl.kt:12-37](file://core/core-data/src/main/java/com/uit20years/core/data/repository/EventRepositoryImpl.kt#L12-L37)
- [EventDto.kt:6-18](file://core/core-data/src/main/java/com/uit20years/core/data/dto/EventDto.kt#L6-L18)
- [EventMapper.kt:6-32](file://core/core-data/src/main/java/com/uit20years/core/data/mapper/EventMapper.kt#L6-L32)
- [FirestoreService.kt:16-106](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt#L16-L106)
- [UitResult.kt:3-11](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L3-L11)

## Architecture Overview
The Events feature follows a layered architecture:
- UI layer: Compose screen and navigation graph define the user interface and routing.
- Domain layer: Repository interface defines the event operations contract.
- Data layer: Repository implementation integrates Firestore and applies mapping to produce domain models.
- Common utilities: UitResult standardizes asynchronous result handling across the app.

```mermaid
sequenceDiagram
participant User as "User"
participant Screen as "EventsScreen"
participant Repo as "EventRepository"
participant Impl as "EventRepositoryImpl"
participant Mapper as "EventMapper"
participant Firestore as "FirestoreService"
User->>Screen : Navigate to Events
Screen->>Repo : Request events
Repo->>Impl : getEvents()
Impl->>Impl : Emit Loading
Impl->>Firestore : Query events collection
Firestore-->>Impl : Stream QuerySnapshot
Impl->>Mapper : Convert EventDto to Event
Mapper-->>Impl : Domain Event list
Impl->>Impl : Emit Success(list)
Impl-->>Screen : Flow<UitResult<List<Event>>
Screen->>Screen : Render events UI
```

**Diagram sources**
- [EventsScreen.kt:14-26](file://feature/feature-events/src/main/java/com/uit20years/feature/events/EventsScreen.kt#L14-L26)
- [EventRepository.kt:8](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/EventRepository.kt#L8)
- [EventRepositoryImpl.kt:14-18](file://core/core-data/src/main/java/com/uit20years/core/data/repository/EventRepositoryImpl.kt#L14-L18)
- [EventMapper.kt:6-18](file://core/core-data/src/main/java/com/uit20years/core/data/mapper/EventMapper.kt#L6-L18)
- [FirestoreService.kt:22-28](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt#L22-L28)

## Detailed Component Analysis

### EventsScreen
- Purpose: Placeholder screen for the Events feature, centered with a "Coming Soon" message.
- Current behavior: Renders a single composable with centered text and fills the available space.
- Extension points: Replace the placeholder with a scrollable list of events, category chips, and registration controls. Bind to repository flows for data and status updates.

```mermaid
flowchart TD
Start(["EventsScreen Entry"]) --> Layout["Centered Box Layout"]
Layout --> Text["Display 'Events\\nComing Soon'"]
Text --> End(["Screen Ready"])
```

**Diagram sources**
- [EventsScreen.kt:14-26](file://feature/feature-events/src/main/java/com/uit20years/feature/events/EventsScreen.kt#L14-L26)

**Section sources**
- [EventsScreen.kt:13-26](file://feature/feature-events/src/main/java/com/uit20years/feature/events/EventsScreen.kt#L13-L26)

### Navigation and Routing
- Route definition: EventsRoute is a serializable route marker used by the navigation graph.
- Graph builder: eventsGraph registers a single composable destination for EventsScreen under the EventsRoute.
- Application integration: AppNavHost currently routes to authentication screens; future integration will add the Events graph similarly.

```mermaid
sequenceDiagram
participant App as "AppNavHost"
participant Router as "Navigation Graph"
participant Events as "EventsRoute"
participant Screen as "EventsScreen"
App->>Router : Initialize NavHost
Router->>Events : Register EventsRoute
Events->>Screen : Compose EventsScreen
Screen-->>Router : Rendered UI
```

**Diagram sources**
- [AppNavHost.kt:10-25](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L10-L25)
- [EventsNavigation.kt:13-21](file://feature/feature-events/src/main/java/com/uit20years/feature/events/navigation/EventsNavigation.kt#L13-L21)
- [EventsNavigation.kt:10-25](file://feature/feature-events/src/main/java/com/uit20years/feature/events/navigation/EventsNavigation.kt#L10-L25)

**Section sources**
- [EventsNavigation.kt:10-25](file://feature/feature-events/src/main/java/com/uit20years/feature/events/navigation/EventsNavigation.kt#L10-L25)
- [AppNavHost.kt:10-25](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L10-L25)
- [Route.kt:5-12](file://app/src/main/java/com/uit20years/app/navigation/Route.kt#L5-L12)

### Data Flow and Repository Integration
- Domain contract: EventRepository declares methods for listing events, observing specific events, and managing registrations.
- Stubbed implementation: EventRepositoryImpl emits Loading followed by placeholder Success or Error states. This pattern supports UI loading indicators and error messaging.
- Mapping pipeline: EventDto from Firestore is mapped to Event via EventMapper, aligning with the established DTO-to-domain pattern used across the app.
- Firestore integration: FirestoreService provides reactive observation and collection queries suitable for streaming event updates.

```mermaid
classDiagram
class EventRepository {
+getEvents() Flow~UitResult~Event[]~~
+getEventById(eventId) Flow~UitResult~Event~~
+observeScoreboard(eventId) Flow~UitResult~Event~~
+registerForEvent(eventId, userId) Flow~UitResult~Unit~~
+unregisterFromEvent(eventId, userId) Flow~UitResult~Unit~~
}
class EventRepositoryImpl {
+getEvents(limit) Flow~UitResult~Event[]~~
+getEvent(eventId) Flow~UitResult~Event~~
+registerEvent(eventId, userId) Flow~UitResult~Unit~~
+unregisterEvent(eventId, userId) Flow~UitResult~Unit~~
}
class Event {
+id : String
+title : String
+description : String
+location : String
+imageUrl : String?
+startTime : Long
+endTime : Long
+organizerId : String
+attendeeCount : Int
+maxAttendees : Int?
+type : EventType
+livestreamUrl : String?
+isRegistered : Boolean
+createdAt : Long
}
class EventDto {
+id : String
+title : String
+description : String
+location : String
+organizerId : String
+attendeeIds : String[]
+startTime : Long
+endTime : Long
+imageUrl : String
+createdAt : Date?
}
class FirestoreService {
+getCollection(path, queryBuilder) QuerySnapshot
+observeCollection(path, queryBuilder) Flow~QuerySnapshot~
+setDocument(path, id, data, merge)
+addDocument(path, data) String
+updateDocument(path, id, fields)
+deleteDocument(path, id)
+runTransaction(block)
}
EventRepository <|.. EventRepositoryImpl
EventRepositoryImpl --> FirestoreService : "uses"
EventRepositoryImpl --> Event : "produces"
EventRepositoryImpl --> EventDto : "consumes"
EventDto <.. Event : "mapped by EventMapper"
```

**Diagram sources**
- [EventRepository.kt:7-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/EventRepository.kt#L7-L13)
- [EventRepositoryImpl.kt:12-37](file://core/core-data/src/main/java/com/uit20years/core/data/repository/EventRepositoryImpl.kt#L12-L37)
- [Event.kt:3-18](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Event.kt#L3-L18)
- [EventDto.kt:6-18](file://core/core-data/src/main/java/com/uit20years/core/data/dto/EventDto.kt#L6-L18)
- [EventMapper.kt:6-32](file://core/core-data/src/main/java/com/uit20years/core/data/mapper/EventMapper.kt#L6-L32)
- [FirestoreService.kt:16-106](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt#L16-L106)

**Section sources**
- [EventRepository.kt:7-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/EventRepository.kt#L7-L13)
- [EventRepositoryImpl.kt:12-37](file://core/core-data/src/main/java/com/uit20years/core/data/repository/EventRepositoryImpl.kt#L12-L37)
- [EventMapper.kt:6-32](file://core/core-data/src/main/java/com/uit20years/core/data/mapper/EventMapper.kt#L6-L32)
- [FirestoreService.kt:16-106](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt#L16-L106)

### UI Components and Event Registration
- Upcoming events display: The EventsScreen will render a list of upcoming events, leveraging the repository's event listing flow and UitResult handling for loading and error states.
- Categories: A category filter UI can be integrated alongside the event list, allowing users to filter by EventType values defined in the domain model.
- Registration functionality: Registration and unregistration actions will call repository methods and reflect real-time updates via observeScoreboard and event observation flows.

```mermaid
flowchart TD
Start(["User selects Category"]) --> Filter["Filter events by EventType"]
Filter --> List["Render filtered event list"]
List --> Register{"Registration Available?"}
Register --> |Yes| Action["Show Register Button"]
Register --> |No| Action["Show Full/Waitlist Indicator"]
Action --> Click["User taps action"]
Click --> CallRepo["Call register/unregister on repository"]
CallRepo --> Update["Receive updated event via observeScoreboard"]
Update --> Refresh["Refresh UI with new status"]
```

[No sources needed since this diagram shows conceptual workflow, not actual code structure]

## Dependency Analysis
- Coupling: EventsScreen depends on the repository interface, promoting testability and separation of concerns. The repository implementation depends on FirestoreService and mapping utilities.
- Cohesion: EventRepository encapsulates event operations, while EventRepositoryImpl centralizes data access logic. EventMapper ensures consistent DTO-to-domain conversion.
- External dependencies: FirestoreService provides reactive streams and CRUD operations. UitResult standardizes asynchronous result handling across the app.

```mermaid
graph LR
EventsScreen["EventsScreen"] --> EventRepo["EventRepository"]
EventRepo --> EventRepoImpl["EventRepositoryImpl"]
EventRepoImpl --> Firestore["FirestoreService"]
EventRepoImpl --> EventMapper["EventMapper"]
EventMapper --> Event["Event"]
EventRepoImpl --> UitResult["UitResult"]
```

**Diagram sources**
- [EventsScreen.kt:14-26](file://feature/feature-events/src/main/java/com/uit20years/feature/events/EventsScreen.kt#L14-L26)
- [EventRepository.kt:7-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/EventRepository.kt#L7-L13)
- [EventRepositoryImpl.kt:12-37](file://core/core-data/src/main/java/com/uit20years/core/data/repository/EventRepositoryImpl.kt#L12-L37)
- [EventMapper.kt:6-32](file://core/core-data/src/main/java/com/uit20years/core/data/mapper/EventMapper.kt#L6-L32)
- [FirestoreService.kt:16-106](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt#L16-L106)
- [UitResult.kt:3-11](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L3-L11)

**Section sources**
- [EventRepository.kt:7-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/EventRepository.kt#L7-L13)
- [EventRepositoryImpl.kt:12-37](file://core/core-data/src/main/java/com/uit20years/core/data/repository/EventRepositoryImpl.kt#L12-L37)
- [EventMapper.kt:6-32](file://core/core-data/src/main/java/com/uit20years/core/data/mapper/EventMapper.kt#L6-L32)
- [FirestoreService.kt:16-106](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt#L16-L106)
- [UitResult.kt:3-11](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L3-L11)

## Performance Considerations
- Reactive updates: Use observeCollection and observeDocument to minimize polling and keep UI synchronized with Firestore changes.
- Efficient filtering: Apply Firestore queries with filters and ordering to reduce client-side processing overhead.
- Loading states: Leverage UitResult.Loading to provide responsive UI feedback during data fetches.
- Memory management: Ensure proper lifecycle handling of navigation and composition scopes to avoid leaks.

## Troubleshooting Guide
- Loading state handling: Verify that UI displays Loading while repository emits Loading and transitions to Success or Error appropriately.
- Error propagation: Confirm that Error states from the repository propagate to the UI and present actionable messages.
- Data mapping: Validate that EventDto fields map correctly to Event, especially optional fields and timestamps.
- Firestore connectivity: Test repository methods with network availability and handle transaction failures gracefully.

**Section sources**
- [UitResult.kt:13-37](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L13-L37)
- [EventRepositoryImpl.kt:14-36](file://core/core-data/src/main/java/com/uit20years/core/data/repository/EventRepositoryImpl.kt#L14-L36)
- [EventMapper.kt:6-32](file://core/core-data/src/main/java/com/uit20years/core/data/mapper/EventMapper.kt#L6-L32)

## Conclusion
The Events feature is currently a placeholder with a clear path to implementation. The navigation structure is ready, and the core domain and data layers provide the foundation for listing, filtering, and registering for events. By integrating Firestore through EventRepositoryImpl, applying EventMapper for DTO-to-domain conversions, and leveraging UitResult for robust asynchronous handling, the feature can evolve into a comprehensive event management experience. Extending the EventsScreen to render event lists, categories, and registration controls will complete the feature following the established architectural patterns.
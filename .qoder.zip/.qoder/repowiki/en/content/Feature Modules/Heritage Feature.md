# Heritage Feature

<cite>
**Referenced Files in This Document**
- [HeritageScreen.kt](file://feature/feature-heritage/src/main/java/com/uit20years/feature/heritage/HeritageScreen.kt)
- [HeritageNavigation.kt](file://feature/feature-heritage/src/main/java/com/uit20years/feature/heritage/navigation/HeritageNavigation.kt)
- [HeritageRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/HeritageRepository.kt)
- [HeritageRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/HeritageRepositoryImpl.kt)
- [Heritage.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Heritage.kt)
- [HeritageDto.kt](file://core/core-data/src/main/java/com/uit20years/core/data/dto/HeritageDto.kt)
- [AppNavHost.kt](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt)
- [Route.kt](file://app/src/main/java/com/uit20years/app/navigation/Route.kt)
- [IMPLEMENTATION_COMPLETE.md](file://IMPLEMENTATION_COMPLETE.md)
- [build.gradle.kts (feature-heritage)](file://feature/feature-heritage/build.gradle.kts)
- [build.gradle.kts (core-data)](file://core/core-data/build.gradle.kts)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document describes the heritage feature module that implements the historical timeline functionality in the UIT20Years application. It covers the current state of the feature, the navigation structure, and the integration points with the core heritage domain and data layers. It also outlines the data model for heritage items, the repository contract, and the planned implementation path to deliver a fully functional timeline screen with chronological navigation, content categorization, and search capabilities.

The heritage feature is currently in a stubbed state with a placeholder screen and type-safe navigation. The next steps involve implementing the repository to fetch data from Firestore, mapping DTOs to domain models, and building the UI to present historical milestones, achievements, and institutional history in a timeline format.

## Project Structure
The heritage feature is organized as a dedicated feature module with a minimal Compose screen and a navigation graph. The feature integrates with the core domain and data layers via the repository pattern and shared models.

```mermaid
graph TB
subgraph "App Shell"
AppNav["AppNavHost.kt"]
Routes["Route.kt"]
end
subgraph "Feature: heritage"
Screen["HeritageScreen.kt"]
Nav["HeritageNavigation.kt"]
end
subgraph "Core Domain"
RepoIntf["HeritageRepository.kt"]
end
subgraph "Core Data"
RepoImpl["HeritageRepositoryImpl.kt"]
Dto["HeritageDto.kt"]
end
subgraph "Core Model"
Model["Heritage.kt"]
end
AppNav --> Nav
Nav --> Screen
Screen --> RepoIntf
RepoIntf --> RepoImpl
RepoImpl --> Dto
Dto --> Model
```

**Diagram sources**
- [AppNavHost.kt](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt)
- [Route.kt](file://app/src/main/java/com/uit20years/app/navigation/Route.kt)
- [HeritageScreen.kt](file://feature/feature-heritage/src/main/java/com/uit20years/feature/heritage/HeritageScreen.kt)
- [HeritageNavigation.kt](file://feature/feature-heritage/src/main/java/com/uit20years/feature/heritage/navigation/HeritageNavigation.kt)
- [HeritageRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/HeritageRepository.kt)
- [HeritageRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/HeritageRepositoryImpl.kt)
- [HeritageDto.kt](file://core/core-data/src/main/java/com/uit20years/core/data/dto/HeritageDto.kt)
- [Heritage.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Heritage.kt)

**Section sources**
- [build.gradle.kts (feature-heritage)](file://feature/feature-heritage/build.gradle.kts)
- [build.gradle.kts (core-data)](file://core/core-data/build.gradle.kts)

## Core Components
- HeritageScreen: A placeholder Compose screen indicating “Coming Soon” while the timeline feature is under development.
- HeritageNavigation: Defines a type-safe navigation route for the heritage feature using kotlinx.serialization.
- HeritageRepository (Domain): Declares the timeline retrieval, item lookup, and search APIs used by the feature.
- HeritageRepositoryImpl (Data): Provides stub implementations emitting loading and success/error states; intended to integrate with Firestore and search services.
- Heritage (Model): The domain model representing a historical item with fields for id, title, content, media URLs, category, year, tags, and creation timestamp.
- HeritageDto (Data): The Firestore DTO representation used for persistence and mapping to the domain model.

**Section sources**
- [HeritageScreen.kt](file://feature/feature-heritage/src/main/java/com/uit20years/feature/heritage/HeritageScreen.kt)
- [HeritageNavigation.kt](file://feature/feature-heritage/src/main/java/com/uit20years/feature/heritage/navigation/HeritageNavigation.kt)
- [HeritageRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/HeritageRepository.kt)
- [HeritageRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/HeritageRepositoryImpl.kt)
- [Heritage.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Heritage.kt)
- [HeritageDto.kt](file://core/core-data/src/main/java/com/uit20years/core/data/dto/HeritageDto.kt)

## Architecture Overview
The heritage feature follows a clean architecture pattern:
- The feature module depends on the core domain interfaces.
- The core data module implements the domain interfaces and interacts with Firestore and search services.
- The feature module exposes a Compose screen and a navigation graph that integrates into the app’s NavHost.

```mermaid
sequenceDiagram
participant User as "User"
participant Nav as "HeritageNavigation"
participant Screen as "HeritageScreen"
participant Repo as "HeritageRepository"
participant Impl as "HeritageRepositoryImpl"
participant Store as "Firestore/Search"
User->>Nav : Navigate to heritage route
Nav->>Screen : Compose heritage screen
Screen->>Repo : Request timeline data
Repo->>Impl : Delegate call
Impl->>Store : Fetch items / search
Store-->>Impl : Items / Results
Impl-->>Repo : Flow<UitResult<List<Heritage>>
Repo-->>Screen : Flow<UitResult<List<Heritage>>
Screen-->>User : Render timeline UI
```

**Diagram sources**
- [HeritageNavigation.kt](file://feature/feature-heritage/src/main/java/com/uit20years/feature/heritage/navigation/HeritageNavigation.kt)
- [HeritageScreen.kt](file://feature/feature-heritage/src/main/java/com/uit20years/feature/heritage/HeritageScreen.kt)
- [HeritageRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/HeritageRepository.kt)
- [HeritageRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/HeritageRepositoryImpl.kt)

## Detailed Component Analysis

### HeritageScreen
- Purpose: Placeholder screen for the heritage timeline feature.
- Behavior: Centers a “Coming Soon” message using Compose layout primitives.
- Extensibility: Once the repository is implemented, this screen will consume a Flow of timeline items and render a chronological list or timeline UI.

```mermaid
flowchart TD
Start(["Render HeritageScreen"]) --> Layout["Centered Box Layout"]
Layout --> Text["Display 'Coming Soon' Text"]
Text --> End(["Exit"])
```

**Diagram sources**
- [HeritageScreen.kt](file://feature/feature-heritage/src/main/java/com/uit20years/feature/heritage/HeritageScreen.kt)

**Section sources**
- [HeritageScreen.kt](file://feature/feature-heritage/src/main/java/com/uit20years/feature/heritage/HeritageScreen.kt)

### Navigation and Routing
- Route Definition: Uses kotlinx.serialization to define a type-safe route object for the heritage feature.
- Graph Composition: Adds a nested navigation graph with a single composable screen for the heritage feature.
- Integration: The app’s NavHost currently wires the auth graph; the heritage graph can be integrated similarly once ready.

```mermaid
sequenceDiagram
participant App as "AppNavHost"
participant Nav as "HeritageNavigation"
participant Graph as "NavGraphBuilder"
participant Screen as "HeritageScreen"
App->>Nav : Import heritageGraph
Nav->>Graph : navigation<HeritageRoute>
Graph->>Graph : composable<HeritageScreen>
Graph-->>App : Graph registered
App-->>Screen : Navigate to screen
```

**Diagram sources**
- [AppNavHost.kt](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt)
- [HeritageNavigation.kt](file://feature/feature-heritage/src/main/java/com/uit20years/feature/heritage/navigation/HeritageNavigation.kt)

**Section sources**
- [HeritageNavigation.kt](file://feature/feature-heritage/src/main/java/com/uit20years/feature/heritage/navigation/HeritageNavigation.kt)
- [AppNavHost.kt](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt)
- [Route.kt](file://app/src/main/java/com/uit20years/app/navigation/Route.kt)

### Domain Repository Contract
- Responsibilities:
  - Provide a timeline stream of heritage items.
  - Retrieve a specific heritage item by ID.
  - Support searching heritage items by query.
- Return Types: Flow of UitResult wrapping lists or single items for robust UI state handling.

```mermaid
classDiagram
class HeritageRepository {
+getTimeline() Flow~UitResult~<Heritage[]~>~
+getHeritageById(id : String) Flow~UitResult~<Heritage>
+searchHeritage(query : String) Flow~UitResult~<Heritage[]~>~
}
```

**Diagram sources**
- [HeritageRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/HeritageRepository.kt)

**Section sources**
- [HeritageRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/HeritageRepository.kt)

### Data Repository Implementation
- Current State: Emits loading, then success with empty lists or errors for all operations.
- Future Work: Replace stubs with Firestore queries and Algolia search integration.
- Integration Points: FirestoreService for persistence, SearchService for indexing/search.

```mermaid
flowchart TD
Call["Call getTimeline/getHeritageById/searchHeritage"] --> EmitLoading["Emit Loading"]
EmitLoading --> Backend["TODO: Firestore / Search"]
Backend --> Success["Emit Success(List/Item)"]
Backend --> Error["Emit Error"]
```

**Diagram sources**
- [HeritageRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/HeritageRepositoryImpl.kt)

**Section sources**
- [HeritageRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/HeritageRepositoryImpl.kt)

### Domain Model and DTO
- Heritage Model: Contains identity, title, content, media URLs, category, year, tags, and creation timestamp.
- HeritageDto: Firestore-compatible DTO with server timestamps and default values for safe deserialization.
- Mapping Strategy: Convert DTOs to domain models in mappers for UI consumption.

```mermaid
classDiagram
class Heritage {
+String id
+String title
+String content
+String[] mediaUrls
+HeritageCategory category
+Int year
+String[] tags
+Long createdAt
}
class HeritageDto {
+String id
+String title
+String content
+String category
+Int year
+String imageUrl
+String[] tags
+Date createdAt
}
HeritageDto --> Heritage : "map to domain"
```

**Diagram sources**
- [Heritage.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Heritage.kt)
- [HeritageDto.kt](file://core/core-data/src/main/java/com/uit20years/core/data/dto/HeritageDto.kt)

**Section sources**
- [Heritage.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Heritage.kt)
- [HeritageDto.kt](file://core/core-data/src/main/java/com/uit20years/core/data/dto/HeritageDto.kt)

### UI Components for Timeline Presentation
- Current State: Placeholder text in the screen.
- Recommended Components (from core-ui): LoadingIndicator, ErrorView, EmptyView for robust UI states.
- Timeline UI Pattern: Consider a vertical timeline layout with year markers, cards for items grouped by year, and optional media rendering.

[No sources needed since this section provides general guidance]

## Dependency Analysis
The feature module depends on navigation-compose and kotlinx.serialization. The core-data module depends on core-domain, core-firebase, core-search, core-media, core-model, and core-common. The heritage feature will depend on core-domain for the repository interface and core-data for the implementation once it is built.

```mermaid
graph LR
Feature["feature-heritage"] --> NavCompose["navigation-compose"]
Feature --> Serialization["kotlinx-serialization-json"]
CoreData["core-data"] --> CoreDomain["core-domain"]
CoreData --> CoreFirebase["core-firebase"]
CoreData --> CoreSearch["core-search"]
CoreData --> CoreMedia["core-media"]
CoreData --> CoreModel["core-model"]
CoreData --> CoreCommon["core-common"]
```

**Diagram sources**
- [build.gradle.kts (feature-heritage)](file://feature/feature-heritage/build.gradle.kts)
- [build.gradle.kts (core-data)](file://core/core-data/build.gradle.kts)

**Section sources**
- [build.gradle.kts (feature-heritage)](file://feature/feature-heritage/build.gradle.kts)
- [build.gradle.kts (core-data)](file://core/core-data/build.gradle.kts)

## Performance Considerations
- Pagination and Limits: When implementing timeline fetching, introduce limits and pagination to avoid loading large datasets at once.
- Caching: Use local caching or in-memory caches for frequently accessed years/items to reduce network calls.
- Lazy Lists: Render timeline items lazily to minimize memory footprint and improve scroll performance.
- Debounced Search: Apply debouncing for search queries to reduce backend load.
- Offline Resilience: Leverage Firestore offline persistence and UitResult to handle connectivity gracefully.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
- Navigation Issues:
  - Ensure the heritage graph is registered in the app’s NavHost and the route is serializable.
  - Verify that the feature module is included in the app module dependencies.
- Repository Not Found:
  - Confirm Hilt bindings for the repository interface are provided in the data module.
  - Check that the feature module depends on core-data so the implementation is available at runtime.
- Empty Timeline:
  - Confirm that the repository emits Loading followed by Success with actual items after implementation.
  - Validate Firestore rules and data presence for the heritage collection.
- Serialization Errors:
  - Ensure DTOs match Firestore schema and use default values for backward compatibility.

**Section sources**
- [HeritageNavigation.kt](file://feature/feature-heritage/src/main/java/com/uit20years/feature/heritage/navigation/HeritageNavigation.kt)
- [AppNavHost.kt](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt)
- [IMPLEMENTATION_COMPLETE.md](file://IMPLEMENTATION_COMPLETE.md)

## Conclusion
The heritage feature module is currently a placeholder with type-safe navigation and stubbed repository implementations. The next phase involves integrating Firestore for timeline data, implementing the repository methods, mapping DTOs to domain models, and building the timeline UI with chronological navigation and content categorization. Following the established architectural patterns ensures maintainability and scalability as new historical content types and customization options are introduced.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### Implementation Roadmap
- Implement HeritageRepositoryImpl to fetch timelines, search, and fetch items from Firestore.
- Add mapping from HeritageDto to Heritage model.
- Wire the feature’s NavHost integration into the app shell.
- Build the timeline UI with year grouping, item cards, and media support.
- Add search and filtering by category/time period.
- Add unit tests for repository and screen logic.

**Section sources**
- [IMPLEMENTATION_COMPLETE.md](file://IMPLEMENTATION_COMPLETE.md)
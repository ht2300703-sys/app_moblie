# Profile Feature

<cite>
**Referenced Files in This Document**
- [ProfileScreen.kt](file://feature/feature-profile/src/main/java/com/uit20years/feature/profile/ProfileScreen.kt)
- [ProfileNavigation.kt](file://feature/feature-profile/src/main/java/com/uit20years/feature/profile/navigation/ProfileNavigation.kt)
- [AppNavHost.kt](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt)
- [Route.kt](file://app/src/main/java/com/uit20years/app/navigation/Route.kt)
- [User.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt)
- [UserRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/UserRepository.kt)
- [UserRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/UserRepositoryImpl.kt)
- [UserDto.kt](file://core/core-data/src/main/java/com/uit20years/core/data/dto/UserDto.kt)
- [UserMapper.kt](file://core/core-data/src/main/java/com/uit20years/core/data/mapper/UserMapper.kt)
- [AuthRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt)
- [AuthRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt)
- [GetCurrentUserUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/GetCurrentUserUseCase.kt)
- [FirestorePaths.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/constants/FirestorePaths.kt)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document describes the Profile Feature module for the UIT20Years application. It focuses on the current ProfileScreen placeholder, the navigation structure, and the integration points with the core user domain models and repositories. It also outlines the data fetching patterns for user profiles, update mechanisms, and profile picture handling, and provides guidance for extending the feature with user information display, editing capabilities, and account settings management.

## Project Structure
The Profile Feature is implemented as a Compose feature module with a minimal screen and navigation graph. The navigation integrates with the application-level NavHost, while the user data layer resides in the core modules.

```mermaid
graph TB
subgraph "App Layer"
ANH["AppNavHost.kt"]
AR["Route.kt"]
end
subgraph "Feature: Profile"
PS["ProfileScreen.kt"]
PN["ProfileNavigation.kt"]
end
subgraph "Core Domain"
UR["UserRepository.kt"]
AU["AuthRepository.kt"]
GCUC["GetCurrentUserUseCase.kt"]
end
subgraph "Core Data"
URI["UserRepositoryImpl.kt"]
ARI["AuthRepositoryImpl.kt"]
end
subgraph "Core Model"
UM["User.kt"]
end
subgraph "Core Common"
FP["FirestorePaths.kt"]
end
ANH --> PN
PN --> PS
PS --> UR
UR --> URI
URI --> FP
PS --> AU
AU --> ARI
URI --> UM
ARI --> UM
```

**Diagram sources**
- [AppNavHost.kt:1-26](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L1-L26)
- [Route.kt:1-13](file://app/src/main/java/com/uit20years/app/navigation/Route.kt#L1-L13)
- [ProfileScreen.kt:1-27](file://feature/feature-profile/src/main/java/com/uit20years/feature/profile/ProfileScreen.kt#L1-L27)
- [ProfileNavigation.kt:1-25](file://feature/feature-profile/src/main/java/com/uit20years/feature/profile/navigation/ProfileNavigation.kt#L1-L25)
- [UserRepository.kt:1-15](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/UserRepository.kt#L1-L15)
- [UserRepositoryImpl.kt:1-97](file://core/core-data/src/main/java/com/uit20years/core/data/repository/UserRepositoryImpl.kt#L1-L97)
- [AuthRepository.kt:1-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L1-L14)
- [AuthRepositoryImpl.kt:1-147](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L1-L147)
- [User.kt:1-23](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt#L1-L23)
- [FirestorePaths.kt:1-17](file://core/core-common/src/main/kotlin/com/uit20years/core/common/constants/FirestorePaths.kt#L1-L17)

**Section sources**
- [ProfileScreen.kt:1-27](file://feature/feature-profile/src/main/java/com/uit20years/feature/profile/ProfileScreen.kt#L1-L27)
- [ProfileNavigation.kt:1-25](file://feature/feature-profile/src/main/java/com/uit20years/feature/profile/navigation/ProfileNavigation.kt#L1-L25)
- [AppNavHost.kt:1-26](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L1-L26)
- [Route.kt:1-13](file://app/src/main/java/com/uit20years/app/navigation/Route.kt#L1-L13)

## Core Components
- ProfileScreen: A placeholder screen indicating "Profile Coming Soon". It currently renders centered text and does not consume user data.
- ProfileNavigation: Defines the serializable route for the profile screen and registers the composable within a navigation graph.
- Application Navigation: The AppNavHost sets up the global navigation host and currently routes to authentication screens. The profile graph is declared but not yet integrated into the main NavHost.

Key integration points:
- User domain model: The profile feature will consume the User model for display and editing.
- User repository: Provides user retrieval, updates, and social actions (follow/unfollow) via Flow-based APIs.
- Authentication repository: Supplies current user context and integrates with Firestore user documents.

**Section sources**
- [ProfileScreen.kt:13-26](file://feature/feature-profile/src/main/java/com/uit20years/feature/profile/ProfileScreen.kt#L13-L26)
- [ProfileNavigation.kt:10-25](file://feature/feature-profile/src/main/java/com/uit20years/feature/profile/navigation/ProfileNavigation.kt#L10-L25)
- [AppNavHost.kt:10-25](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L10-L25)
- [User.kt:3-15](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt#L3-L15)
- [UserRepository.kt:7-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/UserRepository.kt#L7-L14)
- [AuthRepository.kt:7-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L7-L13)

## Architecture Overview
The profile feature follows a layered architecture:
- Presentation: Compose screen and navigation graph.
- Domain: Use cases and repository interfaces define the contract for user operations.
- Data: Repository implementations handle Firestore interactions and mapping between DTOs and domain models.
- Common: Constants and shared utilities (e.g., Firestore collection paths).

```mermaid
graph TB
PS["ProfileScreen.kt"] --> UR["UserRepository.kt"]
UR --> URI["UserRepositoryImpl.kt"]
URI --> FP["FirestorePaths.kt"]
URI --> UD["UserDto.kt"]
URI --> UM["User.kt"]
PS --> AU["AuthRepository.kt"]
AU --> ARI["AuthRepositoryImpl.kt"]
ARI --> FP
ARI --> UD
ARI --> UM
```

**Diagram sources**
- [ProfileScreen.kt:13-26](file://feature/feature-profile/src/main/java/com/uit20years/feature/profile/ProfileScreen.kt#L13-L26)
- [UserRepository.kt:7-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/UserRepository.kt#L7-L14)
- [UserRepositoryImpl.kt:22-59](file://core/core-data/src/main/java/com/uit20years/core/data/repository/UserRepositoryImpl.kt#L22-L59)
- [FirestorePaths.kt:3-16](file://core/core-common/src/main/kotlin/com/uit20years/core/common/constants/FirestorePaths.kt#L3-L16)
- [UserDto.kt:6-18](file://core/core-data/src/main/java/com/uit20years/core/data/dto/UserDto.kt#L6-L18)
- [User.kt:3-15](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt#L3-L15)
- [AuthRepository.kt:7-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L7-L13)
- [AuthRepositoryImpl.kt:29-55](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L29-L55)

## Detailed Component Analysis

### ProfileScreen Implementation
Current behavior:
- Renders a centered "Profile\nComing Soon" text.
- Does not fetch or display user data.
- Does not expose editing controls or account settings UI.

Recommended enhancements:
- Fetch current user via GetCurrentUserUseCase or AuthRepository.getCurrentUser().
- Display user avatar, display name, bio, faculty, graduation year, and follower/following counts.
- Provide editable fields for bio, faculty, and other profile attributes.
- Implement update mechanism using UserRepository.updateProfile().
- Support profile picture upload via MediaUploader and persist avatarUrl.

```mermaid
flowchart TD
Start(["ProfileScreen Entry"]) --> LoadUser["Load Current User"]
LoadUser --> HasUser{"User Available?"}
HasUser --> |No| ShowAuth["Redirect to Auth or Show Error"]
HasUser --> |Yes| RenderUI["Render User Details<br/>+ Edit Controls"]
RenderUI --> OnEdit["On Edit Triggered"]
OnEdit --> Validate["Validate Input Fields"]
Validate --> Valid{"Valid?"}
Valid --> |No| ShowError["Show Validation Error"]
Valid --> |Yes| UpdateRepo["Call UserRepository.updateProfile()"]
UpdateRepo --> UpdateResult{"Update Success?"}
UpdateResult --> |No| ShowError
UpdateResult --> |Yes| Refresh["Refresh UI with Updated Data"]
ShowAuth --> End(["Exit"])
ShowError --> End
Refresh --> End
```

**Diagram sources**
- [ProfileScreen.kt:13-26](file://feature/feature-profile/src/main/java/com/uit20years/feature/profile/ProfileScreen.kt#L13-L26)
- [GetCurrentUserUseCase.kt:10-22](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/GetCurrentUserUseCase.kt#L10-L22)
- [AuthRepository.kt:11-12](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L11-L12)
- [AuthRepositoryImpl.kt:116-133](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L116-L133)
- [UserRepository.kt:8-9](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/UserRepository.kt#L8-L9)
- [UserRepositoryImpl.kt:37-59](file://core/core-data/src/main/java/com/uit20years/core/data/repository/UserRepositoryImpl.kt#L37-L59)

**Section sources**
- [ProfileScreen.kt:13-26](file://feature/feature-profile/src/main/java/com/uit20years/feature/profile/ProfileScreen.kt#L13-L26)
- [GetCurrentUserUseCase.kt:10-22](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/GetCurrentUserUseCase.kt#L10-L22)
- [AuthRepositoryImpl.kt:116-133](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L116-L133)

### Navigation Structure and Route Definitions
- ProfileRoute and ProfileScreen are defined as serializable data objects for type-safe navigation.
- ProfileNavigation registers a nested navigation graph under ProfileRoute with ProfileScreen as the start destination.
- AppNavHost currently routes to authentication screens and includes a placeholder for a home destination. The profile graph is declared but not yet wired into AppNavHost.

Integration steps:
- Import the profile graph into AppNavHost similar to how authGraph is integrated.
- Define a top-level route for Profile in Route.kt if needed.
- Connect bottom navigation or a dedicated profile tab to navigate to ProfileRoute.

```mermaid
sequenceDiagram
participant App as "AppNavHost.kt"
participant Nav as "ProfileNavigation.kt"
participant Screen as "ProfileScreen.kt"
App->>Nav : "Invoke profileGraph(navController)"
Nav->>Nav : "Define ProfileRoute and ProfileScreen"
Nav->>Screen : "Register composable<ProfileScreen>"
App-->>Screen : "Render ProfileScreen on ProfileRoute"
```

**Diagram sources**
- [AppNavHost.kt:10-25](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L10-L25)
- [ProfileNavigation.kt:13-21](file://feature/feature-profile/src/main/java/com/uit20years/feature/profile/navigation/ProfileNavigation.kt#L13-L21)
- [ProfileScreen.kt:13-26](file://feature/feature-profile/src/main/java/com/uit20years/feature/profile/ProfileScreen.kt#L13-L26)

**Section sources**
- [ProfileNavigation.kt:10-25](file://feature/feature-profile/src/main/java/com/uit20years/feature/profile/navigation/ProfileNavigation.kt#L10-L25)
- [AppNavHost.kt:10-25](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L10-L25)

### Data Fetching Patterns for User Profiles
- Current user retrieval: AuthRepositoryImpl.getCurrentUser() fetches the Firebase user and loads the corresponding Firestore document from the USERS collection, mapping it to the domain User model.
- Flow-based loading: Both AuthRepositoryImpl and UserRepositoryImpl emit Loading, Success, and Error states for asynchronous operations.
- Firestore paths: FirestorePaths.USERS defines the collection name for user documents.

```mermaid
sequenceDiagram
participant VM as "ViewModel (Profile)"
participant GCUC as "GetCurrentUserUseCase.kt"
participant ARI as "AuthRepositoryImpl.kt"
participant FS as "FirestoreService"
participant FP as "FirestorePaths.kt"
participant UM as "User.kt"
VM->>GCUC : "invoke()"
GCUC->>ARI : "getCurrentUser()"
ARI->>FS : "getDocument(USERS, uid)"
FS-->>ARI : "User document"
ARI->>UM : "Map to User domain"
ARI-->>GCUC : "User"
GCUC-->>VM : "UitResult<User>"
```

**Diagram sources**
- [GetCurrentUserUseCase.kt:10-22](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/GetCurrentUserUseCase.kt#L10-L22)
- [AuthRepositoryImpl.kt:116-133](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L116-L133)
- [FirestorePaths.kt:3-4](file://core/core-common/src/main/kotlin/com/uit20years/core/common/constants/FirestorePaths.kt#L3-L4)
- [User.kt:3-15](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt#L3-L15)

**Section sources**
- [AuthRepositoryImpl.kt:116-133](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L116-L133)
- [FirestorePaths.kt:3-4](file://core/core-common/src/main/kotlin/com/uit20years/core/common/constants/FirestorePaths.kt#L3-L4)
- [User.kt:3-15](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt#L3-L15)

### Update Mechanisms and Profile Picture Handling
- Profile update: UserRepositoryImpl.updateProfile() converts the domain User to UserDto and writes to Firestore with merge=true.
- Profile picture handling: The User model includes an optional avatarUrl field. To implement image uploads, integrate MediaUploader to upload images to Firebase Storage and update avatarUrl via UserRepository.updateProfile().

```mermaid
flowchart TD
Start(["Update Profile"]) --> BuildDto["Build UserDto from User"]
BuildDto --> UploadImage{"Avatar Changed?"}
UploadImage --> |Yes| MediaUpload["Upload to Firebase Storage"]
UploadImage --> |No| SkipUpload["Skip Upload"]
MediaUpload --> SetUrl["Set avatarUrl in UserDto"]
SkipUpload --> Save["Save to Firestore (merge=true)"]
SetUrl --> Save
Save --> Done(["Update Complete"])
```

**Diagram sources**
- [UserRepositoryImpl.kt:37-59](file://core/core-data/src/main/java/com/uit20years/core/data/repository/UserRepositoryImpl.kt#L37-L59)
- [UserDto.kt:6-18](file://core/core-data/src/main/java/com/uit20years/core/data/dto/UserDto.kt#L6-L18)
- [User.kt:7](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt#L7)

**Section sources**
- [UserRepositoryImpl.kt:37-59](file://core/core-data/src/main/java/com/uit20years/core/data/repository/UserRepositoryImpl.kt#L37-L59)
- [UserDto.kt:6-18](file://core/core-data/src/main/java/com/uit20years/core/data/dto/UserDto.kt#L6-L18)
- [User.kt:7](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt#L7)

### UI Components for User Details and Statistics
- Placeholder UI: ProfileScreen currently uses a centered Text composable.
- Recommended components (from core-ui):
  - UitTextField for editable fields (display name, bio, faculty).
  - UitButton for save/cancel actions.
  - UitTopBar for navigation and actions.
  - LoadingIndicator and ErrorView for feedback states.
- For profile picture:
  - Use an image component to render avatarUrl.
  - Provide an action to pick/upload an image and update avatarUrl.

Note: The above components are available in core-ui and can be imported into the profile feature module.

**Section sources**
- [ProfileScreen.kt:13-26](file://feature/feature-profile/src/main/java/com/uit20years/feature/profile/ProfileScreen.kt#L13-L26)

## Dependency Analysis
The profile feature depends on:
- Domain interfaces (UserRepository, AuthRepository) for user operations.
- Data implementations (UserRepositoryImpl, AuthRepositoryImpl) for Firestore interactions.
- Model (User) and DTO (UserDto) for data representation.
- Constants (FirestorePaths) for collection names.

```mermaid
graph LR
PS["ProfileScreen.kt"] --> UR["UserRepository.kt"]
PS --> AU["AuthRepository.kt"]
UR --> URI["UserRepositoryImpl.kt"]
AU --> ARI["AuthRepositoryImpl.kt"]
URI --> FP["FirestorePaths.kt"]
URI --> UD["UserDto.kt"]
ARI --> UD
URI --> UM["User.kt"]
ARI --> UM
```

**Diagram sources**
- [ProfileScreen.kt:13-26](file://feature/feature-profile/src/main/java/com/uit20years/feature/profile/ProfileScreen.kt#L13-L26)
- [UserRepository.kt:7-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/UserRepository.kt#L7-L14)
- [AuthRepository.kt:7-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L7-L13)
- [UserRepositoryImpl.kt:22-59](file://core/core-data/src/main/java/com/uit20years/core/data/repository/UserRepositoryImpl.kt#L22-L59)
- [AuthRepositoryImpl.kt:29-55](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L29-L55)
- [FirestorePaths.kt:3-16](file://core/core-common/src/main/kotlin/com/uit20years/core/common/constants/FirestorePaths.kt#L3-L16)
- [UserDto.kt:6-18](file://core/core-data/src/main/java/com/uit20years/core/data/dto/UserDto.kt#L6-L18)
- [User.kt:3-15](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt#L3-L15)

**Section sources**
- [UserRepository.kt:7-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/UserRepository.kt#L7-L14)
- [AuthRepository.kt:7-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L7-L13)
- [UserRepositoryImpl.kt:22-59](file://core/core-data/src/main/java/com/uit20years/core/data/repository/UserRepositoryImpl.kt#L22-L59)
- [AuthRepositoryImpl.kt:29-55](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L29-L55)

## Performance Considerations
- Prefer Flow-based APIs for reactive UI updates and efficient state management.
- Use merge=true when updating user profiles to avoid overwriting existing fields.
- Debounce user input for real-time editing to reduce unnecessary Firestore writes.
- Cache frequently accessed user data locally to minimize network requests.
- Use lazy composition and recomposition boundaries to optimize rendering of lists or grids.

## Troubleshooting Guide
Common issues and resolutions:
- User not found: Ensure the user document exists in the USERS collection before attempting to load. The repository emits an error when the document does not exist.
- Authentication state: Verify that the current user is authenticated before loading profile data. Use GetCurrentUserUseCase or AuthRepository.observeAuthState().
- Firestore exceptions: Catch and map exceptions to user-friendly messages. The repositories already emit UitResult.Error with localized messages.
- Serialization errors: Confirm that ProfileRoute and ProfileScreen are properly annotated as Serializable and registered in the navigation graph.

**Section sources**
- [UserRepositoryImpl.kt:22-35](file://core/core-data/src/main/java/com/uit20years/core/data/repository/UserRepositoryImpl.kt#L22-L35)
- [AuthRepositoryImpl.kt:29-55](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L29-L55)
- [ProfileNavigation.kt:10-25](file://feature/feature-profile/src/main/java/com/uit20years/feature/profile/navigation/ProfileNavigation.kt#L10-L25)

## Conclusion
The Profile Feature currently provides a placeholder screen and navigation structure. By integrating the core user domain models and repositories, the feature can deliver a robust user profile experience with editing capabilities, account settings, and profile picture management. The established patterns for data fetching, updates, and navigation enable scalable enhancements aligned with the application’s architecture.

## Appendices
- Extending profile functionality:
  - Add a ProfileViewModel to manage UI state and delegate to use cases/repositories.
  - Implement edit forms with validation and submit handlers.
  - Add social actions (follow/unfollow) using UserRepository.followUser/unfollowUser.
  - Integrate media upload pipeline for profile pictures.
- Adding profile customization options:
  - Extend the User model with new fields and update mappers.
  - Add new UI components for displaying and editing custom fields.
- Implementing user preference management:
  - Store preferences in Firestore under the user document or a separate preferences collection.
  - Use Flow-based observers to keep preferences synchronized across sessions.
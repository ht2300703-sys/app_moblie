# App Module

<cite>
**Referenced Files in This Document**
- [UIT20YearsApplication.kt](file://app/src/main/java/com/uit20years/app/UIT20YearsApplication.kt)
- [MainActivity.kt](file://app/src/main/java/com/uit20years/app/MainActivity.kt)
- [AppNavHost.kt](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt)
- [Route.kt](file://app/src/main/java/com/uit20years/app/navigation/Route.kt)
- [DispatcherModule.kt](file://app/src/main/java/com/uit20years/app/di/DispatcherModule.kt)
- [AndroidManifest.xml](file://app/src/main/AndroidManifest.xml)
- [build.gradle.kts](file://app/build.gradle.kts)
- [AuthNavigation.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/navigation/AuthNavigation.kt)
- [EventsNavigation.kt](file://feature/feature-events/src/main/java/com/uit20years/feature/events/navigation/EventsNavigation.kt)
- [AndroidHiltConventionPlugin.kt](file://build-logic/convention/src/main/kotlin/AndroidHiltConventionPlugin.kt)
- [KotlinAndroid.kt](file://build-logic/convention/src/main/kotlin/KotlinAndroid.kt)
- [libs.versions.toml](file://gradle/libs.versions.toml)
- [Dispatchers.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/dispatcher/Dispatchers.kt)
- [settings.gradle.kts](file://settings.gradle.kts)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
The app module serves as the main application shell and entry point for the UIT20Years Android application. It orchestrates the entire application lifecycle, manages dependency injection with Hilt, configures the main activity with edge-to-edge support, and defines the navigation architecture using Jetpack Compose Navigation. The module integrates with core modules and feature modules while maintaining a clean separation of concerns through modular architecture patterns.

## Project Structure
The app module follows a modular Android architecture with clear boundaries between the application shell, core infrastructure, and feature implementations. The structure emphasizes separation of concerns and testability through dependency injection and navigation composition.

```mermaid
graph TB
subgraph "App Module"
App["app module"]
App --> MainAct["MainActivity"]
App --> AppNav["AppNavHost"]
App --> DI["Dependency Injection"]
end
subgraph "Core Modules"
CoreCommon["core-common"]
CoreData["core-data"]
CoreDomain["core-domain"]
CoreFirebase["core-firebase"]
CoreUI["core-ui"]
CoreModel["core-model"]
CoreMedia["core-media"]
CoreSearch["core-search"]
end
subgraph "Feature Modules"
FeatureAuth["feature-auth"]
FeatureMoments["feature-moments"]
FeatureEvents["feature-events"]
FeatureHeritage["feature-heritage"]
FeatureProfile["feature-profile"]
FeatureNotifications["feature-notifications"]
end
App --> CoreCommon
App --> CoreData
App --> CoreDomain
App --> CoreFirebase
App --> CoreUI
App --> CoreModel
App --> CoreMedia
App --> CoreSearch
App --> FeatureAuth
App --> FeatureMoments
App --> FeatureEvents
App --> FeatureHeritage
App --> FeatureProfile
App --> FeatureNotifications
```

**Diagram sources**
- [settings.gradle.kts:20-39](file://settings.gradle.kts#L20-L39)
- [build.gradle.kts:35-52](file://app/build.gradle.kts#L35-L52)

**Section sources**
- [settings.gradle.kts:18-39](file://settings.gradle.kts#L18-L39)
- [build.gradle.kts:1-82](file://app/build.gradle.kts#L1-L82)

## Core Components
The app module consists of several key components that work together to provide the application foundation:

### Application Bootstrap
The application bootstrapping process begins with the application class that initializes the Hilt dependency injection framework. This enables the entire application to benefit from structured dependency management and testing capabilities.

### Main Activity Configuration
The MainActivity serves as the primary entry point for the Android application, configured with edge-to-edge support and Compose-based UI rendering. It establishes the navigation host and applies the application theme.

### Navigation Architecture
The navigation system uses Jetpack Compose Navigation with type-safe route definitions. The AppNavHost coordinates multiple feature graphs while maintaining a centralized navigation controller.

### Dependency Injection Setup
The app module implements a comprehensive dependency injection system using Hilt, providing specialized dispatchers and managing application-wide dependencies.

**Section sources**
- [UIT20YearsApplication.kt:1-8](file://app/src/main/java/com/uit20years/app/UIT20YearsApplication.kt#L1-L8)
- [MainActivity.kt:1-28](file://app/src/main/java/com/uit20years/app/MainActivity.kt#L1-L28)
- [AppNavHost.kt:1-26](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L1-L26)
- [DispatcherModule.kt:1-27](file://app/src/main/java/com/uit20years/app/di/DispatcherModule.kt#L1-L27)

## Architecture Overview
The app module implements a layered architecture that separates concerns between presentation, navigation, and infrastructure components. The architecture emphasizes modularity, testability, and maintainability through well-defined interfaces and dependency injection.

```mermaid
graph TB
subgraph "Presentation Layer"
MainActivity["MainActivity"]
AppNavHost["AppNavHost"]
Routes["Route Definitions"]
end
subgraph "Navigation Layer"
NavController["NavController"]
AuthGraph["Auth Graph"]
HomeGraph["Home Graph"]
end
subgraph "Feature Layer"
AuthFeature["Auth Feature"]
EventsFeature["Events Feature"]
MomentsFeature["Moments Feature"]
HeritageFeature["Heritage Feature"]
ProfileFeature["Profile Feature"]
NotificationsFeature["Notifications Feature"]
end
subgraph "Infrastructure Layer"
HiltDI["Hilt DI Container"]
FirebaseService["Firebase Services"]
NetworkLayer["Network Layer"]
DatabaseLayer["Local Storage"]
end
MainActivity --> AppNavHost
AppNavHost --> NavController
AppNavHost --> Routes
AppNavHost --> AuthGraph
AppNavHost --> HomeGraph
AuthGraph --> AuthFeature
HomeGraph --> EventsFeature
HomeGraph --> MomentsFeature
HomeGraph --> HeritageFeature
HomeGraph --> ProfileFeature
HomeGraph --> NotificationsFeature
HiltDI --> FirebaseService
HiltDI --> NetworkLayer
HiltDI --> DatabaseLayer
```

**Diagram sources**
- [MainActivity.kt:14-27](file://app/src/main/java/com/uit20years/app/MainActivity.kt#L14-L27)
- [AppNavHost.kt:10-25](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L10-L25)
- [AuthNavigation.kt:20-48](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/navigation/AuthNavigation.kt#L20-L48)

## Detailed Component Analysis

### Application Bootstrap and Lifecycle
The application bootstrap process follows a structured lifecycle that ensures proper initialization of all components before user interaction begins.

```mermaid
sequenceDiagram
participant System as "Android System"
participant App as "UIT20YearsApplication"
participant Hilt as "Hilt Container"
participant Activity as "MainActivity"
participant Nav as "AppNavHost"
System->>App : onCreate()
App->>Hilt : Initialize DI Container
Hilt-->>App : Provide Dependencies
App-->>System : Application Ready
System->>Activity : onCreate()
Activity->>Activity : enableEdgeToEdge()
Activity->>Nav : setContent(AppNavHost)
Nav->>Nav : rememberNavController()
Nav->>Nav : Configure Navigation Graph
Nav-->>Activity : Render UI
Activity-->>System : Activity Ready
```

**Diagram sources**
- [UIT20YearsApplication.kt:6-7](file://app/src/main/java/com/uit20years/app/UIT20YearsApplication.kt#L6-L7)
- [MainActivity.kt:16-26](file://app/src/main/java/com/uit20years/app/MainActivity.kt#L16-L26)
- [AppNavHost.kt:11-25](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L11-L25)

The bootstrap process begins with the application class annotated with `@HiltAndroidApp`, which triggers Hilt's dependency injection framework initialization. This creates a singleton-scoped container that manages all application-level dependencies.

**Section sources**
- [UIT20YearsApplication.kt:1-8](file://app/src/main/java/com/uit20years/app/UIT20YearsApplication.kt#L1-L8)

### Main Activity Configuration and Edge-to-Edge Support
The MainActivity implements modern Android UI patterns with edge-to-edge support and Compose-based rendering. The activity configuration ensures optimal screen utilization and modern UI aesthetics.

```mermaid
classDiagram
class MainActivity {
+onCreate(Bundle) void
+enableEdgeToEdge() void
+setContent() void
-navController NavController
}
class UIT20YearsApplication {
+Application constructor
+@HiltAndroidApp annotation
}
class AppNavHost {
+rememberNavController() NavController
+NavHost() void
+authGraph() void
}
MainActivity --> UIT20YearsApplication : "extends"
MainActivity --> AppNavHost : "renders"
AppNavHost --> MainActivity : "called from"
```

**Diagram sources**
- [MainActivity.kt:14-27](file://app/src/main/java/com/uit20years/app/MainActivity.kt#L14-L27)
- [AppNavHost.kt:10-25](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L10-L25)

The edge-to-edge support is enabled through the `enableEdgeToEdge()` method, which allows the UI to extend behind system bars for a more immersive experience. The Compose-based UI rendering provides declarative UI construction with Material Design 3 theming.

**Section sources**
- [MainActivity.kt:1-28](file://app/src/main/java/com/uit20years/app/MainActivity.kt#L1-L28)

### Navigation Architecture and Type-Safe Routes
The navigation system implements type-safe routing using Kotlin serialization annotations, providing compile-time safety for navigation operations.

```mermaid
classDiagram
class Route {
<<sealed>>
+Auth : Route
+Home : Route
}
class AuthRoute {
<<serializable>>
+AuthRoute data object
}
class LoginRoute {
<<serializable>>
+LoginRoute data object
}
class RegisterRoute {
<<serializable>>
+RegisterRoute data object
}
class AppNavHost {
+rememberNavController() NavController
+NavHost() void
+authGraph() void
}
Route <|-- AuthRoute
Route <|-- HomeRoute
AuthRoute --> LoginRoute : "contains"
AuthRoute --> RegisterRoute : "contains"
AppNavHost --> AuthRoute : "startDestination"
```

**Diagram sources**
- [Route.kt:5-12](file://app/src/main/java/com/uit20years/app/navigation/Route.kt#L5-L12)
- [AuthNavigation.kt:11-18](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/navigation/AuthNavigation.kt#L11-L18)
- [AppNavHost.kt:14-18](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L14-L18)

The type-safe route system uses Kotlin serialization annotations (`@Serializable`) to create compile-time safe navigation targets. The `Route` sealed class defines the application's navigation hierarchy, while individual route objects represent specific destinations within the navigation graph.

**Section sources**
- [Route.kt:1-13](file://app/src/main/java/com/uit20years/app/navigation/Route.kt#L1-L13)
- [AuthNavigation.kt:1-49](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/navigation/AuthNavigation.kt#L1-L49)

### Dependency Injection Setup with Hilt
The app module implements a comprehensive dependency injection system using Hilt, providing specialized dispatchers and managing application-wide dependencies.

```mermaid
classDiagram
class DispatcherModule {
+providesIoDispatcher() CoroutineDispatcher
+providesDefaultDispatcher() CoroutineDispatcher
}
class IoDispatcher {
<<qualifier>>
+IoDispatcher annotation
}
class DefaultDispatcher {
<<qualifier>>
+DefaultDispatcher annotation
}
class UIT20YearsApplication {
+@HiltAndroidApp annotation
}
class MainActivity {
+@AndroidEntryPoint annotation
}
DispatcherModule --> IoDispatcher : "annotated with"
DispatcherModule --> DefaultDispatcher : "annotated with"
UIT20YearsApplication --> DispatcherModule : "installed in"
MainActivity --> DispatcherModule : "injects"
```

**Diagram sources**
- [DispatcherModule.kt:13-26](file://app/src/main/java/com/uit20years/app/di/DispatcherModule.kt#L13-L26)
- [Dispatchers.kt:5-16](file://core/core-common/src/main/kotlin/com/uit20years/core/common/dispatcher/Dispatchers.kt#L5-L16)
- [UIT20YearsApplication.kt:6-7](file://app/src/main/java/com/uit20years/app/UIT20YearsApplication.kt#L6-L7)

The dependency injection setup uses Hilt qualifiers to distinguish between different coroutine dispatchers. The `DispatcherModule` provides both IO and default dispatchers with singleton scope, ensuring efficient resource utilization across the application.

**Section sources**
- [DispatcherModule.kt:1-27](file://app/src/main/java/com/uit20years/app/di/DispatcherModule.kt#L1-L27)
- [Dispatchers.kt:1-16](file://core/core-common/src/main/kotlin/com/uit20years/core/common/dispatcher/Dispatchers.kt#L1-L16)

### AndroidManifest Configuration
The AndroidManifest.xml defines the application's permissions, activities, and service configurations following modern Android development practices.

```mermaid
flowchart TD
Manifest["AndroidManifest.xml"] --> AppNode["<application>"]
Manifest --> ActNode["<activity>"]
Manifest --> FCMNode["<service>"]
AppNode --> AppAttrs["Attributes:<br/>- name<br/>- icon<br/>- label<br/>- theme"]
AppNode --> PermNode["<uses-permission>"]
ActNode --> ActAttrs["Attributes:<br/>- name<br/>- exported<br/>- softInputMode"]
ActNode --> IntentNode["<intent-filter><br/>MAIN + LAUNCHER</intent-filter>"]
FCMNode --> FCMAttrs["Attributes:<br/>- name<br/>- exported"]
FCMNode --> FCMIntent["<intent-filter><br/>MESSAGING_EVENT</intent-filter>"]
PermNode --> NetPerm["INTERNET"]
PermNode --> StatePerm["ACCESS_NETWORK_STATE"]
```

**Diagram sources**
- [AndroidManifest.xml:8-37](file://app/src/main/AndroidManifest.xml#L8-L37)

The manifest configuration includes essential permissions for network connectivity and Firebase Cloud Messaging integration. The main activity is configured as the launcher activity with appropriate window behavior for modern Android applications.

**Section sources**
- [AndroidManifest.xml:1-40](file://app/src/main/AndroidManifest.xml#L1-L40)

## Dependency Analysis
The app module maintains strategic dependencies on core modules and feature modules while keeping the coupling minimal and manageable.

```mermaid
graph TB
subgraph "App Module Dependencies"
AppDeps["app/build.gradle.kts"]
subgraph "Feature Dependencies"
AuthDep["feature-auth"]
MomentsDep["feature-moments"]
EventsDep["feature-events"]
HeritageDep["feature-heritage"]
ProfileDep["feature-profile"]
NotificationsDep["feature-notifications"]
end
subgraph "Core Dependencies"
CommonDep["core-common"]
ModelDep["core-model"]
DomainDep["core-domain"]
DataDep["core-data"]
FirebaseDep["core-firebase"]
SearchDep["core-search"]
MediaDep["core-media"]
UIDep["core-ui"]
end
end
AppDeps --> AuthDep
AppDeps --> MomentsDep
AppDeps --> EventsDep
AppDeps --> HeritageDep
AppDeps --> ProfileDep
AppDeps --> NotificationsDep
AppDeps --> CommonDep
AppDeps --> ModelDep
AppDeps --> DomainDep
AppDeps --> DataDep
AppDeps --> FirebaseDep
AppDeps --> SearchDep
AppDeps --> MediaDep
AppDeps --> UIDep
```

**Diagram sources**
- [build.gradle.kts:35-52](file://app/build.gradle.kts#L35-L52)
- [settings.gradle.kts:20-39](file://settings.gradle.kts#L20-L39)

The dependency graph shows the app module's integration with all feature modules and core infrastructure modules. This structure enables independent development and testing of individual features while maintaining cohesive application functionality.

**Section sources**
- [build.gradle.kts:35-52](file://app/build.gradle.kts#L35-L52)
- [settings.gradle.kts:20-39](file://settings.gradle.kts#L20-L39)

## Performance Considerations
The app module implements several performance optimization strategies:

- **Lazy Initialization**: Navigation components are initialized lazily through Compose's remember mechanism
- **Singleton Scope**: Hilt provides singleton-scoped dependencies to minimize object creation overhead
- **Edge-to-Edge Rendering**: Modern UI rendering reduces unnecessary layout passes
- **Modular Architecture**: Feature isolation prevents unnecessary module loading

## Troubleshooting Guide
Common issues and their solutions:

### Navigation Issues
- **Route Not Found**: Ensure all route objects are properly annotated with `@Serializable`
- **Navigation Graph Errors**: Verify that all feature graphs are properly integrated into AppNavHost
- **Back Stack Management**: Use appropriate navigation options for popUpTo operations

### Dependency Injection Problems
- **Missing Qualifiers**: Ensure dispatcher providers use correct qualifier annotations
- **Scope Mismatches**: Verify singleton scope usage for application-wide dependencies
- **Component Initialization**: Check that `@HiltAndroidApp` is present on the application class

### Build Configuration Issues
- **Version Conflicts**: Review Gradle version catalogs for dependency conflicts
- **Plugin Configuration**: Verify build logic plugins are properly applied
- **Module Dependencies**: Ensure all required modules are included in settings.gradle.kts

**Section sources**
- [AuthNavigation.kt:20-48](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/navigation/AuthNavigation.kt#L20-L48)
- [DispatcherModule.kt:13-26](file://app/src/main/java/com/uit20years/app/di/DispatcherModule.kt#L13-L26)

## Conclusion
The app module successfully implements a modern Android application architecture with clear separation of concerns, robust dependency injection, and scalable navigation patterns. The modular design enables independent development of features while maintaining cohesive application functionality. The implementation follows Android best practices with edge-to-edge support, type-safe navigation, and comprehensive dependency management.

## Appendices

### Build Configuration Reference
The app module uses a comprehensive build configuration that leverages Gradle's convention plugins and version catalogs for consistent dependency management.

**Section sources**
- [build.gradle.kts:1-82](file://app/build.gradle.kts#L1-L82)
- [libs.versions.toml:1-103](file://gradle/libs.versions.toml#L1-L103)

### Extension Guidelines
To extend the navigation system and add new routes following established patterns:

1. **Define Route Objects**: Create serializable route objects following the existing pattern
2. **Create Navigation Graph**: Implement feature-specific navigation graphs using NavGraphBuilder extension functions
3. **Integrate into AppNavHost**: Add the new graph to the main navigation host
4. **Update Route Definitions**: Extend the Route sealed class if needed
5. **Provide Dependencies**: Add any required dependencies to the DI module
# Feature Modules

<cite>
**Referenced Files in This Document**
- [MainActivity.kt](file://app/src/main/java/com/uit20years/app/MainActivity.kt)
- [AppNavHost.kt](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt)
- [Route.kt](file://app/src/main/java/com/uit20years/app/navigation/Route.kt)
- [AuthNavigation.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/navigation/AuthNavigation.kt)
- [LoginScreen.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginScreen.kt)
- [LoginViewModel.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt)
- [LoginEvent.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginEvent.kt)
- [LoginUiState.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginUiState.kt)
- [RegisterScreen.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterScreen.kt)
- [RegisterViewModel.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt)
- [RegisterEvent.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterEvent.kt)
- [RegisterUiState.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterUiState.kt)
- [LoginUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt)
- [RegisterUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt)
- [AuthRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt)
- [FirebaseAuthService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt)
- [EventsNavigation.kt](file://feature/feature-events/src/main/java/com/uit20years/feature/events/navigation/EventsNavigation.kt)
- [HeritageNavigation.kt](file://feature/feature-heritage/src/main/java/com/uit20years/feature/heritage/navigation/HeritageNavigation.kt)
- [MomentsNavigation.kt](file://feature/feature-moments/src/main/java/com/uit20years/feature/moments/navigation/MomentsNavigation.kt)
- [NotificationsNavigation.kt](file://feature/feature-notifications/src/main/java/com/uit20years/feature/notifications/navigation/NotificationsNavigation.kt)
- [ProfileNavigation.kt](file://feature/feature-profile/src/main/java/com/uit20years/feature/profile/navigation/ProfileNavigation.kt)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document explains the feature modules that implement specific application functionality in the UIT20Years Android application. It covers the authentication feature (login and registration), social feed feature (moments), events management feature, heritage timeline feature, user profile feature, and notifications feature. It also documents the navigation architecture using type-safe routes, the implementation of each feature's screens and view models, and how features integrate with the core modules. The app module acts as the application shell, hosting the navigation host and coordinating feature graphs. Finally, it outlines stub features that are placeholders and provides guidance for extending existing features and adding new ones following established patterns.

## Project Structure
The project follows a modular architecture:
- app: Application shell that hosts the navigation and UI shell.
- feature/*: Feature modules that encapsulate UI, navigation, and presentation logic per feature.
- core/*: Shared libraries for domain logic, repositories, data transfer objects, Firebase services, media utilities, and UI components.

```mermaid
graph TB
subgraph "App Shell"
MainActivity["MainActivity"]
AppNavHost["AppNavHost"]
Route["Route (type-safe)"]
end
subgraph "Features"
Auth["feature-auth"]
Moments["feature-moments"]
Events["feature-events"]
Heritage["feature-heritage"]
Notifications["feature-notifications"]
Profile["feature-profile"]
end
subgraph "Core"
Domain["core-domain"]
Data["core-data"]
Firebase["core-firebase"]
UI["core-ui"]
end
MainActivity --> AppNavHost
AppNavHost --> Route
AppNavHost --> Auth
AppNavHost --> Moments
AppNavHost --> Events
AppNavHost --> Heritage
AppNavHost --> Notifications
AppNavHost --> Profile
Auth --> Domain
Domain --> Data
Data --> Firebase
Auth --> UI
Moments --> UI
Events --> UI
Heritage --> UI
Notifications --> UI
Profile --> UI
```

**Diagram sources**
- [MainActivity.kt:14-27](file://app/src/main/java/com/uit20years/app/MainActivity.kt#L14-L27)
- [AppNavHost.kt:10-25](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L10-L25)
- [Route.kt:5-12](file://app/src/main/java/com/uit20years/app/navigation/Route.kt#L5-L12)
- [AuthNavigation.kt:20-48](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/navigation/AuthNavigation.kt#L20-L48)
- [EventsNavigation.kt:13-21](file://feature/feature-events/src/main/java/com/uit20years/feature/events/navigation/EventsNavigation.kt#L13-L21)
- [HeritageNavigation.kt:13-21](file://feature/feature-heritage/src/main/java/com/uit20years/feature/heritage/navigation/HeritageNavigation.kt#L13-L21)
- [MomentsNavigation.kt:13-21](file://feature/feature-moments/src/main/java/com/uit20years/feature/moments/navigation/MomentsNavigation.kt#L13-L21)
- [NotificationsNavigation.kt:13-21](file://feature/feature-notifications/src/main/java/com/uit20years/feature/notifications/navigation/NotificationsNavigation.kt#L13-L21)
- [ProfileNavigation.kt:13-21](file://feature/feature-profile/src/main/java/com/uit20years/feature/profile/navigation/ProfileNavigation.kt#L13-L21)

**Section sources**
- [MainActivity.kt:14-27](file://app/src/main/java/com/uit20years/app/MainActivity.kt#L14-L27)
- [AppNavHost.kt:10-25](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L10-L25)
- [Route.kt:5-12](file://app/src/main/java/com/uit20years/app/navigation/Route.kt#L5-L12)

## Core Components
- App shell and navigation host:
  - MainActivity sets up the UI shell and hosts AppNavHost.
  - AppNavHost configures the NavHost with a start destination and registers feature graphs.
  - Route defines type-safe sealed route classes for navigation.
- Authentication feature:
  - AuthNavigation defines the Auth graph with LoginRoute and RegisterRoute.
  - LoginScreen and RegisterScreen render forms and delegate actions to view models.
  - LoginViewModel and RegisterViewModel manage UI state, validation, and effects.
  - LoginUseCase and RegisterUseCase orchestrate repository calls for authentication.
  - AuthRepositoryImpl integrates with FirebaseAuthService for Firebase operations.
- Other features (placeholders):
  - Events, Heritage, Moments, Notifications, and Profile define typed routes and navigation builders but render placeholder screens.

**Section sources**
- [MainActivity.kt:14-27](file://app/src/main/java/com/uit20years/app/MainActivity.kt#L14-L27)
- [AppNavHost.kt:10-25](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L10-L25)
- [Route.kt:5-12](file://app/src/main/java/com/uit20years/app/navigation/Route.kt#L5-L12)
- [AuthNavigation.kt:20-48](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/navigation/AuthNavigation.kt#L20-L48)
- [LoginScreen.kt:30-126](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginScreen.kt#L30-L126)
- [RegisterScreen.kt:30-144](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterScreen.kt#L30-L144)
- [LoginViewModel.kt:20-100](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L20-L100)
- [RegisterViewModel.kt:20-140](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt#L20-L140)
- [LoginUseCase.kt:9-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L9-L14)
- [RegisterUseCase.kt:9-17](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt#L9-L17)
- [AuthRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt)
- [FirebaseAuthService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt)
- [EventsNavigation.kt:13-21](file://feature/feature-events/src/main/java/com/uit20years/feature/events/navigation/EventsNavigation.kt#L13-L21)
- [HeritageNavigation.kt:13-21](file://feature/feature-heritage/src/main/java/com/uit20years/feature/heritage/navigation/HeritageNavigation.kt#L13-L21)
- [MomentsNavigation.kt:13-21](file://feature/feature-moments/src/main/java/com/uit20years/feature/moments/navigation/MomentsNavigation.kt#L13-L21)
- [NotificationsNavigation.kt:13-21](file://feature/feature-notifications/src/main/java/com/uit20years/feature/notifications/navigation/NotificationsNavigation.kt#L13-L21)
- [ProfileNavigation.kt:13-21](file://feature/feature-profile/src/main/java/com/uit20years/feature/profile/navigation/ProfileNavigation.kt#L13-L21)

## Architecture Overview
The app uses Compose Navigation with type-safe routes via Kotlin serialization. The app module delegates navigation to feature graphs, each exposing a typed route and a navigation builder. Authentication is wired as the initial destination. Other features are registered as stubs and can be integrated later.

```mermaid
sequenceDiagram
participant Activity as "MainActivity"
participant NavHost as "AppNavHost"
participant AuthGraph as "Auth Graph"
participant Login as "LoginScreen"
participant VM as "LoginViewModel"
participant UseCase as "LoginUseCase"
participant Repo as "AuthRepositoryImpl"
participant Firebase as "FirebaseAuthService"
Activity->>NavHost : "Render navigation host"
NavHost->>AuthGraph : "Navigate to AuthRoute"
AuthGraph->>Login : "Show LoginScreen"
Login->>VM : "onEvent(Submit)"
VM->>UseCase : "Invoke login(email,password)"
UseCase->>Repo : "login(email,password)"
Repo->>Firebase : "Authenticate"
Firebase-->>Repo : "Auth result"
Repo-->>UseCase : "Flow<UitResult<User>>"
UseCase-->>VM : "Flow<UitResult<User>>"
VM-->>Login : "effects(NavigateToHome)"
Login-->>NavHost : "Navigate to 'home'"
```

**Diagram sources**
- [MainActivity.kt:14-27](file://app/src/main/java/com/uit20years/app/MainActivity.kt#L14-L27)
- [AppNavHost.kt:10-25](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L10-L25)
- [AuthNavigation.kt:20-48](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/navigation/AuthNavigation.kt#L20-L48)
- [LoginScreen.kt:30-126](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginScreen.kt#L30-L126)
- [LoginViewModel.kt:20-100](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L20-L100)
- [LoginUseCase.kt:9-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L9-L14)
- [AuthRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt)
- [FirebaseAuthService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt)

## Detailed Component Analysis

### Authentication Feature
The authentication feature implements login and registration flows with a unidirectional data flow pattern:
- UI state is managed in view models using StateFlow.
- Validation occurs in the view model prior to invoking use cases.
- Effects are emitted via channels to trigger navigation and side effects.
- Use cases delegate to repositories, which integrate with Firebase services.

```mermaid
classDiagram
class LoginViewModel {
+uiState : StateFlow<LoginUiState>
+effects : Flow<LoginEffect>
+onEvent(event)
-validateAndLogin()
-login(email, password)
}
class RegisterViewModel {
+uiState : StateFlow<RegisterUiState>
+effects : Flow<RegisterEffect>
+onEvent(event)
-validateAndRegister()
-register(email, password, displayName)
}
class LoginUseCase {
+invoke(email, password) : Flow<UitResult<User>>
}
class RegisterUseCase {
+invoke(email, password, displayName) : Flow<UitResult<User>>
}
class AuthRepositoryImpl {
+login(email, password) : Flow<UitResult<User>>
+register(email, password, displayName) : Flow<UitResult<User>>
}
LoginViewModel --> LoginUseCase : "invokes"
RegisterViewModel --> RegisterUseCase : "invokes"
LoginUseCase --> AuthRepositoryImpl : "calls"
RegisterUseCase --> AuthRepositoryImpl : "calls"
```

**Diagram sources**
- [LoginViewModel.kt:20-100](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L20-L100)
- [RegisterViewModel.kt:20-140](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt#L20-L140)
- [LoginUseCase.kt:9-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L9-L14)
- [RegisterUseCase.kt:9-17](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt#L9-L17)
- [AuthRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt)

```mermaid
sequenceDiagram
participant Screen as "LoginScreen"
participant VM as "LoginViewModel"
participant UC as "LoginUseCase"
participant Repo as "AuthRepositoryImpl"
participant FB as "FirebaseAuthService"
Screen->>VM : "Submit"
VM->>VM : "validateAndLogin()"
VM->>UC : "invoke(email,password)"
UC->>Repo : "login(email,password)"
Repo->>FB : "authenticate"
FB-->>Repo : "result"
Repo-->>UC : "Flow<UitResult<User>>"
UC-->>VM : "Flow<UitResult<User>>"
VM-->>Screen : "effects(NavigateToHome)"
```

**Diagram sources**
- [LoginScreen.kt:30-126](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginScreen.kt#L30-L126)
- [LoginViewModel.kt:20-100](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L20-L100)
- [LoginUseCase.kt:9-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L9-L14)
- [AuthRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt)
- [FirebaseAuthService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt)

```mermaid
flowchart TD
Start(["Login Submit"]) --> Validate["Validate Email & Password"]
Validate --> Valid{"Valid?"}
Valid --> |No| ShowErrors["Set error messages<br/>and flags"]
Valid --> |Yes| CallUseCase["Call LoginUseCase"]
CallUseCase --> Loading["Emit Loading"]
Loading --> Result{"Success or Error?"}
Result --> |Success| EmitEffect["Emit NavigateToHome"]
Result --> |Error| ShowSnackbar["Show error via Snackbar"]
EmitEffect --> End(["Navigate to Home"])
ShowSnackbar --> End
ShowErrors --> End
```

**Diagram sources**
- [LoginViewModel.kt:48-94](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L48-L94)
- [LoginScreen.kt:39-54](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginScreen.kt#L39-L54)

Key implementation patterns:
- View models expose StateFlow for UI state and a channel-based effects stream.
- Screens collect state with lifecycle-aware collection and react to effects.
- Validation is performed in the view model before invoking use cases.
- Use cases return Flow<UitResult<T>> to propagate loading, success, and error states.

**Section sources**
- [AuthNavigation.kt:20-48](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/navigation/AuthNavigation.kt#L20-L48)
- [LoginScreen.kt:30-126](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginScreen.kt#L30-L126)
- [LoginViewModel.kt:20-100](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L20-L100)
- [LoginEvent.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginEvent.kt)
- [LoginUiState.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginUiState.kt)
- [RegisterScreen.kt:30-144](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterScreen.kt#L30-L144)
- [RegisterViewModel.kt:20-140](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt#L20-L140)
- [RegisterEvent.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterEvent.kt)
- [RegisterUiState.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterUiState.kt)
- [LoginUseCase.kt:9-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L9-L14)
- [RegisterUseCase.kt:9-17](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt#L9-L17)
- [AuthRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt)
- [FirebaseAuthService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt)

### Social Feed (Moments) Feature
- Navigation graph is defined with a typed route and a screen composable.
- Placeholder screen is rendered; future implementation will include posts, reactions, and comments.

Integration points:
- Follows the same pattern as authentication: typed route, navigation builder, and screen.

**Section sources**
- [MomentsNavigation.kt:13-21](file://feature/feature-moments/src/main/java/com/uit20years/feature/moments/navigation/MomentsNavigation.kt#L13-L21)

### Events Management Feature
- Navigation graph is defined with a typed route and a screen composable.
- Placeholder screen is rendered; future implementation will include event creation, editing, and listing.

**Section sources**
- [EventsNavigation.kt:13-21](file://feature/feature-events/src/main/java/com/uit20years/feature/events/navigation/EventsNavigation.kt#L13-L21)

### Heritage Timeline Feature
- Navigation graph is defined with a typed route and a screen composable.
- Placeholder screen is rendered; future implementation will include timeline rendering and item interactions.

**Section sources**
- [HeritageNavigation.kt:13-21](file://feature/feature-heritage/src/main/java/com/uit20years/feature/heritage/navigation/HeritageNavigation.kt#L13-L21)

### User Profile Feature
- Navigation graph is defined with a typed route and a screen composable.
- Placeholder screen is rendered; future implementation will include profile editing and settings.

**Section sources**
- [ProfileNavigation.kt:13-21](file://feature/feature-profile/src/main/java/com/uit20years/feature/profile/navigation/ProfileNavigation.kt#L13-L21)

### Notifications Feature
- Navigation graph is defined with a typed route and a screen composable.
- Placeholder screen is rendered; future implementation will include notification list and actions.

**Section sources**
- [NotificationsNavigation.kt:13-21](file://feature/feature-notifications/src/main/java/com/uit20years/feature/notifications/navigation/NotificationsNavigation.kt#L13-L21)

### Navigation Architecture and Routing
Type-safe routing is achieved via Kotlin serialization on sealed route classes:
- Route defines top-level destinations (Auth, Home).
- Each feature defines its own typed route and a navigation builder extension.
- AppNavHost registers feature graphs and sets the initial destination.

```mermaid
classDiagram
class Route {
<<sealed>>
}
class AuthRoute
class Home
Route <|-- AuthRoute
Route <|-- Home
class AuthNavigation {
+authGraph(navController)
}
class EventsNavigation {
+eventsGraph(navController)
}
class HeritageNavigation {
+heritageGraph(navController)
}
class MomentsNavigation {
+momentsGraph(navController)
}
class NotificationsNavigation {
+notificationsGraph(navController)
}
class ProfileNavigation {
+profileGraph(navController)
}
AuthNavigation --> AuthRoute : "navigation<AuthRoute>()"
EventsNavigation --> EventsRoute : "navigation<EventsRoute>()"
HeritageNavigation --> HeritageRoute : "navigation<HeritageRoute>()"
MomentsNavigation --> MomentsRoute : "navigation<MomentsRoute>()"
NotificationsNavigation --> NotificationsRoute : "navigation<NotificationsRoute>()"
ProfileNavigation --> ProfileRoute : "navigation<ProfileRoute>()"
```

**Diagram sources**
- [Route.kt:5-12](file://app/src/main/java/com/uit20years/app/navigation/Route.kt#L5-L12)
- [AuthNavigation.kt:11-18](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/navigation/AuthNavigation.kt#L11-L18)
- [EventsNavigation.kt:10-11](file://feature/feature-events/src/main/java/com/uit20years/feature/events/navigation/EventsNavigation.kt#L10-L11)
- [HeritageNavigation.kt:10-11](file://feature/feature-heritage/src/main/java/com/uit20years/feature/heritage/navigation/HeritageNavigation.kt#L10-L11)
- [MomentsNavigation.kt:10-11](file://feature/feature-moments/src/main/java/com/uit20years/feature/moments/navigation/MomentsNavigation.kt#L10-L11)
- [NotificationsNavigation.kt:10-11](file://feature/feature-notifications/src/main/java/com/uit20years/feature/notifications/navigation/NotificationsNavigation.kt#L10-L11)
- [ProfileNavigation.kt:10-11](file://feature/feature-profile/src/main/java/com/uit20years/feature/profile/navigation/ProfileNavigation.kt#L10-L11)

**Section sources**
- [Route.kt:5-12](file://app/src/main/java/com/uit20years/app/navigation/Route.kt#L5-L12)
- [AppNavHost.kt:10-25](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L10-L25)
- [AuthNavigation.kt:20-48](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/navigation/AuthNavigation.kt#L20-L48)
- [EventsNavigation.kt:13-21](file://feature/feature-events/src/main/java/com/uit20years/feature/events/navigation/EventsNavigation.kt#L13-L21)
- [HeritageNavigation.kt:13-21](file://feature/feature-heritage/src/main/java/com/uit20years/feature/heritage/navigation/HeritageNavigation.kt#L13-L21)
- [MomentsNavigation.kt:13-21](file://feature/feature-moments/src/main/java/com/uit20years/feature/moments/navigation/MomentsNavigation.kt#L13-L21)
- [NotificationsNavigation.kt:13-21](file://feature/feature-notifications/src/main/java/com/uit20years/feature/notifications/navigation/NotificationsNavigation.kt#L13-L21)
- [ProfileNavigation.kt:13-21](file://feature/feature-profile/src/main/java/com/uit20years/feature/profile/navigation/ProfileNavigation.kt#L13-L21)

## Dependency Analysis
- App shell depends on feature graphs for navigation.
- Feature modules depend on core-domain use cases.
- Use cases depend on core-data repositories.
- Repositories integrate with core-firebase services.
- All features share core-ui components for consistent UX.

```mermaid
graph LR
MainActivity --> AppNavHost
AppNavHost --> AuthGraph["Auth Graph"]
AppNavHost --> MomentsGraph["Moments Graph"]
AppNavHost --> EventsGraph["Events Graph"]
AppNavHost --> HeritageGraph["Heritage Graph"]
AppNavHost --> NotificationsGraph["Notifications Graph"]
AppNavHost --> ProfileGraph["Profile Graph"]
AuthGraph --> LoginVM["LoginViewModel"]
AuthGraph --> RegisterVM["RegisterViewModel"]
LoginVM --> LoginUC["LoginUseCase"]
RegisterVM --> RegisterUC["RegisterUseCase"]
LoginUC --> AuthRepo["AuthRepositoryImpl"]
RegisterUC --> AuthRepo
AuthRepo --> FirebaseAuth["FirebaseAuthService"]
AuthGraph --> UI["core-ui components"]
MomentsGraph --> UI
EventsGraph --> UI
HeritageGraph --> UI
NotificationsGraph --> UI
ProfileGraph --> UI
```

**Diagram sources**
- [MainActivity.kt:14-27](file://app/src/main/java/com/uit20years/app/MainActivity.kt#L14-L27)
- [AppNavHost.kt:10-25](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L10-L25)
- [AuthNavigation.kt:20-48](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/navigation/AuthNavigation.kt#L20-L48)
- [LoginViewModel.kt:20-100](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L20-L100)
- [RegisterViewModel.kt:20-140](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt#L20-L140)
- [LoginUseCase.kt:9-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L9-L14)
- [RegisterUseCase.kt:9-17](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt#L9-L17)
- [AuthRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt)
- [FirebaseAuthService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt)

**Section sources**
- [MainActivity.kt:14-27](file://app/src/main/java/com/uit20years/app/MainActivity.kt#L14-L27)
- [AppNavHost.kt:10-25](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L10-L25)
- [AuthNavigation.kt:20-48](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/navigation/AuthNavigation.kt#L20-L48)
- [LoginUseCase.kt:9-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L9-L14)
- [RegisterUseCase.kt:9-17](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt#L9-L17)
- [AuthRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt)
- [FirebaseAuthService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt)

## Performance Considerations
- Prefer StateFlow for UI state to avoid redundant recompositions.
- Use lifecycle-aware state collection to prevent leaks and unnecessary work.
- Emit effects via channels to decouple UI actions from navigation and side effects.
- Keep validation logic in view models to minimize UI thread work.
- Use Flow<UitResult<T>> to unify loading, success, and error handling across features.

## Troubleshooting Guide
Common issues and resolutions:
- Navigation does not occur after login:
  - Verify that LoginScreen reacts to LoginEffect.NavigateToHome and triggers the provided callback.
  - Ensure AppNavHost navigates to the "home" destination and pops the Auth graph.
- Snackbar errors not shown:
  - Confirm that screens collect uiState.errorMessage and show snackbars via SnackbarHostState.
  - Ensure the view model clears error messages after displaying them.
- Validation not applied:
  - Check that view models update error flags and messages during validation.
  - Ensure form fields reflect error states via isError flags.
- Feature screens appear blank:
  - Confirm that feature graphs are registered in AppNavHost and typed routes are properly defined.

**Section sources**
- [LoginScreen.kt:39-54](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginScreen.kt#L39-L54)
- [LoginViewModel.kt:48-94](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L48-L94)
- [AuthNavigation.kt:29-33](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/navigation/AuthNavigation.kt#L29-L33)
- [AppNavHost.kt:20-23](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L20-L23)

## Conclusion
The UIT20Years application employs a modular, type-safe navigation architecture with clear separation of concerns across app shell, features, and core modules. The authentication feature demonstrates a robust MVVM pattern with validation, use cases, and repository integration. Other features are structured as stubs ready for implementation following the same patterns. Extending features and adding new ones requires defining typed routes, implementing navigation builders, creating screens and view models, wiring use cases, and integrating with core repositories and Firebase services.

## Appendices

### Extending Existing Features
- Add or modify screens under feature/*/screenName/ with appropriate view models.
- Define or update typed routes and navigation builders in feature/*/navigation/.
- Wire use cases to repositories and integrate Firebase services as needed.
- Follow the MVVM pattern: StateFlow for UI state, effects channel for navigation, and validation in view models.

### Adding New Features
- Create a new feature module with navigation, screen, and view model packages.
- Define a typed route and a navigation builder extension.
- Register the feature graph in AppNavHost and set its destination.
- Implement screens using core-ui components for consistency.
- Integrate with core-domain use cases and core-data repositories.
# Troubleshooting and FAQ

<cite>
**Referenced Files in This Document**
- [build.gradle.kts](file://build.gradle.kts)
- [settings.gradle.kts](file://settings.gradle.kts)
- [gradle/libs.versions.toml](file://gradle/libs.versions.toml)
- [app/build.gradle.kts](file://app/build.gradle.kts)
- [app/src/main/AndroidManifest.xml](file://app/src/main/AndroidManifest.xml)
- [app/src/main/java/com/uit20years/app/UIT20YearsApplication.kt](file://app/src/main/java/com/uit20years/app/UIT20YearsApplication.kt)
- [app/src/main/java/com/uit20years/app/MainActivity.kt](file://app/src/main/java/com/uit20years/app/MainActivity.kt)
- [app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt)
- [app/src/main/java/com/uit20years/app/navigation/Route.kt](file://app/src/main/java/com/uit20years/app/navigation/Route.kt)
- [core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt)
- [core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt)
- [core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt)
- [core/core-common/src/main/kotlin/com/uit20years/core/common/constants/AppConstants.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/constants/AppConstants.kt)
- [feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt)
- [feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document provides comprehensive troubleshooting guidance and frequently asked questions for the UIT20Years Android application. It focuses on common build issues (Gradle sync, dependency conflicts, version compatibility), Firebase configuration pitfalls (missing google-services.json, authentication failures, Firestore connectivity), Hilt dependency injection errors, navigation issues, runtime exceptions, debugging techniques for ViewModels and repositories, performance and memory optimization, and practical diagnostic steps.

## Project Structure
The project follows a modular Gradle setup with a shared build-logic convention plugin and a multi-module architecture:
- Root build plugins and version catalog define platform versions and plugin IDs.
- Settings include the app module and all core and feature modules.
- The app module aggregates feature and core modules and applies Compose, Hilt, KSP, Kotlin serialization, and Google Services plugins.
- Modules are organized by domain and UI concerns, enabling separation of concerns and testability.

```mermaid
graph TB
subgraph "Root Build"
RBuild["build.gradle.kts"]
RSettings["settings.gradle.kts"]
VCatalog["gradle/libs.versions.toml"]
end
subgraph "App Module"
AppGradle["app/build.gradle.kts"]
AppManifest["AndroidManifest.xml"]
AppMain["MainActivity.kt"]
AppApp["UIT20YearsApplication.kt"]
AppNav["AppNavHost.kt"]
AppRoute["Route.kt"]
end
subgraph "Core Modules"
CoreData["core-data/DataModule.kt"]
CoreFirebase["core-firebase/FirebaseModule.kt"]
CoreCommon["core-common/AppConstants.kt"]
end
subgraph "Feature Modules"
AuthVM["feature-auth/LoginViewModel.kt"]
RegVM["feature-auth/RegisterViewModel.kt"]
end
RBuild --> AppGradle
RSettings --> AppGradle
VCatalog --> AppGradle
AppGradle --> AppManifest
AppGradle --> AppMain
AppMain --> AppNav
AppNav --> AppRoute
AppGradle --> CoreData
AppGradle --> CoreFirebase
AppGradle --> CoreCommon
AppGradle --> AuthVM
AppGradle --> RegVM
```

**Diagram sources**
- [build.gradle.kts:1-12](file://build.gradle.kts#L1-L12)
- [settings.gradle.kts:1-39](file://settings.gradle.kts#L1-L39)
- [gradle/libs.versions.toml:1-103](file://gradle/libs.versions.toml#L1-L103)
- [app/build.gradle.kts:1-82](file://app/build.gradle.kts#L1-L82)
- [app/src/main/AndroidManifest.xml:1-40](file://app/src/main/AndroidManifest.xml#L1-L40)
- [app/src/main/java/com/uit20years/app/MainActivity.kt:1-28](file://app/src/main/java/com/uit20years/app/MainActivity.kt#L1-L28)
- [app/src/main/java/com/uit20years/app/UIT20YearsApplication.kt:1-8](file://app/src/main/java/com/uit20years/app/UIT20YearsApplication.kt#L1-L8)
- [app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt:1-26](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L1-L26)
- [app/src/main/java/com/uit20years/app/navigation/Route.kt:1-13](file://app/src/main/java/com/uit20years/app/navigation/Route.kt#L1-L13)
- [core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt:1-42](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt#L1-L42)
- [core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt:1-28](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt#L1-L28)
- [core/core-common/src/main/kotlin/com/uit20years/core/common/constants/AppConstants.kt:1-13](file://core/core-common/src/main/kotlin/com/uit20years/core/common/constants/AppConstants.kt#L1-L13)
- [feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt:1-100](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L1-L100)
- [feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt:1-140](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt#L1-L140)

**Section sources**
- [build.gradle.kts:1-12](file://build.gradle.kts#L1-L12)
- [settings.gradle.kts:1-39](file://settings.gradle.kts#L1-L39)
- [gradle/libs.versions.toml:1-103](file://gradle/libs.versions.toml#L1-L103)
- [app/build.gradle.kts:1-82](file://app/build.gradle.kts#L1-L82)

## Core Components
- Application bootstrap and DI: The application class is annotated for Hilt initialization, and the main activity is marked as an Android entry point for Hilt.
- Navigation: A single NavHost starts at the authentication route and integrates feature graphs.
- Authentication repositories: The repository layer orchestrates Firebase Auth and Firestore to manage user lifecycle operations.
- Firebase services: Firebase services are provided as singletons via Hilt in the Firebase module.
- Version catalog: Centralized versions for AGP, Kotlin, Compose BOM, Hilt, Navigation, Firebase BOM, coroutines, and testing libraries.

Key implementation references:
- [UIT20YearsApplication.kt:6-7](file://app/src/main/java/com/uit20years/app/UIT20YearsApplication.kt#L6-L7)
- [MainActivity.kt:14-14](file://app/src/main/java/com/uit20years/app/MainActivity.kt#L14-L14)
- [AppNavHost.kt:14-18](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L14-L18)
- [DataModule.kt:24-41](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt#L24-L41)
- [FirebaseModule.kt:16-26](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt#L16-L26)
- [libs.versions.toml:1-103](file://gradle/libs.versions.toml#L1-L103)

**Section sources**
- [app/src/main/java/com/uit20years/app/UIT20YearsApplication.kt:1-8](file://app/src/main/java/com/uit20years/app/UIT20YearsApplication.kt#L1-L8)
- [app/src/main/java/com/uit20years/app/MainActivity.kt:1-28](file://app/src/main/java/com/uit20years/app/MainActivity.kt#L1-L28)
- [app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt:1-26](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L1-L26)
- [core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt:1-42](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt#L1-L42)
- [core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt:1-28](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt#L1-L28)
- [gradle/libs.versions.toml:1-103](file://gradle/libs.versions.toml#L1-L103)

## Architecture Overview
The app uses a layered architecture:
- Presentation layer: Compose UI with ViewModels and navigation.
- Domain layer: Use cases encapsulate business logic.
- Data layer: Repositories implement domain interfaces and coordinate Firebase services.
- Infrastructure: Firebase services (Auth, Firestore, Storage) provided via Hilt.

```mermaid
graph TB
UI["MainActivity<br/>AppNavHost"] --> VM["LoginViewModel / RegisterViewModel"]
VM --> UC["Auth UseCases"]
UC --> Repo["AuthRepositoryImpl"]
Repo --> FAuth["FirebaseAuthService"]
Repo --> FStore["FirestoreService"]
Repo --> FStorage["FirebaseStorageService"]
Repo --> FProv["FirebaseModule (Hilt)"]
Repo --> DBind["DataModule (Hilt)"]
FProv --> FAuth
FProv --> FStore
FProv --> FStorage
DBind --> Repo
```

**Diagram sources**
- [app/src/main/java/com/uit20years/app/MainActivity.kt:10-25](file://app/src/main/java/com/uit20years/app/MainActivity.kt#L10-L25)
- [app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt:10-24](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L10-L24)
- [feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt:20-23](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L20-L23)
- [feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt:20-23](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt#L20-L23)
- [core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt:24-27](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L24-L27)
- [core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt:12-27](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt#L12-L27)
- [core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt:20-41](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt#L20-L41)

## Detailed Component Analysis

### Authentication Flow (ViewModel to Repository to Firebase)
This sequence illustrates how login triggers repository calls to Firebase services and emits results to the UI.

```mermaid
sequenceDiagram
participant UI as "Login Screen"
participant VM as "LoginViewModel"
participant UC as "LoginUseCase"
participant Repo as "AuthRepositoryImpl"
participant FAuth as "FirebaseAuthService"
participant FStore as "FirestoreService"
UI->>VM : "Submit"
VM->>UC : "invoke(email,password)"
UC->>Repo : "login(email,password)"
Repo->>FAuth : "signInWithEmail"
FAuth-->>Repo : "AuthResult"
Repo->>FStore : "getDocument(users/{uid})"
FStore-->>Repo : "DocumentSnapshot"
Repo-->>UC : "UitResult<User>"
UC-->>VM : "UitResult<User>"
VM-->>UI : "Show loading/success/error"
```

**Diagram sources**
- [feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt:72-94](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L72-L94)
- [core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt:29-55](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L29-L55)
- [core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt:16-22](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt#L16-L22)

**Section sources**
- [feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt:1-100](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L1-L100)
- [core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt:1-147](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L1-L147)

### Navigation Flow
The main activity hosts a NavHost that starts at the authentication route and integrates feature graphs.

```mermaid
flowchart TD
Start(["MainActivity onCreate"]) --> SetContent["Set Compose Content"]
SetContent --> NavHost["NavHost(startDestination=AuthRoute)"]
NavHost --> AuthGraph["authGraph(navController)"]
AuthGraph --> HomePlaceholder["composable('home') placeholder"]
HomePlaceholder --> End(["AppNavHost ready"])
```

**Diagram sources**
- [app/src/main/java/com/uit20years/app/MainActivity.kt:15-26](file://app/src/main/java/com/uit20years/app/MainActivity.kt#L15-L26)
- [app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt:11-25](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L11-L25)

**Section sources**
- [app/src/main/java/com/uit20years/app/MainActivity.kt:1-28](file://app/src/main/java/com/uit20years/app/MainActivity.kt#L1-L28)
- [app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt:1-26](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L1-L26)

## Dependency Analysis
- Plugin and library versions are centralized in the version catalog, ensuring consistent versions across modules.
- The app module depends on core and feature modules and applies Compose, Hilt, KSP, Kotlin serialization, and Google Services plugins.
- Hilt modules bind domain repositories to their implementations and provide Firebase singletons.

```mermaid
graph LR
VCat["libs.versions.toml"] --> AppGradle["app/build.gradle.kts"]
AppGradle --> HiltDep["Hilt deps"]
AppGradle --> FirebaseDep["Firebase BOM + KTX"]
AppGradle --> ComposeDep["Compose BOM + Lifecycle"]
AppGradle --> CoreData["core-data/DataModule"]
AppGradle --> CoreFirebase["core-firebase/FirebaseModule"]
```

**Diagram sources**
- [gradle/libs.versions.toml:24-91](file://gradle/libs.versions.toml#L24-L91)
- [app/build.gradle.kts:35-81](file://app/build.gradle.kts#L35-L81)
- [core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt:20-41](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt#L20-L41)
- [core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt:12-27](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt#L12-L27)

**Section sources**
- [gradle/libs.versions.toml:1-103](file://gradle/libs.versions.toml#L1-L103)
- [app/build.gradle.kts:1-82](file://app/build.gradle.kts#L1-L82)
- [core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt:1-42](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt#L1-L42)
- [core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt:1-28](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt#L1-L28)

## Performance Considerations
- Minification and ProGuard: Release builds enable minification; ensure keep rules for Hilt, serialization, and navigation classes if crashes occur after build.
- Compose performance: Prefer immutable state, avoid unnecessary recompositions, and use stable state holders.
- Network and Firestore: Batch writes, cache selectively, and handle offline scenarios gracefully.
- Memory: Avoid retaining Activity/Fragment contexts in ViewModels; use application context where appropriate.
- Logging: Use Timber for structured logs during profiling.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide

### Build Problems

- Gradle sync fails or plugin resolution errors
  - Verify plugin IDs in the version catalog match applied plugin IDs in modules.
  - Ensure pluginManagement includes the build-logic includeBuild path.
  - Confirm repositories are configured consistently across settings and pluginManagement.
  - References:
    - [build.gradle.kts:1-12](file://build.gradle.kts#L1-L12)
    - [settings.gradle.kts:1-8](file://settings.gradle.kts#L1-L8)
    - [gradle/libs.versions.toml:93-103](file://gradle/libs.versions.toml#L93-L103)

- Dependency conflicts or version mismatch warnings
  - Align Compose BOM, Hilt, Navigation, and Firebase versions via the version catalog.
  - Use platform() for Compose BOM and Firebase BOM to resolve transitive conflicts.
  - References:
    - [gradle/libs.versions.toml:24-91](file://gradle/libs.versions.toml#L24-L91)
    - [app/build.gradle.kts:59-74](file://app/build.gradle.kts#L59-L74)

- KSP or annotation processor issues
  - Ensure KSP plugin ID matches the version catalog and is applied in modules requiring code generation.
  - References:
    - [gradle/libs.versions.toml:82-86](file://gradle/libs.versions.toml#L82-L86)
    - [app/build.gradle.kts:6-6](file://app/build.gradle.kts#L6-L6)

- Debug vs release build differences
  - Debug suffix and minify toggles differ; confirm manifest and build types when switching variants.
  - References:
    - [app/build.gradle.kts:20-32](file://app/build.gradle.kts#L20-L32)

### Firebase Configuration Issues

- Missing google-services.json
  - Symptoms: App crash or Firebase SDK initialization failure at startup.
  - Solution: Place google-services.json in the app module’s src directory and ensure the Google Services plugin is applied.
  - References:
    - [app/build.gradle.kts:6-6](file://app/build.gradle.kts#L6-L6)
    - [app/src/main/AndroidManifest.xml:29-36](file://app/src/main/AndroidManifest.xml#L29-L36)

- Authentication failures (invalid credentials, user collision)
  - Symptoms: Login/Register emits specific error messages for invalid credentials or existing accounts.
  - Diagnose: Inspect repository error branches and localized messages.
  - References:
    - [core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt:48-54](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L48-L54)
    - [core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt:81-87](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L81-L87)

- Firestore connectivity problems
  - Symptoms: Repository emits database connection errors or empty user profiles.
  - Diagnose: Check Firestore paths and document existence; ensure Firestore service is provided via Hilt.
  - References:
    - [core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt:35-47](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L35-L47)
    - [core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt:100-114](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L100-L114)
    - [core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt:20-22](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt#L20-L22)

### Hilt Dependency Injection Errors

- Dagger compilation errors or missing binding
  - Ensure @HiltAndroidApp is present on the Application class and @AndroidEntryPoint on Activities/Components using injected dependencies.
  - Verify Hilt modules install in SingletonComponent and provide required dependencies.
  - References:
    - [app/src/main/java/com/uit20years/app/UIT20YearsApplication.kt:6-7](file://app/src/main/java/com/uit20years/app/UIT20YearsApplication.kt#L6-L7)
    - [app/src/main/java/com/uit20years/app/MainActivity.kt:14-14](file://app/src/main/java/com/uit20years/app/MainActivity.kt#L14-L14)
    - [core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt:20-41](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt#L20-L41)
    - [core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt:12-27](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt#L12-L27)

- ViewModel injection failures
  - Ensure @HiltViewModel is used on ViewModels and dependencies are provided via Hilt modules.
  - References:
    - [feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt:20-20](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L20-L20)
    - [feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt:20-20](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt#L20-L20)

### Navigation Issues

- Blank or missing screens
  - Ensure NavHost startDestination matches the intended route and feature graphs are wired correctly.
  - References:
    - [app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt:14-18](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L14-L18)
    - [app/src/main/java/com/uit20years/app/navigation/Route.kt:5-12](file://app/src/main/java/com/uit20years/app/navigation/Route.kt#L5-L12)

### Runtime Exceptions

- ViewModel state and effect handling
  - Validate state updates and effect emissions are handled on the main thread; avoid blocking operations in collect.
  - References:
    - [feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt:72-94](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L72-L94)
    - [feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt:112-133](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt#L112-L133)

- Repository exceptions
  - Catch and map Firebase exceptions to user-friendly messages; ensure fallbacks for missing documents.
  - References:
    - [core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt:48-54](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L48-L54)
    - [core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt:81-87](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L81-L87)
    - [core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt:100-114](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L100-L114)

### Debugging Techniques

- ViewModels
  - Observe StateFlow/UIState and effect channels; log transitions and error messages.
  - References:
    - [feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt:25-29](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L25-L29)
    - [feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt:25-29](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt#L25-L29)

- Repository implementations
  - Wrap repository calls with try/catch and emit UitResult states; log underlying exceptions.
  - References:
    - [core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt:29-55](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L29-L55)

- UI components
  - Use logging for navigation events and state changes; verify Compose previews and device-specific rendering.
  - References:
    - [app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt:10-25](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L10-L25)

- Logging and diagnostics
  - Use Timber for structured logs; filter logs by tag and level during development.
  - References:
    - [app/build.gradle.kts:79-80](file://app/build.gradle.kts#L79-L80)

### Performance and Memory Optimization

- Minification and shrinking
  - Review proguard rules for Hilt, serialization, and navigation classes to prevent runtime reflection errors.
  - References:
    - [app/build.gradle.kts:22-27](file://app/build.gradle.kts#L22-L27)

- Compose recomposition
  - Keep state local to UI scopes; avoid passing heavy objects into recompositions.
  - References:
    - [app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt:10-25](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L10-L25)

- Firestore reads/writes
  - Batch writes, cache small documents, and handle offline scenarios; monitor network permissions.
  - References:
    - [app/src/main/AndroidManifest.xml:5-6](file://app/src/main/AndroidManifest.xml#L5-L6)

### Frequently Asked Questions

- Why is the app crashing on startup?
  - Check for missing google-services.json and ensure the Google Services plugin is applied.
  - References:
    - [app/build.gradle.kts:6-6](file://app/build.gradle.kts#L6-L6)
    - [app/src/main/AndroidManifest.xml:29-36](file://app/src/main/AndroidManifest.xml#L29-L36)

- How do I fix “Unresolved reference” for Hilt-generated code?
  - Clean and rebuild; ensure KSP/Hilt compiler is applied and version-catalog-aligned.
  - References:
    - [gradle/libs.versions.toml:82-86](file://gradle/libs.versions.toml#L82-L86)
    - [app/build.gradle.kts:67-70](file://app/build.gradle.kts#L67-L70)

- Why does navigation not switch screens?
  - Verify NavHost startDestination and that feature graphs are registered.
  - References:
    - [app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt:14-18](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L14-L18)

- How do I handle Firestore permission errors?
  - Ensure Firestore rules allow read/write for testing; check document paths and user auth state.
  - References:
    - [core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt:35-47](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L35-L47)

- What constants influence image handling and search behavior?
  - Review page sizes, image dimensions, quality, and debounce intervals.
  - References:
    - [core/core-common/src/main/kotlin/com/uit20years/core/common/constants/AppConstants.kt:3-12](file://core/core-common/src/main/kotlin/com/uit20years/core/common/constants/AppConstants.kt#L3-L12)

### Step-by-Step Solutions

- Fix Gradle sync issues
  - Confirm pluginManagement includes build-logic and repositories are set to FAIL_ON_PROJECT_REPOS.
  - Ensure version catalog versions align with applied plugin IDs.
  - References:
    - [settings.gradle.kts:1-16](file://settings.gradle.kts#L1-L16)
    - [gradle/libs.versions.toml:93-103](file://gradle/libs.versions.toml#L93-L103)

- Resolve dependency conflicts
  - Use platform() for Compose BOM and Firebase BOM; centralize versions in libs.versions.toml.
  - References:
    - [gradle/libs.versions.toml:29-56](file://gradle/libs.versions.toml#L29-L56)
    - [app/build.gradle.kts:59-74](file://app/build.gradle.kts#L59-L74)

- Configure Firebase correctly
  - Add google-services.json; apply Google Services plugin; verify FCM service declaration.
  - References:
    - [app/build.gradle.kts:6-6](file://app/build.gradle.kts#L6-L6)
    - [app/src/main/AndroidManifest.xml:29-36](file://app/src/main/AndroidManifest.xml#L29-L36)

- Fix Hilt injection errors
  - Annotate Application and Activities with Hilt entry points; ensure modules provide singletons.
  - References:
    - [app/src/main/java/com/uit20years/app/UIT20YearsApplication.kt:6-7](file://app/src/main/java/com/uit20years/app/UIT20YearsApplication.kt#L6-L7)
    - [app/src/main/java/com/uit20years/app/MainActivity.kt:14-14](file://app/src/main/java/com/uit20years/app/MainActivity.kt#L14-L14)
    - [core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt:16-26](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt#L16-L26)

- Resolve navigation issues
  - Set NavHost startDestination and register feature graphs; verify route definitions.
  - References:
    - [app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt:14-18](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L14-L18)
    - [app/src/main/java/com/uit20years/app/navigation/Route.kt:5-12](file://app/src/main/java/com/uit20years/app/navigation/Route.kt#L5-L12)

- Debug ViewModels and repositories
  - Log StateFlow/UIState transitions and effect emissions; wrap repository calls with UitResult handling.
  - References:
    - [feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt:72-94](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L72-L94)
    - [core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt:29-55](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L29-L55)

### Diagnostic Commands and Tools

- Build and sync
  - ./gradlew clean
  - ./gradlew :app:assembleDebug
  - ./gradlew :app:assembleRelease

- Lint and static analysis
  - ./gradlew lint
  - ./gradlew ktlintCheck

- Test
  - ./gradlew test

- Profiling
  - Android Studio Profiler: CPU, Memory, Network
  - Logcat filtering by Timber tags and application ID

- Firebase
  - Firebase console: Auth, Firestore, Storage rules and usage
  - Enable debug logging for Firebase SDKs during development

[No sources needed since this section provides general guidance]

## Conclusion
This guide consolidates actionable troubleshooting steps for building, configuring, and operating the UIT20Years Android application. By aligning versions, applying plugins correctly, configuring Firebase, wiring Hilt modules, and instrumenting ViewModels and repositories with robust error handling, most issues can be resolved quickly. Use the provided diagnostic commands and tools to isolate problems efficiently.

## Appendices

### Quick Reference: Common Fixes
- Missing google-services.json → Add to app module and apply Google Services plugin.
- Hilt errors → Clean/rebuild; ensure KSP/Hilt compiler and @HiltAndroidApp/@AndroidEntryPoint.
- Navigation blank → Confirm NavHost startDestination and feature graph registration.
- Firestore errors → Check rules, paths, and document existence; wrap with UitResult.
- Build conflicts → Use platform() BOMs and centralize versions in libs.versions.toml.

[No sources needed since this section provides general guidance]
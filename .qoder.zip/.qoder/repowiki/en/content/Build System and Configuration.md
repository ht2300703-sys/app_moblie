# Build System and Configuration

<cite>
**Referenced Files in This Document**
- [build.gradle.kts](file://build.gradle.kts)
- [settings.gradle.kts](file://settings.gradle.kts)
- [gradle.properties](file://gradle.properties)
- [gradle/libs.versions.toml](file://gradle/libs.versions.toml)
- [build-logic/settings.gradle.kts](file://build-logic/settings.gradle.kts)
- [build-logic/convention/src/main/kotlin/AndroidApplicationConventionPlugin.kt](file://build-logic/convention/src/main/kotlin/AndroidApplicationConventionPlugin.kt)
- [build-logic/convention/src/main/kotlin/AndroidComposeConventionPlugin.kt](file://build-logic/convention/src/main/kotlin/AndroidComposeConventionPlugin.kt)
- [build-logic/convention/src/main/kotlin/AndroidHiltConventionPlugin.kt](file://build-logic/convention/src/main/kotlin/AndroidHiltConventionPlugin.kt)
- [build-logic/convention/src/main/kotlin/AndroidLibraryConventionPlugin.kt](file://build-logic/convention/src/main/kotlin/AndroidLibraryConventionPlugin.kt)
- [build-logic/convention/src/main/kotlin/JvmLibraryConventionPlugin.kt](file://build-logic/convention/src/main/kotlin/JvmLibraryConventionPlugin.kt)
- [build-logic/convention/src/main/kotlin/KotlinAndroid.kt](file://build-logic/convention/src/main/kotlin/KotlinAndroid.kt)
- [build-logic/convention/src/main/kotlin/AndroidFeatureConventionPlugin.kt](file://build-logic/convention/src/main/kotlin/AndroidFeatureConventionPlugin.kt)
- [app/build.gradle.kts](file://app/build.gradle.kts)
- [core/core-common/build.gradle.kts](file://core/core-common/build.gradle.kts)
- [feature/feature-auth/build.gradle.kts](file://feature/feature-auth/build.gradle.kts)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document explains the build system and configuration of the UIT20Years Android application. It focuses on the custom Gradle convention plugins that standardize module builds, the centralized dependency management via version catalogs, and the multi-module architecture orchestrated by the root and build-logic settings. You will learn how to modify build configurations, add new modules, and troubleshoot common build issues while maintaining consistency across the project.

## Project Structure
The project is organized as a multi-module Gradle build with a dedicated build-logic module that encapsulates shared build logic and convention plugins. The root build applies common Gradle plugins with aliasing from the version catalog. The root settings defines repositories and includes all modules. The build-logic settings configures a version catalog pointing to the central TOML file and exposes convention plugins to all modules.

```mermaid
graph TB
RootSettings["Root settings.gradle.kts<br/>Includes modules and repositories"] --> App[":app"]
RootSettings --> CoreCommon[":core:core-common"]
RootSettings --> CoreModel[":core:core-model"]
RootSettings --> CoreDomain[":core:core-domain"]
RootSettings --> CoreData[":core:core-data"]
RootSettings --> CoreFirebase[":core:core-firebase"]
RootSettings --> CoreSearch[":core:core-search"]
RootSettings --> CoreMedia[":core:core-media"]
RootSettings --> CoreUI[":core:core-ui"]
RootSettings --> FeatureAuth[":feature:feature-auth"]
RootSettings --> FeatureMoments[":feature:feature-moments"]
RootSettings --> FeatureEvents[":feature:feature-events"]
RootSettings --> FeatureHeritage[":feature:feature-heritage"]
RootSettings --> FeatureProfile[":feature:feature-profile"]
RootSettings --> FeatureNotifications[":feature:feature-notifications"]
BuildLogicSettings["build-logic/settings.gradle.kts<br/>Exposes convention plugins"] --> Conventions["Convention Plugins"]
Conventions --> App
Conventions --> CoreModules["Core Modules"]
Conventions --> FeatureModules["Feature Modules"]
```

**Diagram sources**
- [settings.gradle.kts](file://settings.gradle.kts)
- [build-logic/settings.gradle.kts](file://build-logic/settings.gradle.kts)

**Section sources**
- [settings.gradle.kts](file://settings.gradle.kts)
- [build-logic/settings.gradle.kts](file://build-logic/settings.gradle.kts)

## Core Components
This section documents the core build components that ensure consistency and maintainability across modules.

- Root build script
  - Applies common Gradle plugins with aliasing from the version catalog. These plugins are applied conditionally to avoid applying them at the wrong scope.
  - Example reference: [build.gradle.kts](file://build.gradle.kts)

- Version catalog
  - Centralized dependency declarations and plugin aliases in gradle/libs.versions.toml. Includes versions, libraries, bundles, and plugin identifiers.
  - Example reference: [gradle/libs.versions.toml](file://gradle/libs.versions.toml)

- Root settings
  - Declares repositories and includes all modules. Uses pluginManagement to include the build-logic composite build and sets dependencyResolutionManagement to enforce repository configuration.
  - Example reference: [settings.gradle.kts](file://settings.gradle.kts)

- Build-logic settings
  - Configures a version catalog named libs backed by the central TOML and exposes convention plugins to modules.
  - Example reference: [build-logic/settings.gradle.kts](file://build-logic/settings.gradle.kts)

- Gradle properties
  - Enables parallel and build caching, AndroidX usage, non-transitive R class, and disables BuildConfig generation by default.
  - Example reference: [gradle.properties](file://gradle.properties)

**Section sources**
- [build.gradle.kts](file://build.gradle.kts)
- [gradle/libs.versions.toml](file://gradle/libs.versions.toml)
- [settings.gradle.kts](file://settings.gradle.kts)
- [build-logic/settings.gradle.kts](file://build-logic/settings.gradle.kts)
- [gradle.properties](file://gradle.properties)

## Architecture Overview
The build architecture leverages convention plugins to standardize Android and JVM configurations, Compose and Hilt integrations, and serialization support. Modules declare their identity using convention plugin aliases, and the version catalog ensures consistent dependency versions across the project.

```mermaid
graph TB
subgraph "Root Build"
RBG["build.gradle.kts"]
RP["gradle.properties"]
RC["gradle/libs.versions.toml"]
end
subgraph "Root Settings"
RS["settings.gradle.kts"]
end
subgraph "Build Logic"
BLS["build-logic/settings.gradle.kts"]
CAP["AndroidApplicationConventionPlugin"]
CCP["AndroidComposeConventionPlugin"]
CHP["AndroidHiltConventionPlugin"]
CLP["AndroidLibraryConventionPlugin"]
JLP["JvmLibraryConventionPlugin"]
KAK["KotlinAndroid (extension)"]
AFP["AndroidFeatureConventionPlugin"]
end
subgraph "Modules"
APP[":app"]
CORECOMMON[":core:core-common"]
FEATUREAUTH[":feature:feature-auth"]
end
RS --> APP
RS --> CORECOMMON
RS --> FEATUREAUTH
BLS --> CAP
BLS --> CCP
BLS --> CH
BLS --> CLP
BLS --> JLP
BLS --> AFP
CAP --> APP
CCP --> APP
CH --> APP
CLP --> CORECOMMON
JLP --> CORECOMMON
AFP --> FEATUREAUTH
RBG --> RC
BLS --> RC
APP --> RC
CORECOMMON --> RC
FEATUREAUTH --> RC
```

**Diagram sources**
- [build.gradle.kts](file://build.gradle.kts)
- [settings.gradle.kts](file://settings.gradle.kts)
- [gradle/libs.versions.toml](file://gradle/libs.versions.toml)
- [build-logic/settings.gradle.kts](file://build-logic/settings.gradle.kts)
- [build-logic/convention/src/main/kotlin/AndroidApplicationConventionPlugin.kt](file://build-logic/convention/src/main/kotlin/AndroidApplicationConventionPlugin.kt)
- [build-logic/convention/src/main/kotlin/AndroidComposeConventionPlugin.kt](file://build-logic/convention/src/main/kotlin/AndroidComposeConventionPlugin.kt)
- [build-logic/convention/src/main/kotlin/AndroidHiltConventionPlugin.kt](file://build-logic/convention/src/main/kotlin/AndroidHiltConventionPlugin.kt)
- [build-logic/convention/src/main/kotlin/AndroidLibraryConventionPlugin.kt](file://build-logic/convention/src/main/kotlin/AndroidLibraryConventionPlugin.kt)
- [build-logic/convention/src/main/kotlin/JvmLibraryConventionPlugin.kt](file://build-logic/convention/src/main/kotlin/JvmLibraryConventionPlugin.kt)
- [build-logic/convention/src/main/kotlin/AndroidFeatureConventionPlugin.kt](file://build-logic/convention/src/main/kotlin/AndroidFeatureConventionPlugin.kt)
- [app/build.gradle.kts](file://app/build.gradle.kts)
- [core/core-common/build.gradle.kts](file://core/core-common/build.gradle.kts)
- [feature/feature-auth/build.gradle.kts](file://feature/feature-auth/build.gradle.kts)

## Detailed Component Analysis

### Convention Plugins Overview
Convention plugins encapsulate standardized Android and JVM configurations, Compose and Hilt setups, and serialization support. They are applied via aliases defined in the version catalog and exposed by the build-logic settings.

- AndroidApplicationConventionPlugin
  - Applies Android Application and Kotlin Android plugins.
  - Configures Kotlin Android settings and sets target SDK.
  - Example reference: [AndroidApplicationConventionPlugin.kt](file://build-logic/convention/src/main/kotlin/AndroidApplicationConventionPlugin.kt)

- AndroidLibraryConventionPlugin
  - Applies Android Library and Kotlin Android plugins.
  - Configures Kotlin Android settings for library modules.
  - Example reference: [AndroidLibraryConventionPlugin.kt](file://build-logic/convention/src/main/kotlin/AndroidLibraryConventionPlugin.kt)

- AndroidComposeConventionPlugin
  - Applies the Compose compiler plugin.
  - Enables Compose build features and adds Compose BOM and bundle dependencies.
  - Example reference: [AndroidComposeConventionPlugin.kt](file://build-logic/convention/src/main/kotlin/AndroidComposeConventionPlugin.kt)

- AndroidHiltConventionPlugin
  - Applies Hilt and KSP plugins.
  - Adds Hilt runtime and KSP compiler dependencies.
  - Example reference: [AndroidHiltConventionPlugin.kt](file://build-logic/convention/src/main/kotlin/AndroidHiltConventionPlugin.kt)

- JvmLibraryConventionPlugin
  - Applies Java Library and Kotlin JVM plugins.
  - Sets Java 17 compatibility and Kotlin JVM target.
  - Example reference: [JvmLibraryConventionPlugin.kt](file://build-logic/convention/src/main/kotlin/JvmLibraryConventionPlugin.kt)

- AndroidFeatureConventionPlugin
  - Applies the feature convention that composes uit.android.library, uit.android.compose, uit.android.hilt, and Kotlin serialization.
  - Adds internal dependencies to core modules and external dependencies via the version catalog.
  - Example reference: [AndroidFeatureConventionPlugin.kt](file://build-logic/convention/src/main/kotlin/AndroidFeatureConventionPlugin.kt)

- KotlinAndroid (extension)
  - Internal extension configuring compile SDK, min SDK, Java compatibility, and Kotlin compiler options.
  - Example reference: [KotlinAndroid.kt](file://build-logic/convention/src/main/kotlin/KotlinAndroid.kt)

```mermaid
classDiagram
class AndroidApplicationConventionPlugin
class AndroidLibraryConventionPlugin
class AndroidComposeConventionPlugin
class AndroidHiltConventionPlugin
class JvmLibraryConventionPlugin
class AndroidFeatureConventionPlugin
class KotlinAndroid
AndroidApplicationConventionPlugin --> KotlinAndroid : "uses"
AndroidLibraryConventionPlugin --> KotlinAndroid : "uses"
AndroidComposeConventionPlugin --> KotlinAndroid : "uses"
AndroidHiltConventionPlugin --> KotlinAndroid : "uses"
JvmLibraryConventionPlugin --> KotlinAndroid : "uses"
AndroidFeatureConventionPlugin --> KotlinAndroid : "uses"
```

**Diagram sources**
- [build-logic/convention/src/main/kotlin/AndroidApplicationConventionPlugin.kt](file://build-logic/convention/src/main/kotlin/AndroidApplicationConventionPlugin.kt)
- [build-logic/convention/src/main/kotlin/AndroidLibraryConventionPlugin.kt](file://build-logic/convention/src/main/kotlin/AndroidLibraryConventionPlugin.kt)
- [build-logic/convention/src/main/kotlin/AndroidComposeConventionPlugin.kt](file://build-logic/convention/src/main/kotlin/AndroidComposeConventionPlugin.kt)
- [build-logic/convention/src/main/kotlin/AndroidHiltConventionPlugin.kt](file://build-logic/convention/src/main/kotlin/AndroidHiltConventionPlugin.kt)
- [build-logic/convention/src/main/kotlin/JvmLibraryConventionPlugin.kt](file://build-logic/convention/src/main/kotlin/JvmLibraryConventionPlugin.kt)
- [build-logic/convention/src/main/kotlin/AndroidFeatureConventionPlugin.kt](file://build-logic/convention/src/main/kotlin/AndroidFeatureConventionPlugin.kt)
- [build-logic/convention/src/main/kotlin/KotlinAndroid.kt](file://build-logic/convention/src/main/kotlin/KotlinAndroid.kt)

**Section sources**
- [build-logic/convention/src/main/kotlin/AndroidApplicationConventionPlugin.kt](file://build-logic/convention/src/main/kotlin/AndroidApplicationConventionPlugin.kt)
- [build-logic/convention/src/main/kotlin/AndroidLibraryConventionPlugin.kt](file://build-logic/convention/src/main/kotlin/AndroidLibraryConventionPlugin.kt)
- [build-logic/convention/src/main/kotlin/AndroidComposeConventionPlugin.kt](file://build-logic/convention/src/main/kotlin/AndroidComposeConventionPlugin.kt)
- [build-logic/convention/src/main/kotlin/AndroidHiltConventionPlugin.kt](file://build-logic/convention/src/main/kotlin/AndroidHiltConventionPlugin.kt)
- [build-logic/convention/src/main/kotlin/JvmLibraryConventionPlugin.kt](file://build-logic/convention/src/main/kotlin/JvmLibraryConventionPlugin.kt)
- [build-logic/convention/src/main/kotlin/AndroidFeatureConventionPlugin.kt](file://build-logic/convention/src/main/kotlin/AndroidFeatureConventionPlugin.kt)
- [build-logic/convention/src/main/kotlin/KotlinAndroid.kt](file://build-logic/convention/src/main/kotlin/KotlinAndroid.kt)

### Module Build Examples
This section shows how modules apply convention plugins and leverage the version catalog.

- Application module (:app)
  - Applies convention plugins for Android application, Compose, Hilt, Kotlin serialization, and Google Services.
  - Declares Android namespace, defaultConfig, build types, and dependencies on feature and core modules plus external libraries from the version catalog.
  - Example reference: [app/build.gradle.kts](file://app/build.gradle.kts)

- Core module (:core:core-common)
  - Applies the JVM library convention plugin and declares coroutines and javax inject dependencies from the version catalog.
  - Example reference: [core/core-common/build.gradle.kts](file://core/core-common/build.gradle.kts)

- Feature module (:feature:feature-auth)
  - Applies the feature convention plugin and Kotlin serialization, and declares navigation and serialization dependencies from the version catalog.
  - Example reference: [feature/feature-auth/build.gradle.kts](file://feature/feature-auth/build.gradle.kts)

```mermaid
sequenceDiagram
participant Gradle as "Gradle"
participant Settings as "settings.gradle.kts"
participant BuildLogic as "build-logic/settings.gradle.kts"
participant VersionCatalog as "gradle/libs.versions.toml"
participant App as " : app/build.gradle.kts"
participant FeatureAuth as " : feature : feature-auth/build.gradle.kts"
Gradle->>Settings : Load root settings
Settings->>BuildLogic : Include build-logic composite build
BuildLogic->>VersionCatalog : Expose libs catalog
Gradle->>App : Apply convention plugins (alias libs.plugins.uit.*)
Gradle->>FeatureAuth : Apply convention plugins (alias libs.plugins.uit.*)
App->>VersionCatalog : Resolve external dependencies
FeatureAuth->>VersionCatalog : Resolve external dependencies
```

**Diagram sources**
- [settings.gradle.kts](file://settings.gradle.kts)
- [build-logic/settings.gradle.kts](file://build-logic/settings.gradle.kts)
- [gradle/libs.versions.toml](file://gradle/libs.versions.toml)
- [app/build.gradle.kts](file://app/build.gradle.kts)
- [feature/feature-auth/build.gradle.kts](file://feature/feature-auth/build.gradle.kts)

**Section sources**
- [app/build.gradle.kts](file://app/build.gradle.kts)
- [core/core-common/build.gradle.kts](file://core/core-common/build.gradle.kts)
- [feature/feature-auth/build.gradle.kts](file://feature/feature-auth/build.gradle.kts)

### Build Optimization and Consistency
- Centralized dependency management
  - All external libraries and plugin versions are declared in the version catalog, ensuring consistent versions across modules.
  - Example reference: [gradle/libs.versions.toml](file://gradle/libs.versions.toml)

- Convention-driven configuration
  - Plugins set compile SDK, min SDK, Java/Kotlin targets, and Compose/Hilt flags consistently across modules.
  - Example reference: [KotlinAndroid.kt](file://build-logic/convention/src/main/kotlin/KotlinAndroid.kt)

- Build caching and parallelism
  - Gradle properties enable parallel execution and build cache to improve performance.
  - Example reference: [gradle.properties](file://gradle.properties)

**Section sources**
- [gradle/libs.versions.toml](file://gradle/libs.versions.toml)
- [KotlinAndroid.kt](file://build-logic/convention/src/main/kotlin/KotlinAndroid.kt)
- [gradle.properties](file://gradle.properties)

## Dependency Analysis
This section maps how modules depend on each other and how the version catalog supplies external dependencies.

```mermaid
graph TB
subgraph "External Dependencies (Version Catalog)"
VC["gradle/libs.versions.toml"]
AGP["Android Gradle Plugin"]
KGP["Kotlin Gradle Plugin"]
CGP["Compose Compiler Plugin"]
KSP["KSP Plugin"]
HILT["Hilt"]
COMPOSE["Compose BOM + Bundles"]
FIREBASE["Firebase BOM + Bundles"]
NAV["Navigation Compose"]
LIFE["Lifecycle"]
COROUTINES["Coroutines"]
SERIALIZATION["Kotlinx Serialization"]
TIMBER["Timber"]
end
subgraph "Modules"
APP[":app"]
COREDATA[":core:core-data"]
COREFIREBASE[":core:core-firebase"]
CORESEARCH[":core:core-search"]
COREMEDIA[":core:core-media"]
COREUI[":core:core-ui"]
COREDOMAIN[":core:core-domain"]
COREMODEL[":core:core-model"]
CORECOMMON[":core:core-common"]
FEATUREAUTH[":feature:feature-auth"]
FEATUREMOMENTS[":feature:feature-moments"]
FEATUREEVENTS[":feature:feature-events"]
FEATUREHERITAGE[":feature:feature-heritage"]
FEATUREPROFILE[":feature:feature-profile"]
FEATURNOTIFICATIONS[":feature:feature-notifications"]
end
APP --> COREDATA
APP --> COREFIREBASE
APP --> CORESEARCH
APP --> COREMEDIA
APP --> COREUI
APP --> COREDOMAIN
APP --> COREMODEL
APP --> CORECOMMON
APP --> FEATUREAUTH
APP --> FEATUREMOMENTS
APP --> FEATUREEVENTS
APP --> FEATUREHERITAGE
APP --> FEATUREPROFILE
APP --> FEATURNOTIFICATIONS
APP --> COMPOSE
APP --> FIREBASE
APP --> HILT
APP --> NAV
APP --> LIFE
APP --> COROUTINES
APP --> SERIALIZATION
APP --> TIMBER
FEATUREAUTH --> NAV
FEATUREAUTH --> SERIALIZATION
CORECOMMON --> COROUTINES
CORECOMMON --> HILT
```

**Diagram sources**
- [gradle/libs.versions.toml](file://gradle/libs.versions.toml)
- [app/build.gradle.kts](file://app/build.gradle.kts)
- [feature/feature-auth/build.gradle.kts](file://feature/feature-auth/build.gradle.kts)
- [core/core-common/build.gradle.kts](file://core/core-common/build.gradle.kts)

**Section sources**
- [gradle/libs.versions.toml](file://gradle/libs.versions.toml)
- [app/build.gradle.kts](file://app/build.gradle.kts)
- [feature/feature-auth/build.gradle.kts](file://feature/feature-auth/build.gradle.kts)
- [core/core-common/build.gradle.kts](file://core/core-common/build.gradle.kts)

## Performance Considerations
- Enable parallel builds and build cache globally via gradle.properties to reduce build times.
- Prefer using BOMs and bundles from the version catalog to minimize dependency resolution overhead.
- Keep convention plugins focused and avoid heavy work in plugin apply blocks to prevent configuration-time slowdowns.
- Use module-level dependency constraints to avoid duplicate transitive dependencies.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
- Plugin alias resolution failures
  - Ensure the version catalog is properly exposed in build-logic settings and referenced in root settings.
  - Verify plugin aliases match entries in the version catalog.

- Compose or Hilt not applied
  - Confirm the convention plugins are applied in the module’s build script and that the convention plugin aliases resolve correctly.
  - Check that the Compose BOM and Hilt dependencies are present in the version catalog.

- Java/Kotlin compatibility errors
  - Ensure the Kotlin Android extension is configured with Java 17 compatibility in convention plugins.
  - Verify module-level Java/Kotlin targets align with convention plugin settings.

- Repository resolution issues
  - Confirm repositories are configured in root settings and build-logic settings.
  - Use FAIL_ON_PROJECT_REPOS mode to catch misconfigured modules.

- Build cache and parallelization
  - If builds fail intermittently, disable parallel or build cache temporarily to isolate flakiness.
  - Review gradle.properties for appropriate JVM arguments and flags.

**Section sources**
- [build-logic/settings.gradle.kts](file://build-logic/settings.gradle.kts)
- [settings.gradle.kts](file://settings.gradle.kts)
- [gradle.properties](file://gradle.properties)
- [gradle/libs.versions.toml](file://gradle/libs.versions.toml)
- [build-logic/convention/src/main/kotlin/KotlinAndroid.kt](file://build-logic/convention/src/main/kotlin/KotlinAndroid.kt)

## Conclusion
The UIT20Years build system uses a robust combination of custom convention plugins, a centralized version catalog, and a multi-module settings configuration to ensure consistency, maintainability, and performance. By leveraging convention plugins and the version catalog, teams can standardize configurations, simplify dependency management, and scale the build as new modules are added.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### How to Modify Build Configurations
- Change compile/target/min SDK or Java/Kotlin targets
  - Update the Kotlin Android extension in the convention plugins.
  - Reference: [KotlinAndroid.kt](file://build-logic/convention/src/main/kotlin/KotlinAndroid.kt)

- Add or update a library dependency
  - Add or update entries in the version catalog and consume them in module build scripts.
  - Reference: [gradle/libs.versions.toml](file://gradle/libs.versions.toml)

- Introduce a new convention plugin
  - Create a new convention plugin under build-logic/convention and expose it via the version catalog.
  - Reference: [build-logic/settings.gradle.kts](file://build-logic/settings.gradle.kts)

**Section sources**
- [KotlinAndroid.kt](file://build-logic/convention/src/main/kotlin/KotlinAndroid.kt)
- [gradle/libs.versions.toml](file://gradle/libs.versions.toml)
- [build-logic/settings.gradle.kts](file://build-logic/settings.gradle.kts)

### How to Add a New Module
- Create a new module under the appropriate directory (e.g., feature or core).
- Apply the relevant convention plugin alias in the module’s build script.
- Declare dependencies on existing modules or external libraries via the version catalog.
- Include the new module in root settings.
- Reference examples:
  - [feature/feature-auth/build.gradle.kts](file://feature/feature-auth/build.gradle.kts)
  - [settings.gradle.kts](file://settings.gradle.kts)

**Section sources**
- [feature/feature-auth/build.gradle.kts](file://feature/feature-auth/build.gradle.kts)
- [settings.gradle.kts](file://settings.gradle.kts)
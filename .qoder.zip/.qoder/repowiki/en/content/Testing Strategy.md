# Testing Strategy

<cite>
**Referenced Files in This Document**
- [DispatcherModule.kt](file://app/src/main/java/com/uit20years/app/di/DispatcherModule.kt)
- [DataModule.kt](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt)
- [FirebaseModule.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt)
- [LoginUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt)
- [RegisterUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt)
- [ObserveAuthStateUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/ObserveAuthStateUseCase.kt)
- [LogoutUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LogoutUseCase.kt)
- [AuthRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt)
- [LoginViewModel.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt)
- [RegisterViewModel.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt)
- [UitResult.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt)
- [Dispatchers.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/dispatcher/Dispatchers.kt)
- [FirebaseAuthService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt)
- [FirestoreService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt)
- [StringExt.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/StringExt.kt)
- [libs.versions.toml](file://gradle/libs.versions.toml)
- [settings.gradle.kts](file://settings.gradle.kts)
- [build.gradle.kts](file://build.gradle.kts)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document defines a comprehensive testing strategy for the UIT20Years Android application following Clean Architecture. It covers unit testing for ViewModels and UseCases, integration testing for repository implementations, and testing patterns for Firebase services. It also explains testing setup using JUnit, MockK, Turbine, and coroutines-test; mocking strategies for dependencies; and testing utilities from core-common. Guidance is provided for testing ViewModels with StateFlow and Channel effects, UseCases with proper isolation, repository implementations with mock Firebase services, UI components, navigation flows, and authentication states. Examples outline common scenarios, error handling, and edge cases. Challenges specific to Firebase integration, asynchronous operations, and dependency injection are addressed, along with recommendations for test coverage and continuous integration testing.

## Project Structure
The project is organized into layered modules aligned with Clean Architecture:
- Application module: app
- Core modules: core-common, core-model, core-domain, core-data, core-firebase, core-search, core-media, core-ui
- Feature modules: feature-auth, feature-moments, feature-events, feature-heritage, feature-profile, feature-notifications

Key testing-relevant modules and files:
- DI modules for dispatchers, data, and Firebase
- Domain UseCases for authentication
- Data repository implementations
- Firebase service wrappers
- ViewModel implementations for authentication screens
- Common result types and extension utilities

```mermaid
graph TB
subgraph "App Layer"
APP["app"]
end
subgraph "Core Layer"
COMMON["core-common"]
MODEL["core-model"]
DOMAIN["core-domain"]
DATA["core-data"]
FIREBASE["core-firebase"]
SEARCH["core-search"]
MEDIA["core-media"]
UI["core-ui"]
end
subgraph "Feature Layer"
AUTH["feature-auth"]
MOMENTS["feature-moments"]
EVENTS["feature-events"]
HERITAGE["feature-heritage"]
PROFILE["feature-profile"]
NOTIFICATIONS["feature-notifications"]
end
APP --> DATA
DATA --> FIREBASE
DATA --> MODEL
DOMAIN --> MODEL
AUTH --> DOMAIN
AUTH --> COMMON
DATA --> COMMON
FIREBASE --> COMMON
```

**Section sources**
- [settings.gradle.kts:20-39](file://settings.gradle.kts#L20-L39)

## Core Components
This section identifies the primary components to test and their roles in the Clean Architecture layers.

- Authentication UseCases
  - LoginUseCase: orchestrates login via AuthRepository and emits UitResult<User>
  - RegisterUseCase: orchestrates registration via AuthRepository and emits UitResult<User>
  - ObserveAuthStateUseCase: observes Firebase auth state and maps to domain User?
  - LogoutUseCase: performs logout and emits UitResult<Unit>

- Authentication Repository Implementation
  - AuthRepositoryImpl: integrates FirebaseAuthService and FirestoreService, handles exceptions, and emits UitResult<User?>

- Firebase Services
  - FirebaseAuthService: wraps FirebaseAuth with suspend and Flow APIs
  - FirestoreService: wraps FirebaseFirestore with suspend and Flow APIs

- ViewModels
  - LoginViewModel: manages LoginUiState and LoginEffect, validates inputs, invokes LoginUseCase, and reacts to UitResult
  - RegisterViewModel: manages RegisterUiState and RegisterEffect, validates inputs, invokes RegisterUseCase, and reacts to UitResult

- Common Utilities
  - UitResult: sealed result type for tests to assert loading, success, and error states
  - String.isValidEmail: input validation used by ViewModels
  - Dispatchers qualifiers: IoDispatcher, DefaultDispatcher, MainDispatcher for DI-scoped dispatchers

**Section sources**
- [LoginUseCase.kt:1-15](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L1-L15)
- [RegisterUseCase.kt:1-18](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt#L1-L18)
- [ObserveAuthStateUseCase.kt:1-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/ObserveAuthStateUseCase.kt#L1-L13)
- [LogoutUseCase.kt:1-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LogoutUseCase.kt#L1-L13)
- [AuthRepositoryImpl.kt:1-147](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L1-L147)
- [FirebaseAuthService.kt:1-37](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L1-L37)
- [FirestoreService.kt:1-107](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt#L1-L107)
- [LoginViewModel.kt:1-100](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L1-L100)
- [RegisterViewModel.kt:1-140](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt#L1-L140)
- [UitResult.kt:1-37](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L1-L37)
- [StringExt.kt:1-10](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/StringExt.kt#L1-L10)
- [Dispatchers.kt:1-16](file://core/core-common/src/main/kotlin/com/uit20years/core/common/dispatcher/Dispatchers.kt#L1-L16)

## Architecture Overview
The testing strategy aligns with Clean Architecture boundaries:
- Unit tests for UseCases and ViewModels focus on behavior and state transitions without external dependencies
- Integration tests for repositories validate interactions with Firebase services via DI and controlled environments
- UI tests validate navigation flows and authentication states using Compose testing utilities

```mermaid
graph TB
subgraph "Test Layers"
UNIT["Unit Tests"]
INTEG["Integration Tests"]
UI_TEST["UI Tests"]
end
subgraph "Domain Layer"
UC_LOGIN["LoginUseCase"]
UC_REGISTER["RegisterUseCase"]
UC_OBS["ObserveAuthStateUseCase"]
UC_LOGOUT["LogoutUseCase"]
end
subgraph "Data Layer"
REPO_IMPL["AuthRepositoryImpl"]
end
subgraph "Firebase Layer"
FB_AUTH["FirebaseAuthService"]
FB_STORE["FirestoreService"]
end
subgraph "Presentation Layer"
VM_LOGIN["LoginViewModel"]
VM_REGISTER["RegisterViewModel"]
end
UNIT --> UC_LOGIN
UNIT --> UC_REGISTER
UNIT --> UC_OBS
UNIT --> UC_LOGOUT
UNIT --> VM_LOGIN
UNIT --> VM_REGISTER
INTEG --> REPO_IMPL
REPO_IMPL --> FB_AUTH
REPO_IMPL --> FB_STORE
UI_TEST --> VM_LOGIN
UI_TEST --> VM_REGISTER
```

**Section sources**
- [DataModule.kt:1-42](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt#L1-L42)
- [FirebaseModule.kt:1-28](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt#L1-L28)
- [DispatcherModule.kt:1-27](file://app/src/main/java/com/uit20years/app/di/DispatcherModule.kt#L1-L27)

## Detailed Component Analysis

### Unit Testing Strategy for UseCases
- Isolation: UseCases depend only on repository interfaces. Inject mocks to isolate business logic from external systems.
- Assertions: Verify emitted UitResult states (Loading, Success, Error) using Turbine’s receiveItems or assertSubscriptions.
- Edge cases: Simulate invalid credentials, network failures, and empty user profiles.
- Example scenarios:
  - Successful login emits Loading followed by Success with a User
  - Invalid credentials emit Loading then Error with a localized message
  - Registration collision emits Loading then Error indicating email already exists

```mermaid
sequenceDiagram
participant Test as "Test Case"
participant UseCase as "LoginUseCase"
participant Repo as "Mock AuthRepository"
participant Result as "Turbine"
Test->>UseCase : invoke(email, password)
UseCase->>Repo : login(email, password)
Repo-->>UseCase : Flow<Loading>
UseCase-->>Result : expectItem(Loading)
Repo-->>UseCase : Flow<Success<User>>
UseCase-->>Result : expectItem(Success<User>)
Result-->>Test : assertNoMoreItems()
```

**Diagram sources**
- [LoginUseCase.kt:9-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L9-L14)
- [UitResult.kt:3-11](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L3-L11)

**Section sources**
- [LoginUseCase.kt:1-15](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L1-L15)
- [RegisterUseCase.kt:1-18](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt#L1-L18)
- [ObserveAuthStateUseCase.kt:1-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/ObserveAuthStateUseCase.kt#L1-L13)
- [LogoutUseCase.kt:1-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LogoutUseCase.kt#L1-L13)

### Unit Testing Strategy for ViewModels
- StateFlow testing: Use Turbine to collect uiState emissions and assert state transitions (loading flags, error messages).
- Channel effects: Use Turbine to collect effects and assert navigation commands.
- Validation logic: Mock or assert behavior against String.isValidEmail and length checks.
- Example scenarios:
  - Valid form submission triggers login flow and navigates on success
  - Invalid email shows email error without invoking UseCase
  - Password shorter than six characters shows password error
  - On Error, errorMessage is set and loading flag is cleared

```mermaid
flowchart TD
Start(["ViewModel.onEvent(event)"]) --> Decide{"Event Type?"}
Decide --> |EmailChanged| UpdateEmail["Update uiState.email<br/>clear isEmailError"]
Decide --> |PasswordChanged| UpdatePassword["Update uiState.password<br/>clear isPasswordError"]
Decide --> |Submit| Validate["validateAndLogin()"]
Decide --> |DismissError| ClearError["Clear errorMessage"]
Validate --> CheckEmail{"isValidEmail?"}
CheckEmail --> |No| ShowEmailError["Set isEmailError=true<br/>errorMessage='invalid email'"]
CheckEmail --> |Yes| CheckPwdLen{"pwd length >= 6?"}
CheckPwdLen --> |No| ShowPwdError["Set isPasswordError=true<br/>errorMessage='too short'"]
CheckPwdLen --> |Yes| InvokeUseCase["Invoke UseCase<br/>collect UitResult"]
InvokeUseCase --> Loading["uiState.isLoading=true"]
InvokeUseCase --> Success["uiState.isLoading=false<br/>emit Navigate effect"]
InvokeUseCase --> Error["uiState.isLoading=false<br/>set errorMessage"]
```

**Diagram sources**
- [LoginViewModel.kt:31-94](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L31-L94)
- [StringExt.kt:3-5](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/StringExt.kt#L3-L5)

**Section sources**
- [LoginViewModel.kt:1-100](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L1-L100)
- [RegisterViewModel.kt:1-140](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt#L1-L140)
- [StringExt.kt:1-10](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/StringExt.kt#L1-L10)

### Integration Testing Strategy for Repositories
- DI-based isolation: Replace real Firebase services with mocks via DI modules. Use @Bind and @Provide to swap implementations.
- Repository responsibilities:
  - AuthRepositoryImpl integrates FirebaseAuthService and FirestoreService
  - Exceptions mapped to UitResult.Error with localized messages
  - observeAuthState maps Firebase snapshots to domain User?
- Testing patterns:
  - Mock FirebaseAuthService to simulate success, failure, and user collisions
  - Mock FirestoreService to simulate document existence and errors
  - Assert emitted UitResult states and error messages

```mermaid
classDiagram
class AuthRepositoryImpl {
+login(email, password) Flow~UitResult<User>~
+register(email, password, displayName) Flow~UitResult<User>~
+logout() Flow~UitResult<Unit>~
+observeAuthState() Flow~User?~
+getCurrentUser() User?
}
class FirebaseAuthService {
+signInWithEmail(email, password) AuthResult
+createUser(email, password) AuthResult
+signOut() void
+getCurrentUser() FirebaseUser?
+observeAuthState() Flow~FirebaseUser?~
}
class FirestoreService {
+getDocument(collection, id) DocumentSnapshot
+setDocument(collection, id, data, merge) void
+observeDocument(collection, id) Flow~DocumentSnapshot~
+runTransaction(block) T
}
AuthRepositoryImpl --> FirebaseAuthService : "uses"
AuthRepositoryImpl --> FirestoreService : "uses"
```

**Diagram sources**
- [AuthRepositoryImpl.kt:24-114](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L24-L114)
- [FirebaseAuthService.kt:14-35](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L14-L35)
- [FirestoreService.kt:16-106](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt#L16-L106)

**Section sources**
- [AuthRepositoryImpl.kt:1-147](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L1-L147)
- [FirebaseAuthService.kt:1-37](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L1-L37)
- [FirestoreService.kt:1-107](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt#L1-L107)

### Testing Patterns for Firebase Services
- FirebaseAuthService: wrap suspend calls and auth state observation with Flow
- FirestoreService: wrap document/collection operations and snapshot listeners with Flow
- Testing approaches:
  - Use MockK to stub suspend functions and Flow emissions
  - For callbacks, use callbackFlow semantics to send values and errors
  - Validate transaction runs and snapshot listener registrations

```mermaid
sequenceDiagram
participant Repo as "AuthRepositoryImpl"
participant AuthSvc as "FirebaseAuthService"
participant StoreSvc as "FirestoreService"
Repo->>AuthSvc : signInWithEmail(email, password)
AuthSvc-->>Repo : AuthResult
Repo->>StoreSvc : getDocument(users, uid)
StoreSvc-->>Repo : DocumentSnapshot
Repo-->>Repo : map to User or Error
```

**Diagram sources**
- [AuthRepositoryImpl.kt:29-55](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L29-L55)
- [FirebaseAuthService.kt:17-18](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L17-L18)
- [FirestoreService.kt:19-20](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt#L19-L20)

**Section sources**
- [FirebaseAuthService.kt:1-37](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L1-L37)
- [FirestoreService.kt:1-107](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt#L1-L107)

### Testing UI Components, Navigation Flows, and Authentication States
- UI components: Test rendering and behavior using Compose testing utilities; verify loading indicators, error views, and text fields
- Navigation: Use NavHostController to simulate navigation events and assert destinations
- Authentication states: Observe UiState transitions and effects; assert navigation effects after successful login or registration

Recommended test scenarios:
- Login screen shows loading during UseCase emission and navigates on success
- Register screen validates inputs and navigates back to login on success
- Error messages appear for invalid inputs and network failures

**Section sources**
- [LoginViewModel.kt:72-94](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L72-L94)
- [RegisterViewModel.kt:112-134](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt#L112-L134)

## Dependency Analysis
Clean Architecture enforces clear boundaries:
- Domain depends only on model and common
- Data depends on domain, model, and firebase
- Presentation depends on domain and common
- DI modules bind implementations to interfaces

```mermaid
graph LR
COMMON["core-common"] --> DOMAIN["core-domain"]
MODEL["core-model"] --> DOMAIN
DOMAIN --> DATA["core-data"]
MODEL --> DATA
FIREBASE["core-firebase"] --> DATA
DOMAIN --> PRESENTATION["feature-*"]
COMMON --> PRESENTATION
DATA --> PRESENTATION
```

**Section sources**
- [DataModule.kt:24-41](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt#L24-L41)
- [FirebaseModule.kt:16-26](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt#L16-L26)
- [DispatcherModule.kt:17-25](file://app/src/main/java/com/uit20years/app/di/DispatcherModule.kt#L17-L25)

## Performance Considerations
- Prefer unit tests for hot-path logic (validation, state updates) to avoid expensive IO
- Use Turbine to assert emissions efficiently without blocking
- Limit coroutine scopes in tests to focused flows to reduce flakiness
- Mock heavy services (Firebase) to eliminate network latency and variability

## Troubleshooting Guide
Common testing challenges and resolutions:
- Asynchronous emissions: Use Turbine to collect and assert Flow emissions deterministically
- Firebase initialization: Ensure DI modules provide singletons; avoid relying on global FirebaseAuth instances in tests
- Dispatcher dependencies: Inject IoDispatcher and DefaultDispatcher via qualifiers to control concurrency in tests
- StateFlow immutability: Update state using copy/update patterns and assert immutable transitions

**Section sources**
- [libs.versions.toml:75-79](file://gradle/libs.versions.toml#L75-L79)
- [Dispatchers.kt:5-11](file://core/core-common/src/main/kotlin/com/uit20years/core/common/dispatcher/Dispatchers.kt#L5-L11)

## Conclusion
This testing strategy leverages Clean Architecture boundaries to create a robust suite of unit, integration, and UI tests. By isolating UseCases and ViewModels, validating repository interactions with Firebase services, and asserting UI behavior and navigation, teams can achieve high confidence in authentication flows and overall application stability. Adopting the recommended patterns and tools ensures maintainable, fast, and reliable tests.

## Appendices

### Testing Setup and Tools
- Frameworks and libraries:
  - JUnit for test runner
  - MockK for mocking
  - Turbine for Flow assertions
  - kotlinx-coroutines-test for coroutine testing
- Version catalog entries:
  - junit, mockk, kotlinx-coroutines-test, turbine

**Section sources**
- [libs.versions.toml:75-79](file://gradle/libs.versions.toml#L75-L79)

### Example Test Scenarios and Edge Cases
- Login
  - Valid credentials: emits Loading then Success with User; navigates to home
  - Invalid credentials: emits Loading then Error with localized message
  - Empty user profile: emits Loading then Error indicating profile not found
- Register
  - Valid inputs: emits Loading then Success; navigates to login
  - Invalid email: shows email error without invoking UseCase
  - Short password: shows password error
  - Non-matching passwords: shows confirm password error
  - Duplicate email: emits Loading then Error indicating email collision
- Logout
  - Success: emits Loading then Success
  - Failure: emits Loading then Error with localized message
- ObserveAuthState
  - Emits current User? from Firestore document or null on error

**Section sources**
- [AuthRepositoryImpl.kt:29-114](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L29-L114)
- [LoginViewModel.kt:48-94](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L48-L94)
- [RegisterViewModel.kt:64-134](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt#L64-L134)

### Continuous Integration Recommendations
- Run unit tests on every commit
- Run integration tests with mocked Firebase services
- Enforce minimum coverage thresholds per module
- Parallelize test execution across modules

**Section sources**
- [build.gradle.kts:1-12](file://build.gradle.kts#L1-L12)
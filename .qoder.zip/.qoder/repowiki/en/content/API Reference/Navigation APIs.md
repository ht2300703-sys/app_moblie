# Navigation APIs

<cite>
**Referenced Files in This Document**
- [Route.kt](file://app/src/main/java/com/uit20years/app/navigation/Route.kt)
- [AppNavHost.kt](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt)
- [MainActivity.kt](file://app/src/main/java/com/uit20years/app/MainActivity.kt)
- [AuthNavigation.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/navigation/AuthNavigation.kt)
- [EventsNavigation.kt](file://feature/feature-events/src/main/java/com/uit20years/feature/events/navigation/EventsNavigation.kt)
- [HeritageNavigation.kt](file://feature/feature-heritage/src/main/java/com/uit20years/feature/heritage/navigation/HeritageNavigation.kt)
- [MomentsNavigation.kt](file://feature/feature-moments/src/main/java/com/uit20years/feature/moments/navigation/MomentsNavigation.kt)
- [NotificationsNavigation.kt](file://feature/feature-notifications/src/main/java/com/uit20years/feature/notifications/navigation/NotificationsNavigation.kt)
- [ProfileNavigation.kt](file://feature/feature-profile/src/main/java/com/uit20years/feature/profile/navigation/ProfileNavigation.kt)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document describes the navigation APIs for the UIT20Years application. It focuses on:
- The Route sealed class and its serialization pattern
- The AppNavHost implementation for type-safe navigation and screen routing
- Feature-specific navigation classes and their navigation functions
- Navigation composables, back stack management, and deep link handling
- Integration with Navigation Compose and serialization patterns for safe navigation

## Project Structure
The navigation system spans two primary areas:
- Application-level navigation definitions and host: app module
- Feature-level navigation graphs and destinations: feature modules

```mermaid
graph TB
subgraph "App Module"
A1["Route.kt"]
A2["AppNavHost.kt"]
A3["MainActivity.kt"]
end
subgraph "Feature Modules"
F1["AuthNavigation.kt"]
F2["EventsNavigation.kt"]
F3["HeritageNavigation.kt"]
F4["MomentsNavigation.kt"]
F5["NotificationsNavigation.kt"]
F6["ProfileNavigation.kt"]
end
A2 --> F1
A2 --> F2
A2 --> F3
A2 --> F4
A2 --> F5
A2 --> F6
A3 --> A2
```

**Diagram sources**
- [AppNavHost.kt:1-26](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L1-L26)
- [MainActivity.kt:1-28](file://app/src/main/java/com/uit20years/app/MainActivity.kt#L1-L28)
- [AuthNavigation.kt:1-49](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/navigation/AuthNavigation.kt#L1-L49)
- [EventsNavigation.kt:1-25](file://feature/feature-events/src/main/java/com/uit20years/feature/events/navigation/EventsNavigation.kt#L1-L25)
- [HeritageNavigation.kt:1-25](file://feature/feature-heritage/src/main/java/com/uit20years/feature/heritage/navigation/HeritageNavigation.kt#L1-L25)
- [MomentsNavigation.kt:1-25](file://feature/feature-moments/src/main/java/com/uit20years/feature/moments/navigation/MomentsNavigation.kt#L1-L25)
- [NotificationsNavigation.kt:1-25](file://feature/feature-notifications/src/main/java/com/uit20years/feature/notifications/navigation/NotificationsNavigation.kt#L1-L25)
- [ProfileNavigation.kt:1-25](file://feature/feature-profile/src/main/java/com/uit20years/feature/profile/navigation/ProfileNavigation.kt#L1-L25)

**Section sources**
- [AppNavHost.kt:1-26](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L1-L26)
- [MainActivity.kt:1-28](file://app/src/main/java/com/uit20years/app/MainActivity.kt#L1-L28)

## Core Components
This section documents the core navigation building blocks and their roles.

- Route sealed class
  - Purpose: Centralized, serializable definition of top-level navigation destinations.
  - Serialization: Uses Kotlinx Serialization to enable safe, typed navigation identifiers.
  - Current destinations: Auth, Home.
  - Reference: [Route.kt:5-12](file://app/src/main/java/com/uit20years/app/navigation/Route.kt#L5-L12)

- AppNavHost
  - Purpose: Hosts the navigation graph for the application, wires the NavHost, and registers feature graphs.
  - Integration: Declares the start destination and includes feature graphs.
  - Back stack behavior: Demonstrates pop-to-root semantics when transitioning to the home destination.
  - Reference: [AppNavHost.kt:10-25](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L10-L25)

- MainActivity
  - Purpose: Entry point that sets the UI content to AppNavHost.
  - Reference: [MainActivity.kt:14-27](file://app/src/main/java/com/uit20years/app/MainActivity.kt#L14-L27)

**Section sources**
- [Route.kt:1-13](file://app/src/main/java/com/uit20years/app/navigation/Route.kt#L1-L13)
- [AppNavHost.kt:1-26](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L1-L26)
- [MainActivity.kt:1-28](file://app/src/main/java/com/uit20years/app/MainActivity.kt#L1-L28)

## Architecture Overview
The navigation architecture follows a layered approach:
- AppNavHost orchestrates the global navigation state and delegates feature-specific routes to feature graphs.
- Feature graphs encapsulate route definitions and transitions for each feature.
- Serialization ensures compile-time safety and runtime reliability for navigation identifiers.

```mermaid
sequenceDiagram
participant Activity as "MainActivity"
participant NavHost as "AppNavHost"
participant AuthGraph as "authGraph"
participant Login as "LoginScreen"
participant Register as "RegisterScreen"
Activity->>NavHost : "Render AppNavHost()"
NavHost->>AuthGraph : "Register authGraph(navController)"
AuthGraph->>Login : "Navigate to LoginScreen"
Login-->>AuthGraph : "onNavigateToRegister -> navController.navigate(RegisterRoute)"
AuthGraph-->>Login : "popBackStack() on success"
Login-->>NavHost : "onLoginSuccess -> navigate('home') with popUpTo(AuthRoute)"
```

**Diagram sources**
- [MainActivity.kt:19-24](file://app/src/main/java/com/uit20years/app/MainActivity.kt#L19-L24)
- [AppNavHost.kt:14-18](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L14-L18)
- [AuthNavigation.kt:20-47](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/navigation/AuthNavigation.kt#L20-L47)

## Detailed Component Analysis

### Route Sealed Class
- Design: Sealed class with serializable data objects representing top-level destinations.
- Serialization pattern: Each destination is annotated for Kotlinx Serialization, enabling safe serialization/deserialization of navigation identifiers.
- Extensibility: New top-level destinations can be added by extending the sealed class with new serializable data objects.

```mermaid
classDiagram
class Route {
<<sealed>>
}
class Auth {
<<object>>
}
class Home {
<<object>>
}
Route <|-- Auth
Route <|-- Home
```

**Diagram sources**
- [Route.kt:5-12](file://app/src/main/java/com/uit20years/app/navigation/Route.kt#L5-L12)

**Section sources**
- [Route.kt:1-13](file://app/src/main/java/com/uit20years/app/navigation/Route.kt#L1-L13)

### AppNavHost Implementation
- Responsibilities:
  - Creates and manages the NavHost controller.
  - Sets the start destination and registers feature graphs.
  - Provides a placeholder for the home destination.
- Back stack management:
  - Demonstrates pop-up-to-root behavior when navigating to the home destination after successful login.
- Deep links:
  - The home destination is represented as a string literal in the current implementation.

```mermaid
flowchart TD
Start(["AppNavHost"]) --> CreateController["Create NavController"]
CreateController --> SetupNavHost["Setup NavHost with startDestination"]
SetupNavHost --> RegisterAuth["Register authGraph(navController)"]
RegisterAuth --> RegisterHome["Register 'home' composable (placeholder)"]
RegisterHome --> End(["Ready"])
```

**Diagram sources**
- [AppNavHost.kt:10-25](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L10-L25)

**Section sources**
- [AppNavHost.kt:1-26](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L1-L26)

### AuthNavigation
- Route definitions:
  - AuthRoute: Top-level route for the authentication feature.
  - LoginRoute: Destination for the login screen.
  - RegisterRoute: Destination for the registration screen.
- Graph composition:
  - authGraph defines nested navigation under AuthRoute with LoginRoute as the start destination.
- Navigation actions:
  - Navigate from Login to Register using RegisterRoute.
  - On successful login, navigate to the home destination and pop the authentication stack.
  - Back navigation from Register to Login is handled via popBackStack.

```mermaid
sequenceDiagram
participant AuthGraph as "authGraph"
participant Login as "LoginRoute"
participant Register as "RegisterRoute"
AuthGraph->>Login : "Show LoginScreen"
Login-->>AuthGraph : "onNavigateToRegister -> navigate(RegisterRoute)"
AuthGraph->>Register : "Show RegisterScreen"
Register-->>AuthGraph : "onRegisterSuccess -> popBackStack()"
Login-->>AuthGraph : "onLoginSuccess -> navigate('home') with popUpTo(AuthRoute)"
```

**Diagram sources**
- [AuthNavigation.kt:20-47](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/navigation/AuthNavigation.kt#L20-L47)

**Section sources**
- [AuthNavigation.kt:1-49](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/navigation/AuthNavigation.kt#L1-L49)

### EventsNavigation
- Route definitions:
  - EventsRoute: Top-level route for the events feature.
  - EventsScreen: Destination for the events screen.
- Graph composition:
  - eventsGraph defines a single-screen navigation under EventsRoute.

```mermaid
flowchart TD
EStart["eventsGraph"] --> ENav["navigation<EventsRoute>"]
ENav --> EComp["composable<EventsScreen>"]
EComp --> EEnd["EventsScreen()"]
```

**Diagram sources**
- [EventsNavigation.kt:13-21](file://feature/feature-events/src/main/java/com/uit20years/feature/events/navigation/EventsNavigation.kt#L13-L21)

**Section sources**
- [EventsNavigation.kt:1-25](file://feature/feature-events/src/main/java/com/uit20years/feature/events/navigation/EventsNavigation.kt#L1-L25)

### HeritageNavigation
- Route definitions:
  - HeritageRoute: Top-level route for the heritage feature.
  - HeritageScreen: Destination for the heritage screen.
- Graph composition:
  - heritageGraph defines a single-screen navigation under HeritageRoute.

```mermaid
flowchart TD
HStart["heritageGraph"] --> HNav["navigation<HeritageRoute>"]
HNav --> HComp["composable<HeritageScreen>"]
HComp --> HEnd["HeritageScreen()"]
```

**Diagram sources**
- [HeritageNavigation.kt:13-21](file://feature/feature-heritage/src/main/java/com/uit20years/feature/heritage/navigation/HeritageNavigation.kt#L13-L21)

**Section sources**
- [HeritageNavigation.kt:1-25](file://feature/feature-heritage/src/main/java/com/uit20years/feature/heritage/navigation/HeritageNavigation.kt#L1-L25)

### MomentsNavigation
- Route definitions:
  - MomentsRoute: Top-level route for the moments feature.
  - MomentsScreen: Destination for the moments screen.
- Graph composition:
  - momentsGraph defines a single-screen navigation under MomentsRoute.

```mermaid
flowchart TD
MStart["momentsGraph"] --> MNav["navigation<MomentsRoute>"]
MNav --> MComp["composable<MomentsScreen>"]
MComp --> MEnd["MomentsScreen()"]
```

**Diagram sources**
- [MomentsNavigation.kt:13-21](file://feature/feature-moments/src/main/java/com/uit20years/feature/moments/navigation/MomentsNavigation.kt#L13-L21)

**Section sources**
- [MomentsNavigation.kt:1-25](file://feature/feature-moments/src/main/java/com/uit20years/feature/moments/navigation/MomentsNavigation.kt#L1-L25)

### NotificationsNavigation
- Route definitions:
  - NotificationsRoute: Top-level route for the notifications feature.
  - NotificationsScreen: Destination for the notifications screen.
- Graph composition:
  - notificationsGraph defines a single-screen navigation under NotificationsRoute.

```mermaid
flowchart TD
NStart["notificationsGraph"] --> NNav["navigation<NotificationsRoute>"]
NNav --> NComp["composable<NotificationsScreen>"]
NComp --> NEnd["NotificationsScreen()"]
```

**Diagram sources**
- [NotificationsNavigation.kt:13-21](file://feature/feature-notifications/src/main/java/com/uit20years/feature/notifications/navigation/NotificationsNavigation.kt#L13-L21)

**Section sources**
- [NotificationsNavigation.kt:1-25](file://feature/feature-notifications/src/main/java/com/uit20years/feature/notifications/navigation/NotificationsNavigation.kt#L1-L25)

### ProfileNavigation
- Route definitions:
  - ProfileRoute: Top-level route for the profile feature.
  - ProfileScreen: Destination for the profile screen.
- Graph composition:
  - profileGraph defines a single-screen navigation under ProfileRoute.

```mermaid
flowchart TD
PStart["profileGraph"] --> PNav["navigation<ProfileRoute>"]
PNav --> PComp["composable<ProfileScreen>"]
PComp --> PEnd["ProfileScreen()"]
```

**Diagram sources**
- [ProfileNavigation.kt:13-21](file://feature/feature-profile/src/main/java/com/uit20years/feature/profile/navigation/ProfileNavigation.kt#L13-L21)

**Section sources**
- [ProfileNavigation.kt:1-25](file://feature/feature-profile/src/main/java/com/uit20years/feature/profile/navigation/ProfileNavigation.kt#L1-L25)

## Dependency Analysis
The navigation system exhibits clear separation of concerns:
- AppNavHost depends on feature graphs to register feature-specific destinations.
- Feature graphs depend on their respective screens and route definitions.
- Serialization is used consistently across Route and feature route objects to ensure type-safe navigation.

```mermaid
graph LR
AppNavHost["AppNavHost.kt"] --> AuthGraph["AuthNavigation.kt"]
AppNavHost --> EventsGraph["EventsNavigation.kt"]
AppNavHost --> HeritageGraph["HeritageNavigation.kt"]
AppNavHost --> MomentsGraph["MomentsNavigation.kt"]
AppNavHost --> NotificationsGraph["NotificationsNavigation.kt"]
AppNavHost --> ProfileGraph["ProfileNavigation.kt"]
Route["Route.kt"] --> AppNavHost
```

**Diagram sources**
- [AppNavHost.kt:7-18](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L7-L18)
- [AuthNavigation.kt:11-18](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/navigation/AuthNavigation.kt#L11-L18)
- [EventsNavigation.kt:10-11](file://feature/feature-events/src/main/java/com/uit20years/feature/events/navigation/EventsNavigation.kt#L10-L11)
- [HeritageNavigation.kt:10-11](file://feature/feature-heritage/src/main/java/com/uit20years/feature/heritage/navigation/HeritageNavigation.kt#L10-L11)
- [MomentsNavigation.kt:10-11](file://feature/feature-moments/src/main/java/com/uit20years/feature/moments/navigation/MomentsNavigation.kt#L10-L11)
- [NotificationsNavigation.kt:10-11](file://feature/feature-notifications/src/main/java/com/uit20years/feature/notifications/navigation/NotificationsNavigation.kt#L10-L11)
- [ProfileNavigation.kt:10-11](file://feature/feature-profile/src/main/java/com/uit20years/feature/profile/navigation/ProfileNavigation.kt#L10-L11)
- [Route.kt:5-12](file://app/src/main/java/com/uit20years/app/navigation/Route.kt#L5-L12)

**Section sources**
- [AppNavHost.kt:1-26](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L1-L26)
- [AuthNavigation.kt:1-49](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/navigation/AuthNavigation.kt#L1-L49)
- [EventsNavigation.kt:1-25](file://feature/feature-events/src/main/java/com/uit20years/feature/events/navigation/EventsNavigation.kt#L1-L25)
- [HeritageNavigation.kt:1-25](file://feature/feature-heritage/src/main/java/com/uit20years/feature/heritage/navigation/HeritageNavigation.kt#L1-L25)
- [MomentsNavigation.kt:1-25](file://feature/feature-moments/src/main/java/com/uit20years/feature/moments/navigation/MomentsNavigation.kt#L1-L25)
- [NotificationsNavigation.kt:1-25](file://feature/feature-notifications/src/main/java/com/uit20years/feature/notifications/navigation/NotificationsNavigation.kt#L1-L25)
- [ProfileNavigation.kt:1-25](file://feature/feature-profile/src/main/java/com/uit20years/feature/profile/navigation/ProfileNavigation.kt#L1-L25)
- [Route.kt:1-13](file://app/src/main/java/com/uit20years/app/navigation/Route.kt#L1-L13)

## Performance Considerations
- Prefer serializable route objects to avoid string parsing overhead and reduce runtime errors.
- Keep feature graphs modular to limit recomposition scope and improve rendering performance.
- Use popUpTo with inclusive flags judiciously to prevent unnecessary back stack growth.

## Troubleshooting Guide
- Symptom: Navigation does not reach the intended destination.
  - Verify that the destination is registered in the correct feature graph and that the route object is serializable.
  - Confirm that the NavHost start destination matches the intended initial route.
- Symptom: Back stack grows unexpectedly after navigation.
  - Ensure popUpTo or popBackStack is used appropriately when transitioning between authentication and main app flows.
- Symptom: Deep link handling fails.
  - For string-based destinations (e.g., "home"), confirm the string literal matches the destination used in navigation calls.

**Section sources**
- [AppNavHost.kt:14-23](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L14-L23)
- [AuthNavigation.kt:29-33](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/navigation/AuthNavigation.kt#L29-L33)

## Conclusion
The navigation system leverages a sealed Route class and feature-specific graphs to provide a type-safe, maintainable navigation layer. Serialization ensures robust routing, while AppNavHost coordinates feature graphs and manages back stack behavior. Extending the system involves adding new serializable routes and integrating feature graphs into AppNavHost.

## Appendices
- Example navigation flow implementation:
  - Define a serializable route object for the destination.
  - Register the destination in the feature graph using composable<T>.
  - Trigger navigation using navController.navigate(T) or navigate("string").
  - Manage back stack with popBackStack or popUpTo as needed.
- Parameter passing between screens:
  - Use serializable route objects to encode parameters implicitly.
  - For complex parameters, pass via ViewModel or state holder and access from the destination screen.
- Deep link handling:
  - For string-based destinations, ensure consistent string literals across navigation calls and NavHost registrations.
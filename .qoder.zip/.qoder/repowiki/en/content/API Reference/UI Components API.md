# UI Components API

<cite>
**Referenced Files in This Document**
- [UitButton.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitButton.kt)
- [UitTextField.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTextField.kt)
- [UitTopBar.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTopBar.kt)
- [LoadingIndicator.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/LoadingIndicator.kt)
- [ErrorView.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/ErrorView.kt)
- [EmptyView.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/EmptyView.kt)
- [Theme.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Theme.kt)
- [Color.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Color.kt)
- [Type.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Type.kt)
- [Shape.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Shape.kt)
- [RegisterScreen.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterScreen.kt)
- [LoginScreen.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginScreen.kt)
- [build.gradle.kts](file://core/core-ui/build.gradle.kts)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document provides comprehensive API documentation for the reusable UI components in the core-ui module. It covers UitButton, UitTextField, UitTopBar, LoadingIndicator, ErrorView, and EmptyView. For each component, we describe properties, styling options, usage patterns, and integration with Material 3 theming. We also include practical examples of component composition, state management integration, accessibility features, and responsive design considerations.

## Project Structure
The core-ui module exposes a set of Compose UI components under the package com.uit20years.core.ui.component and a cohesive Material 3 theming system under com.uit20years.core.ui.theme. The components are designed to be self-contained, theme-aware, and easy to compose into larger screens.

```mermaid
graph TB
subgraph "core-ui Module"
comp_dir["component/"]
theme_dir["theme/"]
comp_dir --> uit_button["UitButton.kt"]
comp_dir --> uit_text_field["UitTextField.kt"]
comp_dir --> uit_top_bar["UitTopBar.kt"]
comp_dir --> loading_indicator["LoadingIndicator.kt"]
comp_dir --> error_view["ErrorView.kt"]
comp_dir --> empty_view["EmptyView.kt"]
theme_dir --> theme_kt["Theme.kt"]
theme_dir --> color_kt["Color.kt"]
theme_dir --> type_kt["Type.kt"]
theme_dir --> shape_kt["Shape.kt"]
end
subgraph "Usage Examples"
register_screen["RegisterScreen.kt"]
login_screen["LoginScreen.kt"]
end
register_screen --> uit_text_field
register_screen --> uit_button
register_screen --> loading_indicator
login_screen --> uit_text_field
login_screen --> uit_button
login_screen --> loading_indicator
theme_kt --> uit_button
theme_kt --> uit_text_field
theme_kt --> uit_top_bar
theme_kt --> loading_indicator
theme_kt --> error_view
theme_kt --> empty_view
```

**Diagram sources**
- [UitButton.kt:1-42](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitButton.kt#L1-L42)
- [UitTextField.kt:1-52](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTextField.kt#L1-L52)
- [UitTopBar.kt:1-43](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTopBar.kt#L1-L43)
- [LoadingIndicator.kt:1-23](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/LoadingIndicator.kt#L1-L23)
- [ErrorView.kt:1-41](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/ErrorView.kt#L1-L41)
- [EmptyView.kt:1-31](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/EmptyView.kt#L1-L31)
- [Theme.kt:1-83](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Theme.kt#L1-L83)
- [Color.kt:1-31](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Color.kt#L1-L31)
- [Type.kt:1-110](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Type.kt#L1-L110)
- [Shape.kt:1-14](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Shape.kt#L1-L14)
- [RegisterScreen.kt:85-144](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterScreen.kt#L85-L144)
- [LoginScreen.kt:80-126](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginScreen.kt#L80-L126)

**Section sources**
- [build.gradle.kts:1-18](file://core/core-ui/build.gradle.kts#L1-L18)

## Core Components
This section summarizes the six reusable UI components and their primary responsibilities:
- UitButton: A Material 3 Button with loading state and brand color defaults.
- UitTextField: A Material 3 OutlinedTextField with error state and optional error message rendering.
- UitTopBar: A Material 3 CenterAlignedTopAppBar with back navigation icon and action slot.
- LoadingIndicator: A full-size centered progress indicator.
- ErrorView: A vertically centered error message with optional retry button.
- EmptyView: A vertically centered message indicating no data.

Each component integrates with the Material 3 theme system via MaterialTheme.colorScheme and typography.

**Section sources**
- [UitButton.kt:1-42](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitButton.kt#L1-L42)
- [UitTextField.kt:1-52](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTextField.kt#L1-L52)
- [UitTopBar.kt:1-43](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTopBar.kt#L1-L43)
- [LoadingIndicator.kt:1-23](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/LoadingIndicator.kt#L1-L23)
- [ErrorView.kt:1-41](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/ErrorView.kt#L1-L41)
- [EmptyView.kt:1-31](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/EmptyView.kt#L1-L31)
- [Theme.kt:57-83](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Theme.kt#L57-L83)

## Architecture Overview
The components are theme-aware and rely on Material 3 primitives. They delegate styling to MaterialTheme.colorScheme and typography, ensuring consistent branding and accessibility. The theme defines brand colors, typography scales, and rounded corner shapes.

```mermaid
graph TB
theme_colors["Brand & Status Colors<br/>Color.kt"]
theme_typo["Typography Scale<br/>Type.kt"]
theme_shapes["Corner Shapes<br/>Shape.kt"]
theme_system["UIT20YearsTheme<br/>Theme.kt"]
uit_button["UitButton<br/>UitButton.kt"]
uit_text_field["UitTextField<br/>UitTextField.kt"]
uit_top_bar["UitTopBar<br/>UitTopBar.kt"]
loading_indicator["LoadingIndicator<br/>LoadingIndicator.kt"]
error_view["ErrorView<br/>ErrorView.kt"]
empty_view["EmptyView<br/>EmptyView.kt"]
theme_system --> uit_button
theme_system --> uit_text_field
theme_system --> uit_top_bar
theme_system --> loading_indicator
theme_system --> error_view
theme_system --> empty_view
theme_colors --> theme_system
theme_typo --> theme_system
theme_shapes --> theme_system
```

**Diagram sources**
- [Theme.kt:15-83](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Theme.kt#L15-L83)
- [Color.kt:1-31](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Color.kt#L1-L31)
- [Type.kt:1-110](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Type.kt#L1-L110)
- [Shape.kt:1-14](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Shape.kt#L1-L14)
- [UitButton.kt:1-42](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitButton.kt#L1-L42)
- [UitTextField.kt:1-52](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTextField.kt#L1-L52)
- [UitTopBar.kt:1-43](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTopBar.kt#L1-L43)
- [LoadingIndicator.kt:1-23](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/LoadingIndicator.kt#L1-L23)
- [ErrorView.kt:1-41](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/ErrorView.kt#L1-L41)
- [EmptyView.kt:1-31](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/EmptyView.kt#L1-L31)

## Detailed Component Analysis

### UitButton
UitButton wraps Material 3 Button with convenience defaults and a loading state.

- Properties
  - text: String — Button label.
  - onClick: () -> Unit — Click handler.
  - modifier: Modifier = Modifier — Layout modifier chain.
  - enabled: Boolean = true — Enables/disables interaction.
  - isLoading: Boolean = false — Shows a white spinner and disables interaction while true.
  - backgroundColor: Color = UITBlue — Container color; uses brand color by default.

- Behavior
  - Full-width layout via fillMaxWidth.
  - When isLoading is true, the button becomes disabled and displays a centered CircularProgressIndicator.
  - Uses ButtonDefaults.buttonColors with containerColor and disabledContainerColor derived from backgroundColor.

- Styling Options
  - backgroundColor accepts any Color; defaults to UITBlue.
  - Disabled appearance inherits alpha-modified backgroundColor for visual consistency.

- Accessibility
  - Inherits Material 3 touch target sizing and focus semantics from Button.
  - No explicit contentDescription is provided; consumers should add one if the button label is insufficient.

- Usage Scenarios
  - Primary submit actions with isLoading bound to ViewModel state.
  - Secondary actions using MaterialTheme.colorScheme.secondary.

- Example References
  - [RegisterScreen.kt:123-127](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterScreen.kt#L123-L127)
  - [RegisterScreen.kt:131-135](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterScreen.kt#L131-L135)
  - [LoginScreen.kt:105-109](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginScreen.kt#L105-L109)
  - [LoginScreen.kt:113-117](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginScreen.kt#L113-L117)

```mermaid
sequenceDiagram
participant User as "User"
participant Screen as "Auth Screen"
participant Button as "UitButton"
participant VM as "ViewModel"
User->>Screen : "Tap Submit"
Screen->>Button : "onClick()"
Button->>VM : "Submit event"
VM-->>Screen : "isLoading = true"
Screen->>Button : "Render with isLoading=true"
VM-->>Screen : "isLoading = false, navigate"
Screen->>Button : "Render with isLoading=false"
```

**Diagram sources**
- [UitButton.kt:14-41](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitButton.kt#L14-L41)
- [RegisterScreen.kt:123-127](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterScreen.kt#L123-L127)
- [LoginScreen.kt:105-109](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginScreen.kt#L105-L109)

**Section sources**
- [UitButton.kt:14-41](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitButton.kt#L14-L41)
- [RegisterScreen.kt:123-135](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterScreen.kt#L123-L135)
- [LoginScreen.kt:105-117](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginScreen.kt#L105-L117)

### UitTextField
UitTextField wraps Material 3 OutlinedTextField with consistent styling and optional error messaging.

- Properties
  - value: String — Current text.
  - onValueChange: (String) -> Unit — Callback for text changes.
  - label: String — Field label.
  - modifier: Modifier = Modifier — Layout modifier chain.
  - enabled: Boolean = true — Enables/disables interaction.
  - isError: Boolean = false — Marks field as invalid.
  - errorMessage: String? = null — Optional error message rendered below the field.
  - visualTransformation: VisualTransformation = VisualTransformation.None — Applies transformations (e.g., masking).
  - isPassword: Boolean = false — Convenience flag to hide input; implemented via visualTransformation and maxLines.
  - maxLines: Int = 1 — Controls multiline behavior.

- Behavior
  - Fills width via fillMaxWidth.
  - Uses TextFieldDefaults.colors with focused/unfocused indicator colors and error indicator color.
  - When isError is true and errorMessage is provided, renders a small red error message beneath the field.

- Styling Options
  - Indicator colors use UITBlue for focused state and Gray for unfocused; error state uses Red.
  - Container colors are transparent for a clean outline appearance.

- Accessibility
  - Inherits Material 3 semantics for text input.
  - Consumers should provide meaningful labels and error messages.

- Usage Scenarios
  - Form inputs with real-time validation feedback.
  - Password fields using isPassword or manual visualTransformation.

- Example References
  - [RegisterScreen.kt:87-92](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterScreen.kt#L87-L92)
  - [RegisterScreen.kt:96-101](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterScreen.kt#L96-L101)
  - [RegisterScreen.kt:105-110](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterScreen.kt#L105-L110)
  - [RegisterScreen.kt:114-119](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterScreen.kt#L114-L119)
  - [LoginScreen.kt:87-92](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginScreen.kt#L87-L92)
  - [LoginScreen.kt:96-101](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginScreen.kt#L96-L101)

```mermaid
flowchart TD
Start(["Render UitTextField"]) --> CheckEnabled["enabled?"]
CheckEnabled --> |No| Disabled["Show disabled field"]
CheckEnabled --> |Yes| CheckError["isError?"]
CheckError --> |Yes| RenderError["Render error message"]
CheckError --> |No| RenderField["Render outlined field"]
RenderError --> End(["Done"])
RenderField --> End
Disabled --> End
```

**Diagram sources**
- [UitTextField.kt:26-51](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTextField.kt#L26-L51)

**Section sources**
- [UitTextField.kt:14-51](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTextField.kt#L14-L51)
- [RegisterScreen.kt:87-119](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterScreen.kt#L87-L119)
- [LoginScreen.kt:87-101](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginScreen.kt#L87-L101)

### UitTopBar
UitTopBar provides a Material 3 CenterAlignedTopAppBar with optional back navigation and action slot.

- Properties
  - title: String — Top app bar title.
  - onBackClick: (() -> Unit)? = null — Back navigation handler; if null, no back icon is shown.
  - actions: @Composable () -> Unit = {} — Action slot for icons/buttons.

- Behavior
  - Displays a back IconButton with contentDescription "Back" when onBackClick is provided.
  - Uses TopAppBarDefaults.centerAlignedTopAppBarColors with white container and UITBlue for title/navigation icons.

- Styling Options
  - Colors align with brand colors; actions can include secondary buttons or menu items.

- Accessibility
  - Back icon includes contentDescription "Back".
  - Consumers should ensure actions are accessible and clearly labeled.

- Example References
  - [RegisterScreen.kt:17-42](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterScreen.kt#L17-L42)
  - [LoginScreen.kt:17-42](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginScreen.kt#L17-L42)

```mermaid
sequenceDiagram
participant User as "User"
participant Bar as "UitTopBar"
participant Nav as "Navigation"
User->>Bar : "Tap Back"
Bar->>Nav : "onBackClick()"
Nav-->>Bar : "Navigate back"
```

**Diagram sources**
- [UitTopBar.kt:17-42](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTopBar.kt#L17-L42)

**Section sources**
- [UitTopBar.kt:17-42](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTopBar.kt#L17-L42)
- [RegisterScreen.kt:17-42](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterScreen.kt#L17-L42)
- [LoginScreen.kt:17-42](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginScreen.kt#L17-L42)

### LoadingIndicator
LoadingIndicator centers a Material 3 CircularProgressIndicator within the screen.

- Properties
  - modifier: Modifier = Modifier — Layout modifier chain.
  - color: Color = UITBlue — Spinner color; defaults to brand blue.

- Behavior
  - Centers the indicator using Box with Alignment.Center.
  - Fills the available space via fillMaxSize.

- Usage Scenarios
  - Overlay during async operations; commonly placed conditionally around content.

- Example References
  - [RegisterScreen.kt:138-140](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterScreen.kt#L138-L140)
  - [LoginScreen.kt:120-122](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginScreen.kt#L120-L122)

**Section sources**
- [LoadingIndicator.kt:12-22](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/LoadingIndicator.kt#L12-L22)
- [RegisterScreen.kt:138-140](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterScreen.kt#L138-L140)
- [LoginScreen.kt:120-122](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginScreen.kt#L120-L122)

### ErrorView
ErrorView presents an error message and optional retry action.

- Properties
  - message: String — Error text.
  - onRetry: (() -> Unit)? = null — Optional retry callback; if null, no retry button is shown.
  - modifier: Modifier = Modifier — Layout modifier chain.

- Behavior
  - Vertically centers content with horizontal alignment.
  - Uses MaterialTheme.typography.bodyLarge and MaterialTheme.colorScheme.error.
  - Conditionally renders a Button with "Retry" label when onRetry is provided.

- Usage Scenarios
  - Displaying network or server errors with a retry option.

- Example References
  - [ErrorView.kt:15-40](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/ErrorView.kt#L15-L40)

**Section sources**
- [ErrorView.kt:15-40](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/ErrorView.kt#L15-L40)

### EmptyView
EmptyView displays a neutral message indicating no data.

- Properties
  - message: String = "No data available" — Default message text.
  - modifier: Modifier = Modifier — Layout modifier chain.

- Behavior
  - Vertically centers content with padding.
  - Uses MaterialTheme.typography.bodyLarge and MaterialTheme.colorScheme.onSurfaceVariant.

- Usage Scenarios
  - Empty lists, search results, or feature placeholders.

- Example References
  - [EmptyView.kt:14-30](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/EmptyView.kt#L14-L30)

**Section sources**
- [EmptyView.kt:14-30](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/EmptyView.kt#L14-L30)

## Dependency Analysis
The components depend on Material 3 primitives and the shared theme system. The core-ui module depends on core-common and core-model, and includes Compose and Lifecycle bundles.

```mermaid
graph TB
core_ui_build["core-ui build.gradle.kts"]
core_common["core-common"]
core_model["core-model"]
compose_bundles["Compose Bundles"]
lifecycle_bundles["Lifecycle Bundles"]
core_ui_build --> core_common
core_ui_build --> core_model
core_ui_build --> compose_bundles
core_ui_build --> lifecycle_bundles
```

**Diagram sources**
- [build.gradle.kts:10-17](file://core/core-ui/build.gradle.kts#L10-L17)

**Section sources**
- [build.gradle.kts:1-18](file://core/core-ui/build.gradle.kts#L1-L18)

## Performance Considerations
- Prefer passing minimal modifier chains; avoid heavy recompositions by keeping state local to the screen and using remember where appropriate.
- For long lists, use LazyColumn with stable item keys to minimize layout work.
- LoadingIndicator overlays should be conditionally rendered to avoid unnecessary composables during normal operation.
- UitTextField and UitButton leverage Material 3 defaults; keep customizations minimal to reduce style recalculations.

## Troubleshooting Guide
- Buttons not responding
  - Verify enabled and isLoading states are correct; when isLoading is true, the button is disabled.
  - Ensure onClick is provided and not shadowed by parent layouts.
  - Reference: [UitButton.kt:24-25](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitButton.kt#L24-L25)

- Text fields show no error message
  - errorMessage must be non-null for the error message to render; otherwise only isError affects the indicator color.
  - Reference: [UitTextField.kt:44-49](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTextField.kt#L44-L49)

- Top bar back icon missing
  - onBackClick must be provided; otherwise no navigation icon is shown.
  - Reference: [UitTopBar.kt:24-33](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTopBar.kt#L24-L33)

- Theming inconsistencies
  - Ensure the app is wrapped in UIT20YearsTheme so components inherit colorScheme and typography.
  - Reference: [Theme.kt:57-83](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Theme.kt#L57-L83)

## Conclusion
The core-ui components provide a cohesive, theme-aware foundation for building consistent UI surfaces. By leveraging Material 3 primitives and the shared theme system, developers can compose reliable screens with minimal boilerplate. The included examples demonstrate state-driven usage patterns suitable for ViewModel-backed forms and asynchronous operations.

## Appendices

### Material 3 Theming Support
- Brand and status colors are defined centrally and applied across components.
- Typography and shapes are configured via UITTypography and UITShapes.
- UIT20YearsTheme applies colorScheme, typography, and shapes globally.

**Section sources**
- [Theme.kt:15-83](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Theme.kt#L15-L83)
- [Color.kt:1-31](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Color.kt#L1-L31)
- [Type.kt:9-110](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Type.kt#L9-L110)
- [Shape.kt:7-13](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Shape.kt#L7-L13)

### Component Composition Examples
- Forms with UitTextField and UitButton
  - RegisterScreen demonstrates multiple text fields with error states and a submit button with loading state.
  - Reference: [RegisterScreen.kt:87-127](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterScreen.kt#L87-L127)
- Login flow with UitTextField and UitButton
  - LoginScreen shows email/password fields and submit button with overlay loading indicator.
  - Reference: [LoginScreen.kt:87-109](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginScreen.kt#L87-L109)
# Use Case APIs

<cite>
**Referenced Files in This Document**
- [LoginUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt)
- [RegisterUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt)
- [LogoutUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LogoutUseCase.kt)
- [ObserveAuthStateUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/ObserveAuthStateUseCase.kt)
- [GetCurrentUserUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/GetCurrentUserUseCase.kt)
- [AuthRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt)
- [AuthRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt)
- [FirebaseAuthService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt)
- [UitResult.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt)
- [User.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt)
- [LoginViewModel.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt)
- [RegisterViewModel.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt)
- [LoginUiState.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginUiState.kt)
- [RegisterUiState.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterUiState.kt)
- [StringExt.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/StringExt.kt)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document provides detailed API documentation for the authentication-related use cases in the core-domain module. It covers the LoginUseCase, RegisterUseCase, LogoutUseCase, ObserveAuthStateUseCase, and GetCurrentUserUseCase classes. For each use case, we explain the execute method (implemented via the invoke operator), parameters, return types, business logic, orchestration of repository operations, parameter validation, error handling strategies, and Flow emission patterns. We also show how ViewModels consume these use cases and manage state using the unidirectional data flow pattern.

## Project Structure
The authentication use cases reside in the core-domain module under the usecase package. They depend on the AuthRepository interface and return Flow streams of UitResult for operations that involve asynchronous work, and Flow<User?> for observation. The concrete repository implementation lives in core-data and integrates with Firebase services from core-firebase. ViewModels in feature-auth demonstrate consumption of these use cases and state management.

```mermaid
graph TB
subgraph "core-domain"
UC_Login["LoginUseCase"]
UC_Register["RegisterUseCase"]
UC_Logout["LogoutUseCase"]
UC_Observe["ObserveAuthStateUseCase"]
UC_GetUser["GetCurrentUserUseCase"]
RepoIF["AuthRepository (interface)"]
end
subgraph "core-data"
RepoImpl["AuthRepositoryImpl"]
end
subgraph "core-firebase"
FBAuth["FirebaseAuthService"]
end
subgraph "feature-auth"
VM_Login["LoginViewModel"]
VM_Register["RegisterViewModel"]
end
UC_Login --> RepoIF
UC_Register --> RepoIF
UC_Logout --> RepoIF
UC_Observe --> RepoIF
UC_GetUser --> RepoIF
RepoIF --> RepoImpl
RepoImpl --> FBAuth
VM_Login --> UC_Login
VM_Register --> UC_Register
```

**Diagram sources**
- [LoginUseCase.kt:1-15](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L1-L15)
- [RegisterUseCase.kt:1-18](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt#L1-L18)
- [LogoutUseCase.kt:1-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LogoutUseCase.kt#L1-L13)
- [ObserveAuthStateUseCase.kt:1-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/ObserveAuthStateUseCase.kt#L1-L13)
- [GetCurrentUserUseCase.kt:1-23](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/GetCurrentUserUseCase.kt#L1-L23)
- [AuthRepository.kt:1-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L1-L14)
- [AuthRepositoryImpl.kt:1-147](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L1-L147)
- [FirebaseAuthService.kt:1-37](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L1-L37)
- [LoginViewModel.kt:1-100](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L1-L100)
- [RegisterViewModel.kt:1-140](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt#L1-L140)

**Section sources**
- [LoginUseCase.kt:1-15](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L1-L15)
- [RegisterUseCase.kt:1-18](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt#L1-L18)
- [LogoutUseCase.kt:1-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LogoutUseCase.kt#L1-L13)
- [ObserveAuthStateUseCase.kt:1-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/ObserveAuthStateUseCase.kt#L1-L13)
- [GetCurrentUserUseCase.kt:1-23](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/GetCurrentUserUseCase.kt#L1-L23)

## Core Components
This section documents each use case’s API surface, parameters, return types, and orchestration.

- LoginUseCase
  - Purpose: Authenticate a user given email and password and stream the result as a Flow of UitResult<User>.
  - Parameters:
    - email: String
    - password: String
  - Return type: Flow<UitResult<User>>
  - Business logic: Delegates to AuthRepository.login, which performs Firebase authentication and fetches the user profile from Firestore, emitting Loading, Success, or Error states.
  - Orchestration: Calls authRepository.login and returns the resulting Flow unchanged.
  - Validation: Handled by the repository; the use case does not validate inputs.
  - Error handling: Errors are emitted as UitResult.Error with localized messages.
  - Flow emission pattern: Emits Loading initially, followed by either Success or Error.

- RegisterUseCase
  - Purpose: Register a new user with email, password, and displayName, streaming UitResult<User>.
  - Parameters:
    - email: String
    - password: String
    - displayName: String
  - Return type: Flow<UitResult<User>>
  - Business logic: Creates a Firebase user and writes a new user document to Firestore, returning the created User domain model.
  - Orchestration: Calls authRepository.register and returns the Flow.
  - Validation: Handled by the repository; the use case does not validate inputs.
  - Error handling: Emits UitResult.Error for invalid credentials, duplicate emails, or database errors.
  - Flow emission pattern: Emits Loading, then Success or Error.

- LogoutUseCase
  - Purpose: Sign out the current user and stream UitResult<Unit>.
  - Parameters: None
  - Return type: Flow<UitResult<Unit>>
  - Business logic: Invokes Firebase sign-out and emits success.
  - Orchestration: Calls authRepository.logout and returns the Flow.
  - Validation: Not applicable.
  - Error handling: Emits UitResult.Error on exceptions.
  - Flow emission pattern: Emits Loading, then Success or Error.

- ObserveAuthStateUseCase
  - Purpose: Observe real-time authentication state changes and emit User? values.
  - Parameters: None
  - Return type: Flow<User?>
  - Business logic: Wraps Firebase auth state changes and resolves the current User by fetching Firestore profile data.
  - Orchestration: Returns authRepository.observeAuthState directly.
  - Validation: Not applicable.
  - Error handling: Catches errors and emits null safely.
  - Flow emission pattern: Emits User? values as the auth state changes.

- GetCurrentUserUseCase
  - Purpose: Retrieve the currently logged-in user synchronously via repository and wrap it in a Flow<UitResult<User>>.
  - Parameters: None
  - Return type: Flow<UitResult<User>>
  - Business logic: Emits Loading, then fetches the current user from the repository; emits Success if found, otherwise emits Error with a “not authenticated” message.
  - Orchestration: Uses a coroutine flow to emit Loading, then delegates to authRepository.getCurrentUser and emits appropriate results.
  - Validation: Not applicable.
  - Error handling: Emits Error when user is null.
  - Flow emission pattern: Emits Loading, then Success or Error.

**Section sources**
- [LoginUseCase.kt:9-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L9-L14)
- [RegisterUseCase.kt:9-17](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt#L9-L17)
- [LogoutUseCase.kt:8-12](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LogoutUseCase.kt#L8-L12)
- [ObserveAuthStateUseCase.kt:8-12](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/ObserveAuthStateUseCase.kt#L8-L12)
- [GetCurrentUserUseCase.kt:10-22](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/GetCurrentUserUseCase.kt#L10-L22)

## Architecture Overview
The use cases act as orchestrators between ViewModels and repositories. They expose a simple API via invoke operators and delegate to AuthRepository implementations. The repository implementation coordinates Firebase authentication and Firestore operations, emitting UitResult for async operations and User? for observation.

```mermaid
sequenceDiagram
participant VM as "ViewModel"
participant UC as "UseCase.invoke(...)"
participant Repo as "AuthRepository"
participant Impl as "AuthRepositoryImpl"
participant FB as "FirebaseAuthService"
VM->>UC : "invoke(parameters)"
UC->>Repo : "delegate call"
Repo->>Impl : "implementation"
Impl->>FB : "perform auth operation"
FB-->>Impl : "result"
Impl-->>UC : "Flow<UitResult<User?>>"
UC-->>VM : "Flow<UitResult<User?>>"
VM->>VM : "collect Flow and update state"
```

**Diagram sources**
- [LoginUseCase.kt:12-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L12-L13)
- [RegisterUseCase.kt:12-16](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt#L12-L16)
- [LogoutUseCase.kt:11-11](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LogoutUseCase.kt#L11-L11)
- [ObserveAuthStateUseCase.kt:11-11](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/ObserveAuthStateUseCase.kt#L11-L11)
- [GetCurrentUserUseCase.kt:13-21](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/GetCurrentUserUseCase.kt#L13-L21)
- [AuthRepository.kt:7-12](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L7-L12)
- [AuthRepositoryImpl.kt:29-55](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L29-L55)
- [FirebaseAuthService.kt:17-25](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L17-L25)

## Detailed Component Analysis

### LoginUseCase
- API
  - Function: invoke(email: String, password: String): Flow<UitResult<User>>
  - Parameters:
    - email: String
    - password: String
  - Return type: Flow<UitResult<User>>
- Business logic
  - Delegates to AuthRepository.login, which:
    - Emits Loading
    - Signs in via Firebase
    - Loads user profile from Firestore
    - Emits Success with User or Error with localized messages
- Parameter validation
  - Not performed by the use case; validation occurs in the repository.
- Error handling
  - Catches Firebase credential and Firestore exceptions, emitting UitResult.Error with messages.
- Flow emission pattern
  - Loading → Success or Error

```mermaid
sequenceDiagram
participant VM as "LoginViewModel"
participant UC as "LoginUseCase"
participant Repo as "AuthRepository"
participant Impl as "AuthRepositoryImpl"
participant FB as "FirebaseAuthService"
VM->>UC : "invoke(email, password)"
UC->>Repo : "login(email, password)"
Repo->>Impl : "login(...)"
Impl->>FB : "signInWithEmail(...)"
FB-->>Impl : "AuthResult"
Impl-->>UC : "Flow<UitResult<User>>"
UC-->>VM : "collect and update uiState"
```

**Diagram sources**
- [LoginUseCase.kt:12-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L12-L13)
- [AuthRepositoryImpl.kt:29-55](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L29-L55)
- [FirebaseAuthService.kt:17-18](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L17-L18)

**Section sources**
- [LoginUseCase.kt:9-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L9-L14)
- [AuthRepositoryImpl.kt:29-55](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L29-L55)
- [UitResult.kt:3-11](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L3-L11)

### RegisterUseCase
- API
  - Function: invoke(email: String, password: String, displayName: String): Flow<UitResult<User>>
  - Parameters:
    - email: String
    - password: String
    - displayName: String
  - Return type: Flow<UitResult<User>>
- Business logic
  - Delegates to AuthRepository.register, which:
    - Emits Loading
    - Creates Firebase user
    - Writes user document to Firestore
    - Emits Success with User or Error with localized messages
- Parameter validation
  - Not performed by the use case; validation occurs in the repository.
- Error handling
  - Catches Firebase user collision and Firestore exceptions, emitting UitResult.Error with messages.
- Flow emission pattern
  - Loading → Success or Error

```mermaid
sequenceDiagram
participant VM as "RegisterViewModel"
participant UC as "RegisterUseCase"
participant Repo as "AuthRepository"
participant Impl as "AuthRepositoryImpl"
participant FB as "FirebaseAuthService"
VM->>UC : "invoke(email, password, displayName)"
UC->>Repo : "register(email, password, displayName)"
Repo->>Impl : "register(...)"
Impl->>FB : "createUser(...)"
FB-->>Impl : "AuthResult"
Impl-->>UC : "Flow<UitResult<User>>"
UC-->>VM : "collect and update uiState"
```

**Diagram sources**
- [RegisterUseCase.kt:12-16](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt#L12-L16)
- [AuthRepositoryImpl.kt:57-88](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L57-L88)
- [FirebaseAuthService.kt:20-21](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L20-L21)

**Section sources**
- [RegisterUseCase.kt:9-17](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt#L9-L17)
- [AuthRepositoryImpl.kt:57-88](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L57-L88)
- [UitResult.kt:3-11](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L3-L11)

### LogoutUseCase
- API
  - Function: invoke(): Flow<UitResult<Unit>>
  - Parameters: None
  - Return type: Flow<UitResult<Unit>>
- Business logic
  - Delegates to AuthRepository.logout, which:
    - Emits Loading
    - Performs Firebase sign-out
    - Emits Success or Error
- Parameter validation
  - Not applicable.
- Error handling
  - Catches exceptions and emits UitResult.Error with messages.
- Flow emission pattern
  - Loading → Success or Error

```mermaid
sequenceDiagram
participant VM as "ViewModel"
participant UC as "LogoutUseCase"
participant Repo as "AuthRepository"
participant Impl as "AuthRepositoryImpl"
participant FB as "FirebaseAuthService"
VM->>UC : "invoke()"
UC->>Repo : "logout()"
Repo->>Impl : "logout()"
Impl->>FB : "signOut()"
FB-->>Impl : "void"
Impl-->>UC : "Flow<UitResult<Unit>>"
UC-->>VM : "collect and react"
```

**Diagram sources**
- [LogoutUseCase.kt:11-11](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LogoutUseCase.kt#L11-L11)
- [AuthRepositoryImpl.kt:90-98](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L90-L98)
- [FirebaseAuthService.kt:23-24](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L23-L24)

**Section sources**
- [LogoutUseCase.kt:8-12](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LogoutUseCase.kt#L8-L12)
- [AuthRepositoryImpl.kt:90-98](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L90-L98)
- [UitResult.kt:3-11](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L3-L11)

### ObserveAuthStateUseCase
- API
  - Function: invoke(): Flow<User?>
  - Parameters: None
  - Return type: Flow<User?>
- Business logic
  - Delegates to AuthRepository.observeAuthState, which:
    - Observes Firebase auth state changes
    - Resolves current User by fetching Firestore profile
    - Emits null on errors
- Parameter validation
  - Not applicable.
- Error handling
  - Catches and suppresses errors, emitting null.
- Flow emission pattern
  - Emits User? values as auth state changes

```mermaid
sequenceDiagram
participant VM as "ViewModel"
participant UC as "ObserveAuthStateUseCase"
participant Repo as "AuthRepository"
participant Impl as "AuthRepositoryImpl"
participant FB as "FirebaseAuthService"
VM->>UC : "invoke()"
UC->>Repo : "observeAuthState()"
Repo->>Impl : "observeAuthState()"
Impl->>FB : "observeAuthState()"
FB-->>Impl : "Flow<FirebaseUser?>"
Impl-->>UC : "Flow<User?>"
UC-->>VM : "collect and update uiState"
```

**Diagram sources**
- [ObserveAuthStateUseCase.kt:11-11](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/ObserveAuthStateUseCase.kt#L11-L11)
- [AuthRepositoryImpl.kt:100-114](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L100-L114)
- [FirebaseAuthService.kt:29-35](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L29-L35)

**Section sources**
- [ObserveAuthStateUseCase.kt:8-12](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/ObserveAuthStateUseCase.kt#L8-L12)
- [AuthRepositoryImpl.kt:100-114](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L100-L114)

### GetCurrentUserUseCase
- API
  - Function: invoke(): Flow<UitResult<User>>
  - Parameters: None
  - Return type: Flow<UitResult<User>>
- Business logic
  - Emits Loading immediately, then calls authRepository.getCurrentUser and emits Success with User or Error with a “not authenticated” message.
- Parameter validation
  - Not applicable.
- Error handling
  - Emits Error when user is null.
- Flow emission pattern
  - Loading → Success or Error

```mermaid
sequenceDiagram
participant VM as "ViewModel"
participant UC as "GetCurrentUserUseCase"
participant Repo as "AuthRepository"
participant Impl as "AuthRepositoryImpl"
VM->>UC : "invoke()"
UC->>UC : "emit Loading"
UC->>Repo : "getCurrentUser()"
Repo->>Impl : "getCurrentUser()"
Impl-->>Repo : "User?"
Repo-->>UC : "User?"
UC->>UC : "emit Success or Error"
UC-->>VM : "collect and update uiState"
```

**Diagram sources**
- [GetCurrentUserUseCase.kt:13-21](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/GetCurrentUserUseCase.kt#L13-L21)
- [AuthRepositoryImpl.kt:116-133](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L116-L133)

**Section sources**
- [GetCurrentUserUseCase.kt:10-22](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/GetCurrentUserUseCase.kt#L10-L22)
- [AuthRepositoryImpl.kt:116-133](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L116-L133)
- [UitResult.kt:3-11](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L3-L11)

## Dependency Analysis
The use cases depend on the AuthRepository interface. The repository interface is implemented by AuthRepositoryImpl, which depends on FirebaseAuthService and FirestoreService. ViewModels depend on the use cases and manage UI state and effects.

```mermaid
classDiagram
class LoginUseCase {
+invoke(email : String, password : String) : Flow~UitResult~User~~
}
class RegisterUseCase {
+invoke(email : String, password : String, displayName : String) : Flow~UitResult~User~~
}
class LogoutUseCase {
+invoke() : Flow~UitResult~Unit~~
}
class ObserveAuthStateUseCase {
+invoke() : Flow~User?~
}
class GetCurrentUserUseCase {
+invoke() : Flow~UitResult~User~~
}
class AuthRepository {
<<interface>>
+login(email : String, password : String) : Flow~UitResult~User~~
+register(email : String, password : String, displayName : String) : Flow~UitResult~User~~
+logout() : Flow~UitResult~Unit~~
+observeAuthState() : Flow~User?~
+getCurrentUser() : User?
}
class AuthRepositoryImpl
class FirebaseAuthService
LoginUseCase --> AuthRepository : "delegates"
RegisterUseCase --> AuthRepository : "delegates"
LogoutUseCase --> AuthRepository : "delegates"
ObserveAuthStateUseCase --> AuthRepository : "delegates"
GetCurrentUserUseCase --> AuthRepository : "delegates"
AuthRepositoryImpl ..|> AuthRepository
AuthRepositoryImpl --> FirebaseAuthService : "uses"
```

**Diagram sources**
- [LoginUseCase.kt:9-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L9-L13)
- [RegisterUseCase.kt:9-16](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt#L9-L16)
- [LogoutUseCase.kt:8-11](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LogoutUseCase.kt#L8-L11)
- [ObserveAuthStateUseCase.kt:8-11](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/ObserveAuthStateUseCase.kt#L8-L11)
- [GetCurrentUserUseCase.kt:10-21](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/GetCurrentUserUseCase.kt#L10-L21)
- [AuthRepository.kt:7-12](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L7-L12)
- [AuthRepositoryImpl.kt:24-27](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L24-L27)
- [FirebaseAuthService.kt:14-15](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L14-L15)

**Section sources**
- [AuthRepository.kt:1-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L1-L14)
- [AuthRepositoryImpl.kt:1-147](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L1-L147)

## Performance Considerations
- Flow emissions: Use cases and repository implementations emit Loading before performing work, enabling responsive UI updates without blocking.
- Observation: ObserveAuthStateUseCase provides continuous updates with minimal overhead by delegating to Firebase’s auth state listener.
- Suspend vs Flow: GetCurrentUserUseCase uses a coroutine flow to unify sync and async retrieval into a single Flow<UitResult<User>> API.
- Error containment: Repository implementations catch exceptions and emit UitResult.Error, preventing crashes and allowing ViewModels to present user-friendly messages.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and resolutions:
- Authentication failures
  - Symptoms: UitResult.Error with messages indicating invalid credentials or connection issues.
  - Resolution: Verify email/password, network connectivity, and Firebase configuration.
- Registration conflicts
  - Symptoms: UitResult.Error indicating email already in use.
  - Resolution: Prompt the user to use another email or trigger the login flow.
- Missing user profile after login
  - Symptoms: UitResult.Error indicating profile not found.
  - Resolution: Ensure Firestore user document exists or trigger registration.
- Auth state observation errors
  - Symptoms: Null emissions from ObserveAuthStateUseCase.
  - Resolution: The repository handles errors by emitting null; ensure downstream logic accounts for null states.
- “Not authenticated” error
  - Symptoms: Error emitted by GetCurrentUserUseCase.
  - Resolution: Redirect to login or retry authentication.

**Section sources**
- [AuthRepositoryImpl.kt:48-54](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L48-L54)
- [AuthRepositoryImpl.kt:81-87](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L81-L87)
- [AuthRepositoryImpl.kt:100-114](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L100-L114)
- [GetCurrentUserUseCase.kt:16-20](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/GetCurrentUserUseCase.kt#L16-L20)

## Conclusion
The authentication use cases provide a clean, testable API for ViewModels to perform login, registration, logout, observe auth state, and fetch the current user. They consistently return Flow streams of UitResult for async operations and User? for observation, enabling robust error handling and responsive UI updates. The repository implementation centralizes Firebase and Firestore interactions, ensuring predictable behavior and maintainability.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### Unidirectional Data Flow and State Management in ViewModels
- LoginViewModel
  - Collects Flow<UitResult<User>> from LoginUseCase.
  - Updates uiState for loading/error states and triggers effects (e.g., navigation) on success.
  - Validates inputs using String.isValidEmail before invoking the use case.
- RegisterViewModel
  - Collects Flow<UitResult<User>> from RegisterUseCase.
  - Updates uiState for loading/error states and triggers effects (e.g., navigate to login) on success.
  - Validates inputs including email, password length, password confirmation, and display name.

```mermaid
flowchart TD
Start(["User submits form"]) --> Validate["Validate inputs"]
Validate --> Valid{"Valid?"}
Valid --> |No| ShowErrors["Update uiState with error messages"]
Valid --> |Yes| InvokeUseCase["Invoke UseCase.invoke(...)"]
InvokeUseCase --> Collect["Collect Flow<UitResult<User>>"]
Collect --> IsLoading{"Loading?"}
IsLoading --> |Yes| SetLoading["Set isLoading = true"]
IsLoading --> |No| IsSuccess{"Success?"}
IsSuccess --> |Yes| EmitEffect["Emit effect (navigate)"]
IsSuccess --> |No| IsError{"Error?"}
IsError --> |Yes| ShowError["Set isLoading=false and show error message"]
EmitEffect --> End(["UI updated"])
ShowErrors --> End
SetLoading --> End
ShowError --> End
```

**Diagram sources**
- [LoginViewModel.kt:48-94](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L48-L94)
- [RegisterViewModel.kt:64-134](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt#L64-L134)
- [StringExt.kt:3-5](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/StringExt.kt#L3-L5)

**Section sources**
- [LoginViewModel.kt:1-100](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L1-L100)
- [RegisterViewModel.kt:1-140](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt#L1-L140)
- [LoginUiState.kt:1-11](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginUiState.kt#L1-L11)
- [RegisterUiState.kt:1-15](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterUiState.kt#L1-L15)
- [StringExt.kt:1-10](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/StringExt.kt#L1-L10)
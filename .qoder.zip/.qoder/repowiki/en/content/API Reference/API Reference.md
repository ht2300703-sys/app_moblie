# API Reference

<cite>
**Referenced Files in This Document**
- [AuthRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt)
- [LoginUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt)
- [RegisterUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt)
- [LogoutUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LogoutUseCase.kt)
- [ObserveAuthStateUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/ObserveAuthStateUseCase.kt)
- [UitButton.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitButton.kt)
- [UitTextField.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTextField.kt)
- [UitTopBar.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTopBar.kt)
- [EmptyView.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/EmptyView.kt)
- [ErrorView.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/ErrorView.kt)
- [UitResult.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt)
- [StringExt.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/StringExt.kt)
- [DateExt.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/DateExt.kt)
- [FlowExt.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/FlowExt.kt)
- [AppConstants.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/constants/AppConstants.kt)
- [Dispatchers.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/dispatcher/Dispatchers.kt)
- [Route.kt](file://app/src/main/java/com/uit20years/app/navigation/Route.kt)
- [AppNavHost.kt](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This API Reference documents the public interfaces and components of the UIT20Years Android application. It focuses on:
- Authentication repository interface and related use cases
- Reusable UI components (buttons, text fields, top bar, empty/error views)
- Common utilities and extension functions
- Navigation route APIs and integration points

The goal is to provide method-level documentation, parameter descriptions, return values, usage patterns, and integration guidance suitable for both technical and non-technical readers.

## Project Structure
The application follows a modular architecture with separate modules for domain logic, data, UI, common utilities, and navigation. The key areas covered here are:
- core-domain: repository interfaces and use cases
- core-ui: Compose UI components
- core-common: shared utilities, extensions, and constants
- app: navigation host and routes

```mermaid
graph TB
subgraph "Domain Layer"
AR["AuthRepository<br/>core-domain"]
UC_LOGIN["LoginUseCase"]
UC_REGISTER["RegisterUseCase"]
UC_LOGOUT["LogoutUseCase"]
UC_OBSERVE["ObserveAuthStateUseCase"]
end
subgraph "UI Layer"
BTN["UitButton"]
TF["UitTextField"]
TOPBAR["UitTopBar"]
EMPTY["EmptyView"]
ERROR["ErrorView"]
end
subgraph "Common Layer"
RESULT["UitResult"]
STR_EXT["StringExt"]
DATE_EXT["DateExt"]
FLOW_EXT["FlowExt"]
CONST["AppConstants"]
DISP["Dispatchers"]
end
subgraph "App Layer"
ROUTE["Route"]
NAV["AppNavHost"]
end
AR --> UC_LOGIN
AR --> UC_REGISTER
AR --> UC_LOGOUT
AR --> UC_OBSERVE
UC_LOGIN --> RESULT
UC_REGISTER --> RESULT
UC_LOGOUT --> RESULT
UC_OBSERVE --> RESULT
BTN --> RESULT
TF --> RESULT
TOPBAR --> RESULT
EMPTY --> RESULT
ERROR --> RESULT
STR_EXT --> RESULT
DATE_EXT --> RESULT
FLOW_EXT --> RESULT
ROUTE --> NAV
```

**Diagram sources**
- [AuthRepository.kt:1-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L1-L14)
- [LoginUseCase.kt:1-15](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L1-L15)
- [RegisterUseCase.kt:1-18](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt#L1-L18)
- [LogoutUseCase.kt:1-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LogoutUseCase.kt#L1-L13)
- [ObserveAuthStateUseCase.kt:1-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/ObserveAuthStateUseCase.kt#L1-L13)
- [UitButton.kt:1-42](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitButton.kt#L1-L42)
- [UitTextField.kt:1-52](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTextField.kt#L1-L52)
- [UitTopBar.kt:1-43](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTopBar.kt#L1-L43)
- [EmptyView.kt:1-31](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/EmptyView.kt#L1-L31)
- [ErrorView.kt:1-41](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/ErrorView.kt#L1-L41)
- [UitResult.kt:1-37](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L1-L37)
- [StringExt.kt:1-10](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/StringExt.kt#L1-L10)
- [DateExt.kt:1-23](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/DateExt.kt#L1-L23)
- [FlowExt.kt:1-13](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/FlowExt.kt#L1-L13)
- [AppConstants.kt:1-13](file://core/core-common/src/main/kotlin/com/uit20years/core/common/constants/AppConstants.kt#L1-L13)
- [Dispatchers.kt:1-16](file://core/core-common/src/main/kotlin/com/uit20years/core/common/dispatcher/Dispatchers.kt#L1-L16)
- [Route.kt](file://app/src/main/java/com/uit20years/app/navigation/Route.kt)
- [AppNavHost.kt](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt)

**Section sources**
- [AuthRepository.kt:1-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L1-L14)
- [UitButton.kt:1-42](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitButton.kt#L1-L42)
- [UitTextField.kt:1-52](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTextField.kt#L1-L52)
- [UitTopBar.kt:1-43](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTopBar.kt#L1-L43)
- [EmptyView.kt:1-31](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/EmptyView.kt#L1-L31)
- [ErrorView.kt:1-41](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/ErrorView.kt#L1-L41)
- [UitResult.kt:1-37](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L1-L37)
- [StringExt.kt:1-10](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/StringExt.kt#L1-L10)
- [DateExt.kt:1-23](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/DateExt.kt#L1-L23)
- [FlowExt.kt:1-13](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/FlowExt.kt#L1-L13)
- [AppConstants.kt:1-13](file://core/core-common/src/main/kotlin/com/uit20years/core/common/constants/AppConstants.kt#L1-L13)
- [Dispatchers.kt:1-16](file://core/core-common/src/main/kotlin/com/uit20years/core/common/dispatcher/Dispatchers.kt#L1-L16)
- [Route.kt](file://app/src/main/java/com/uit20years/app/navigation/Route.kt)
- [AppNavHost.kt](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt)

## Core Components
This section summarizes the primary public APIs grouped by module.

- Authentication Repository
  - Interface: AuthRepository
  - Methods:
    - login(email: String, password: String): Flow<UitResult<User>>
    - register(email: String, password: String, displayName: String): Flow<UitResult<User>>
    - logout(): Flow<UitResult<Unit>>
    - observeAuthState(): Flow<User?>
    - getCurrentUser(): suspend User?

- Authentication Use Cases
  - LoginUseCase: invoke(email: String, password: String): Flow<UitResult<User>>
  - RegisterUseCase: invoke(email: String, password: String, displayName: String): Flow<UitResult<User>>
  - LogoutUseCase: invoke(): Flow<UitResult<Unit>>
  - ObserveAuthStateUseCase: invoke(): Flow<User?>

- UI Components
  - UitButton
    - Parameters: text: String, onClick: () -> Unit, modifier: Modifier = ..., enabled: Boolean = true, isLoading: Boolean = false, backgroundColor: Color = UITBlue
    - Behavior: Renders a Material3 Button with optional loading indicator; disables interaction while loading
  - UitTextField
    - Parameters: value: String, onValueChange: (String) -> Unit, label: String, modifier: Modifier = ..., enabled: Boolean = true, isError: Boolean = false, errorMessage: String? = null, visualTransformation: VisualTransformation = VisualTransformation.None, isPassword: Boolean = false, maxLines: Int = 1
    - Behavior: Material3 OutlinedTextField with error messaging support
  - UitTopBar
    - Parameters: title: String, onBackClick: (() -> Unit)? = null, actions: @Composable () -> Unit = {}
    - Behavior: Material3 CenterAlignedTopAppBar with optional back navigation icon and actions
  - EmptyView
    - Parameters: message: String = "No data available", modifier: Modifier = ...
    - Behavior: Centered empty state message
  - ErrorView
    - Parameters: message: String, onRetry: (() -> Unit)? = null, modifier: Modifier = ...
    - Behavior: Centered error message with optional retry button

- Common Utilities and Extensions
  - UitResult<T>
    - Sealed interface with Success<T>, Error, and Loading
    - Helper extensions: getOrNull(), getOrThrow(), onSuccess(), onError(), isSuccess, isError, isLoading
  - StringExt
    - isValidEmail(): Boolean
    - truncate(maxLength: Int, suffix: String = "..."): String
  - DateExt
    - Long.toFormattedDate(pattern: String = ...): String
    - Long.toRelativeTime(): String
  - FlowExt
    - Flow<T>.asUitResult(): Flow<UitResult<T>>
  - AppConstants
    - PAGE_SIZE, MAX_IMAGE_WIDTH, MAX_IMAGE_HEIGHT, IMAGE_QUALITY, SEARCH_DEBOUNCE_MS, MAX_HASHTAGS, MAX_POST_LENGTH, MAX_COMMENT_LENGTH
  - Dispatchers
    - Qualifiers: @IoDispatcher, @DefaultDispatcher, @MainDispatcher

- Navigation
  - Route: Application routes definition
  - AppNavHost: Hosts navigation graph and integrates with Route

**Section sources**
- [AuthRepository.kt:1-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L1-L14)
- [LoginUseCase.kt:1-15](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L1-L15)
- [RegisterUseCase.kt:1-18](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt#L1-L18)
- [LogoutUseCase.kt:1-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LogoutUseCase.kt#L1-L13)
- [ObserveAuthStateUseCase.kt:1-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/ObserveAuthStateUseCase.kt#L1-L13)
- [UitButton.kt:1-42](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitButton.kt#L1-L42)
- [UitTextField.kt:1-52](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTextField.kt#L1-L52)
- [UitTopBar.kt:1-43](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTopBar.kt#L1-L43)
- [EmptyView.kt:1-31](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/EmptyView.kt#L1-L31)
- [ErrorView.kt:1-41](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/ErrorView.kt#L1-L41)
- [UitResult.kt:1-37](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L1-L37)
- [StringExt.kt:1-10](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/StringExt.kt#L1-L10)
- [DateExt.kt:1-23](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/DateExt.kt#L1-L23)
- [FlowExt.kt:1-13](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/FlowExt.kt#L1-L13)
- [AppConstants.kt:1-13](file://core/core-common/src/main/kotlin/com/uit20years/core/common/constants/AppConstants.kt#L1-L13)
- [Dispatchers.kt:1-16](file://core/core-common/src/main/kotlin/com/uit20years/core/common/dispatcher/Dispatchers.kt#L1-L16)
- [Route.kt](file://app/src/main/java/com/uit20years/app/navigation/Route.kt)
- [AppNavHost.kt](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt)

## Architecture Overview
The authentication flow integrates UI, use cases, repositories, and common result types. The following sequence illustrates a typical login operation.

```mermaid
sequenceDiagram
participant UI as "Login Screen"
participant VM as "LoginViewModel"
participant UC as "LoginUseCase"
participant Repo as "AuthRepository"
participant Result as "UitResult<User>"
UI->>VM : "Invoke login with credentials"
VM->>UC : "invoke(email, password)"
UC->>Repo : "login(email, password)"
Repo-->>UC : "Flow<UitResult<User>>"
UC-->>VM : "Flow<UitResult<User>>"
VM-->>UI : "Render Loading/Success/Error"
```

**Diagram sources**
- [LoginUseCase.kt:1-15](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L1-L15)
- [AuthRepository.kt:1-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L1-L14)
- [UitResult.kt:1-37](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L1-L37)

## Detailed Component Analysis

### Authentication Repository API
- Interface: AuthRepository
  - Purpose: Defines authentication operations and state observation
  - Methods:
    - login(email: String, password: String): Flow<UitResult<User>>
      - Returns a reactive stream indicating progress and outcome
    - register(email: String, password: String, displayName: String): Flow<UitResult<User>>
      - Registers a new user and emits result via Flow
    - logout(): Flow<UitResult<Unit>>
      - Logs out current user and emits result
    - observeAuthState(): Flow<User?>
      - Emits current user state changes
    - getCurrentUser(): suspend User?
      - Suspend function to fetch current user

Usage pattern:
- Subscribe to observeAuthState() to drive UI state
- Call login()/register() and collect Flow<UitResult<User>> to render loading/success/error
- Use getCurrentUser() for immediate access when needed

**Section sources**
- [AuthRepository.kt:1-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L1-L14)

### Authentication Use Cases
- LoginUseCase
  - Purpose: Encapsulates login business logic
  - invoke(email: String, password: String): Flow<UitResult<User>>
- RegisterUseCase
  - Purpose: Encapsulates registration business logic
  - invoke(email: String, password: String, displayName: String): Flow<UitResult<User>>
- LogoutUseCase
  - Purpose: Encapsulates logout business logic
  - invoke(): Flow<UitResult<Unit>>
- ObserveAuthStateUseCase
  - Purpose: Encapsulates observing authentication state
  - invoke(): Flow<User?>

Integration:
- Use cases delegate to AuthRepository
- Suitable for injection via DI frameworks

**Section sources**
- [LoginUseCase.kt:1-15](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L1-L15)
- [RegisterUseCase.kt:1-18](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt#L1-L18)
- [LogoutUseCase.kt:1-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LogoutUseCase.kt#L1-L13)
- [ObserveAuthStateUseCase.kt:1-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/ObserveAuthStateUseCase.kt#L1-L13)

### UI Component APIs

#### UitButton
- Parameters:
  - text: String
  - onClick: () -> Unit
  - modifier: Modifier (default: Modifier)
  - enabled: Boolean (default: true)
  - isLoading: Boolean (default: false)
  - backgroundColor: Color (default: UITBlue)
- Behavior:
  - Renders a Material3 Button
  - Disables interaction when isLoading is true
  - Shows a small CircularProgressIndicator when isLoading is true
- Customization:
  - Adjust backgroundColor and modifier to match theme

Usage example:
- Trigger actions during login/register flows
- Disable button while isLoading is true to prevent duplicate submissions

**Section sources**
- [UitButton.kt:1-42](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitButton.kt#L1-L42)

#### UitTextField
- Parameters:
  - value: String
  - onValueChange: (String) -> Unit
  - label: String
  - modifier: Modifier (default: Modifier)
  - enabled: Boolean (default: true)
  - isError: Boolean (default: false)
  - errorMessage: String? (default: null)
  - visualTransformation: VisualTransformation (default: VisualTransformation.None)
  - isPassword: Boolean (default: false)
  - maxLines: Int (default: 1)
- Behavior:
  - Material3 OutlinedTextField
  - Displays error message below the field when isError is true and errorMessage is provided
  - Single-line mode when maxLines == 1
- Customization:
  - Use isError and errorMessage to reflect validation feedback
  - Set isPassword to mask input

Usage example:
- Collect user input for login and registration forms
- Combine with validation helpers to set isError and errorMessage

**Section sources**
- [UitTextField.kt:1-52](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTextField.kt#L1-L52)

#### UitTopBar
- Parameters:
  - title: String
  - onBackClick: (() -> Unit)? (default: null)
  - actions: @Composable () -> Unit (default: empty lambda)
- Behavior:
  - Material3 CenterAlignedTopAppBar
  - Optional back navigation icon; visible only when onBackClick is provided
  - Supports custom actions composable

Usage example:
- Use in screens requiring navigation back
- Add icons or menus in actions slot

**Section sources**
- [UitTopBar.kt:1-43](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTopBar.kt#L1-L43)

#### EmptyView
- Parameters:
  - message: String (default: "No data available")
  - modifier: Modifier (default: Modifier)
- Behavior:
  - Centered empty state message using Material typography

Usage example:
- Display when lists or data loads return no items

**Section sources**
- [EmptyView.kt:1-31](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/EmptyView.kt#L1-L31)

#### ErrorView
- Parameters:
  - message: String
  - onRetry: (() -> Unit)? (default: null)
  - modifier: Modifier (default: Modifier)
- Behavior:
  - Centered error message with optional Retry button

Usage example:
- Show after failed network requests or operations
- Connect onRetry to trigger re-attempts

**Section sources**
- [ErrorView.kt:1-41](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/ErrorView.kt#L1-L41)

### Common Utilities and Extension Functions

#### UitResult<T>
- Sealed interface with three states:
  - Success<T>(data: T)
  - Error(exception: Throwable?, message: String?)
  - Loading
- Helper extensions:
  - getOrNull(): T?
  - getOrThrow(): T
  - onSuccess(action: (T) -> Unit): UitResult<T>
  - onError(action: (Throwable?, String?) -> Unit): UitResult<T>
  - isSuccess: Boolean
  - isError: Boolean
  - isLoading: Boolean

Usage example:
- Wrap repository results and propagate through use cases
- Use onSuccess/onError to branch UI rendering

**Section sources**
- [UitResult.kt:1-37](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L1-L37)

#### String Extensions
- isValidEmail(): Boolean
  - Validates basic email format
- truncate(maxLength: Int, suffix: String = "..."): String
  - Truncates long strings with suffix

Usage example:
- Validate user input before sending to repository
- Shorten long text for previews

**Section sources**
- [StringExt.kt:1-10](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/StringExt.kt#L1-L10)

#### Date Extensions
- Long.toFormattedDate(pattern: String = ...): String
  - Formats timestamps using a pattern
- Long.toRelativeTime(): String
  - Human-friendly relative time ("just now", "X minutes ago", etc.)

Usage example:
- Display post timestamps and relative freshness

**Section sources**
- [DateExt.kt:1-23](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/DateExt.kt#L1-L23)

#### Flow Extensions
- Flow<T>.asUitResult(): Flow<UitResult<T>>
  - Transforms a Flow<T> into Flow<UitResult<T>> by emitting Loading initially, Success on next, and Error on catch

Usage example:
- Wrap repository flows to unify UI rendering

**Section sources**
- [FlowExt.kt:1-13](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/FlowExt.kt#L1-L13)

#### Constants
- AppConstants
  - PAGE_SIZE: 20
  - MAX_IMAGE_WIDTH: 1080
  - MAX_IMAGE_HEIGHT: 1080
  - IMAGE_QUALITY: 80
  - SEARCH_DEBOUNCE_MS: 300L
  - MAX_HASHTAGS: 10
  - MAX_POST_LENGTH: 2000
  - MAX_COMMENT_LENGTH: 500

Usage example:
- Configure pagination and media constraints
- Enforce content length limits

**Section sources**
- [AppConstants.kt:1-13](file://core/core-common/src/main/kotlin/com/uit20years/core/common/constants/AppConstants.kt#L1-L13)

#### Dispatchers
- Qualifiers:
  - @IoDispatcher
  - @DefaultDispatcher
  - @MainDispatcher

Usage example:
- Inject appropriate dispatcher for coroutines using qualifiers

**Section sources**
- [Dispatchers.kt:1-16](file://core/core-common/src/main/kotlin/com/uit20years/core/common/dispatcher/Dispatchers.kt#L1-L16)

### Navigation Route APIs
- Route: Defines application routes
- AppNavHost: Hosts navigation graph and integrates with Route

Usage example:
- Define destinations in Route
- Wire up AppNavHost to render screens and handle deep links

**Section sources**
- [Route.kt](file://app/src/main/java/com/uit20years/app/navigation/Route.kt)
- [AppNavHost.kt](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt)

## Dependency Analysis
The following diagram shows how UI components depend on common utilities and how use cases depend on repositories.

```mermaid
graph LR
subgraph "UI"
BTN["UitButton"]
TF["UitTextField"]
TOPBAR["UitTopBar"]
EMPTY["EmptyView"]
ERROR["ErrorView"]
end
subgraph "Common"
RESULT["UitResult"]
STR_EXT["StringExt"]
DATE_EXT["DateExt"]
FLOW_EXT["FlowExt"]
CONST["AppConstants"]
DISP["Dispatchers"]
end
subgraph "Domain"
AR["AuthRepository"]
UC_LOGIN["LoginUseCase"]
UC_REGISTER["RegisterUseCase"]
UC_LOGOUT["LogoutUseCase"]
UC_OBSERVE["ObserveAuthStateUseCase"]
end
BTN --> RESULT
TF --> RESULT
TOPBAR --> RESULT
EMPTY --> RESULT
ERROR --> RESULT
STR_EXT --> RESULT
DATE_EXT --> RESULT
FLOW_EXT --> RESULT
UC_LOGIN --> AR
UC_REGISTER --> AR
UC_LOGOUT --> AR
UC_OBSERVE --> AR
```

**Diagram sources**
- [UitButton.kt:1-42](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitButton.kt#L1-L42)
- [UitTextField.kt:1-52](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTextField.kt#L1-L52)
- [UitTopBar.kt:1-43](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTopBar.kt#L1-L43)
- [EmptyView.kt:1-31](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/EmptyView.kt#L1-L31)
- [ErrorView.kt:1-41](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/ErrorView.kt#L1-L41)
- [UitResult.kt:1-37](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L1-L37)
- [StringExt.kt:1-10](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/StringExt.kt#L1-L10)
- [DateExt.kt:1-23](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/DateExt.kt#L1-L23)
- [FlowExt.kt:1-13](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/FlowExt.kt#L1-L13)
- [LoginUseCase.kt:1-15](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L1-L15)
- [RegisterUseCase.kt:1-18](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt#L1-L18)
- [LogoutUseCase.kt:1-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LogoutUseCase.kt#L1-L13)
- [ObserveAuthStateUseCase.kt:1-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/ObserveAuthStateUseCase.kt#L1-L13)
- [AuthRepository.kt:1-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L1-L14)

**Section sources**
- [UitButton.kt:1-42](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitButton.kt#L1-L42)
- [UitTextField.kt:1-52](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTextField.kt#L1-L52)
- [UitTopBar.kt:1-43](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTopBar.kt#L1-L43)
- [EmptyView.kt:1-31](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/EmptyView.kt#L1-L31)
- [ErrorView.kt:1-41](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/ErrorView.kt#L1-L41)
- [UitResult.kt:1-37](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L1-L37)
- [StringExt.kt:1-10](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/StringExt.kt#L1-L10)
- [DateExt.kt:1-23](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/DateExt.kt#L1-L23)
- [FlowExt.kt:1-13](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/FlowExt.kt#L1-L13)
- [LoginUseCase.kt:1-15](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L1-L15)
- [RegisterUseCase.kt:1-18](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt#L1-L18)
- [LogoutUseCase.kt:1-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LogoutUseCase.kt#L1-L13)
- [ObserveAuthStateUseCase.kt:1-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/ObserveAuthStateUseCase.kt#L1-L13)
- [AuthRepository.kt:1-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L1-L14)

## Performance Considerations
- Prefer Flow-based APIs for reactive UI updates to avoid redundant recompositions
- Use asUitResult() to unify UI rendering across different sources
- Apply debounce for search-related operations using AppConstants.SEARCH_DEBOUNCE_MS
- Limit image sizes using MAX_IMAGE_WIDTH/HEIGHT and IMAGE_QUALITY to reduce memory footprint
- Use qualifier dispatchers (@IoDispatcher/@DefaultDispatcher/@MainDispatcher) to offload heavy work appropriately

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
- Handling authentication errors:
  - Use observeAuthState() to react to sign-out or session invalidation
  - For login/register failures, check UitResult.Error and surface messages via ErrorView
- Input validation:
  - Use isValidEmail() before submitting forms
  - Use truncate() to enforce UI-friendly lengths
- Date/time display:
  - Use toRelativeTime() for recent activity; fallback to toFormattedDate() for older entries
- Flow emissions:
  - Ensure flows are collected properly; use asUitResult() to guarantee Loading/Error/Success transitions

**Section sources**
- [UitResult.kt:1-37](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L1-L37)
- [StringExt.kt:1-10](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/StringExt.kt#L1-L10)
- [DateExt.kt:1-23](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/DateExt.kt#L1-L23)
- [FlowExt.kt:1-13](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/FlowExt.kt#L1-L13)

## Conclusion
This API Reference consolidates the public interfaces and components essential for building and integrating with the UIT20Years Android application. By leveraging the repository interfaces, use cases, UI components, and common utilities, developers can implement robust authentication flows, responsive UIs, and maintainable navigation patterns.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### API Definition Tables

- Authentication Repository
  - login(email: String, password: String): Flow<UitResult<User>>
  - register(email: String, password: String, displayName: String): Flow<UitResult<User>>
  - logout(): Flow<UitResult<Unit>>
  - observeAuthState(): Flow<User?>
  - getCurrentUser(): suspend User?

- Use Cases
  - LoginUseCase.invoke(email: String, password: String): Flow<UitResult<User>>
  - RegisterUseCase.invoke(email: String, password: String, displayName: String): Flow<UitResult<User>>
  - LogoutUseCase.invoke(): Flow<UitResult<Unit>>
  - ObserveAuthStateUseCase.invoke(): Flow<User?>

- UI Components
  - UitButton(text: String, onClick: () -> Unit, modifier: Modifier = ..., enabled: Boolean = true, isLoading: Boolean = false, backgroundColor: Color = UITBlue)
  - UitTextField(value: String, onValueChange: (String) -> Unit, label: String, modifier: Modifier = ..., enabled: Boolean = true, isError: Boolean = false, errorMessage: String? = null, visualTransformation: VisualTransformation = VisualTransformation.None, isPassword: Boolean = false, maxLines: Int = 1)
  - UitTopBar(title: String, onBackClick: (() -> Unit)? = null, actions: @Composable () -> Unit = {})
  - EmptyView(message: String = "No data available", modifier: Modifier = ...)
  - ErrorView(message: String, onRetry: (() -> Unit)? = null, modifier: Modifier = ...)

- Common Utilities
  - UitResult<T>: Success<T>, Error, Loading; helpers getOrNull(), getOrThrow(), onSuccess(), onError(), isSuccess, isError, isLoading
  - String.isValidEmail(): Boolean
  - String.truncate(maxLength: Int, suffix: String = "..."): String
  - Long.toFormattedDate(pattern: String = ...): String
  - Long.toRelativeTime(): String
  - Flow<T>.asUitResult(): Flow<UitResult<T>>
  - AppConstants: PAGE_SIZE, MAX_IMAGE_WIDTH, MAX_IMAGE_HEIGHT, IMAGE_QUALITY, SEARCH_DEBOUNCE_MS, MAX_HASHTAGS, MAX_POST_LENGTH, MAX_COMMENT_LENGTH
  - Dispatchers: @IoDispatcher, @DefaultDispatcher, @MainDispatcher

**Section sources**
- [AuthRepository.kt:1-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L1-L14)
- [LoginUseCase.kt:1-15](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L1-L15)
- [RegisterUseCase.kt:1-18](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt#L1-L18)
- [LogoutUseCase.kt:1-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LogoutUseCase.kt#L1-L13)
- [ObserveAuthStateUseCase.kt:1-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/ObserveAuthStateUseCase.kt#L1-L13)
- [UitButton.kt:1-42](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitButton.kt#L1-L42)
- [UitTextField.kt:1-52](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTextField.kt#L1-L52)
- [UitTopBar.kt:1-43](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTopBar.kt#L1-L43)
- [EmptyView.kt:1-31](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/EmptyView.kt#L1-L31)
- [ErrorView.kt:1-41](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/ErrorView.kt#L1-L41)
- [UitResult.kt:1-37](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L1-L37)
- [StringExt.kt:1-10](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/StringExt.kt#L1-L10)
- [DateExt.kt:1-23](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/DateExt.kt#L1-L23)
- [FlowExt.kt:1-13](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/FlowExt.kt#L1-L13)
- [AppConstants.kt:1-13](file://core/core-common/src/main/kotlin/com/uit20years/core/common/constants/AppConstants.kt#L1-L13)
- [Dispatchers.kt:1-16](file://core/core-common/src/main/kotlin/com/uit20years/core/common/dispatcher/Dispatchers.kt#L1-L16)
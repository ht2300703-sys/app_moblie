# Repository Interfaces

<cite>
**Referenced Files in This Document**
- [AuthRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt)
- [EventRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/EventRepository.kt)
- [PostRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/PostRepository.kt)
- [UserRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/UserRepository.kt)
- [HeritageRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/HeritageRepository.kt)
- [NotificationRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/NotificationRepository.kt)
- [UitResult.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt)
- [AuthRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt)
- [EventRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/EventRepositoryImpl.kt)
- [PostRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/PostRepositoryImpl.kt)
- [UserRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/UserRepositoryImpl.kt)
- [HeritageRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/HeritageRepositoryImpl.kt)
- [NotificationRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/NotificationRepositoryImpl.kt)
- [DataModule.kt](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt)
- [LoginUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt)
- [LoginViewModel.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt)
- [RegisterViewModel.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document provides comprehensive API documentation for all repository interfaces located in the core-domain module. It covers the AuthRepository, EventRepository, PostRepository, UserRepository, HeritageRepository, and NotificationRepository interfaces, detailing method signatures, parameter descriptions, return value types, and Flow emission patterns. It also documents the UitResult wrapper pattern for consistent error handling across repository operations and demonstrates how ViewModels interact with these repositories via dependency injection using Hilt.

## Project Structure
The repository interfaces reside in the core-domain module under the package com.uit20years.core.domain.repository. Implementations are provided in the core-data module under com.uit20years.core.data.repository. The UitResult sealed interface resides in core-common under com.uit20years.core.common.result. Dependency binding is configured in core-data’s DataModule using Dagger Hilt’s @Binds annotations.

```mermaid
graph TB
subgraph "core-domain"
AD["AuthRepository.kt"]
ER["EventRepository.kt"]
PR["PostRepository.kt"]
UR["UserRepository.kt"]
HR["HeritageRepository.kt"]
NR["NotificationRepository.kt"]
end
subgraph "core-data"
ADI["AuthRepositoryImpl.kt"]
ERI["EventRepositoryImpl.kt"]
PRI["PostRepositoryImpl.kt"]
URI["UserRepositoryImpl.kt"]
HRI["HeritageRepositoryImpl.kt"]
NRI["NotificationRepositoryImpl.kt"]
DM["DataModule.kt"]
end
subgraph "core-common"
U["UitResult.kt"]
end
AD --> ADI
ER --> ERI
PR --> PRI
UR --> URI
HR --> HRI
NR --> NRI
DM --> AD
DM --> ER
DM --> PR
DM --> UR
DM --> HR
DM --> NR
ADI --> U
ERI --> U
PRI --> U
URI --> U
HRI --> U
NRI --> U
```

**Diagram sources**
- [AuthRepository.kt:1-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L1-L14)
- [EventRepository.kt:1-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/EventRepository.kt#L1-L14)
- [PostRepository.kt:1-18](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/PostRepository.kt#L1-L18)
- [UserRepository.kt:1-15](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/UserRepository.kt#L1-L15)
- [HeritageRepository.kt:1-12](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/HeritageRepository.kt#L1-L12)
- [NotificationRepository.kt:1-12](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/NotificationRepository.kt#L1-L12)
- [AuthRepositoryImpl.kt:1-147](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L1-L147)
- [EventRepositoryImpl.kt:1-38](file://core/core-data/src/main/java/com/uit20years/core/data/repository/EventRepositoryImpl.kt#L1-L38)
- [PostRepositoryImpl.kt:1-48](file://core/core-data/src/main/java/com/uit20years/core/data/repository/PostRepositoryImpl.kt#L1-L48)
- [UserRepositoryImpl.kt:1-97](file://core/core-data/src/main/java/com/uit20years/core/data/repository/UserRepositoryImpl.kt#L1-L97)
- [HeritageRepositoryImpl.kt:1-32](file://core/core-data/src/main/java/com/uit20years/core/data/repository/HeritageRepositoryImpl.kt#L1-L32)
- [NotificationRepositoryImpl.kt:1-32](file://core/core-data/src/main/java/com/uit20years/core/data/repository/NotificationRepositoryImpl.kt#L1-L32)
- [DataModule.kt:1-42](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt#L1-L42)
- [UitResult.kt:1-37](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L1-L37)

**Section sources**
- [AuthRepository.kt:1-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L1-L14)
- [EventRepository.kt:1-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/EventRepository.kt#L1-L14)
- [PostRepository.kt:1-18](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/PostRepository.kt#L1-L18)
- [UserRepository.kt:1-15](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/UserRepository.kt#L1-L15)
- [HeritageRepository.kt:1-12](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/HeritageRepository.kt#L1-L12)
- [NotificationRepository.kt:1-12](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/NotificationRepository.kt#L1-L12)
- [UitResult.kt:1-37](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L1-L37)
- [DataModule.kt:1-42](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt#L1-L42)

## Core Components
This section documents each repository interface with its methods, parameters, return types, and Flow emission patterns. It also explains the UitResult wrapper pattern used consistently across all repository operations.

- AuthRepository
  - Purpose: Authentication and user session management.
  - Methods:
    - login(email: String, password: String): Flow<UitResult<User>>
      - Emits Loading initially, followed by either Success(User) or Error(String).
    - register(email: String, password: String, displayName: String): Flow<UitResult<User>>
      - Emits Loading initially, followed by either Success(User) or Error(String).
    - logout(): Flow<UitResult<Unit>>
      - Emits Loading initially, followed by either Success(Unit) or Error(String).
    - observeAuthState(): Flow<User?>
      - Emits current signed-in User? when available; emits null on errors.
    - getCurrentUser(): suspend User?
      - Returns User? or null if unavailable or on error.
  - Error handling pattern: All methods return Flow<UitResult<T>>. Implementations emit Loading, then either Success(T) or Error(exception, message). Consumers should handle Loading, Success, and Error branches.

- EventRepository
  - Purpose: Event retrieval and registration management.
  - Methods:
    - getEvents(): Flow<UitResult<List<Event>>>
      - Emits Loading initially, followed by Success(List<Event>) or Error(String).
    - getEventById(eventId: String): Flow<UitResult<Event>>
      - Emits Loading initially, followed by Success(Event) or Error(String).
    - observeScoreboard(eventId: String): Flow<UitResult<Event>>
      - Emits Loading initially, then Success(Event) or Error(String).
    - registerForEvent(eventId: String, userId: String): Flow<UitResult<Unit>>
      - Emits Loading initially, followed by Success(Unit) or Error(String).
    - unregisterFromEvent(eventId: String, userId: String): Flow<UitResult<Unit>>
      - Emits Loading initially, followed by Success(Unit) or Error(String).

- PostRepository
  - Purpose: Social feed, post creation/deletion, likes, and comments.
  - Methods:
    - getGlobalFeed(pageSize: Int, lastPostId: String?): Flow<UitResult<List<Post>>>
      - Emits Loading initially, followed by Success(List<Post>) or Error(String).
    - getPersonalFeed(uid: String): Flow<UitResult<List<Post>>>
      - Emits Loading initially, followed by Success(List<Post>) or Error(String).
    - getPostById(postId: String): Flow<UitResult<Post>>
      - Emits Loading initially, followed by Success(Post) or Error(String).
    - createPost(post: Post, mediaBytes: List<ByteArray>): Flow<UitResult<String>>
      - Emits Loading initially, followed by Success(String postId) or Error(String).
    - deletePost(postId: String): Flow<UitResult<Unit>>
      - Emits Loading initially, followed by Success(Unit) or Error(String).
    - toggleLike(postId: String, userId: String): Flow<UitResult<Boolean>>
      - Emits Loading initially, followed by Success(Boolean isLiked) or Error(String).
    - getComments(postId: String): Flow<UitResult<List<Comment>>>
      - Emits Loading initially, followed by Success(List<Comment>) or Error(String).
    - addComment(postId: String, comment: Comment): Flow<UitResult<String>>
      - Emits Loading initially, followed by Success(String commentId) or Error(String).

- UserRepository
  - Purpose: User profile management and social actions.
  - Methods:
    - getUser(uid: String): Flow<UitResult<User>>
      - Emits Loading initially, followed by Success(User) or Error(String).
    - updateProfile(user: User): Flow<UitResult<Unit>>
      - Emits Loading initially, followed by Success(Unit) or Error(String).
    - followUser(targetUid: String): Flow<UitResult<Unit>>
      - Emits Loading initially, followed by Success(Unit) or Error(String).
    - unfollowUser(targetUid: String): Flow<UitResult<Unit>>
      - Emits Loading initially, followed by Success(Unit) or Error(String).
    - getFollowers(uid: String): Flow<UitResult<List<User>>>
      - Emits Loading initially, followed by Success(List<User>) or Error(String).
    - getFollowing(uid: String): Flow<UitResult<List<User>>>
      - Emits Loading initially, followed by Success(List<User>) or Error(String).

- HeritageRepository
  - Purpose: Timeline and heritage item retrieval/search.
  - Methods:
    - getTimeline(): Flow<UitResult<List<Heritage>>>
      - Emits Loading initially, followed by Success(List<Heritage>) or Error(String).
    - getHeritageById(id: String): Flow<UitResult<Heritage>>
      - Emits Loading initially, followed by Success(Heritage) or Error(String).
    - searchHeritage(query: String): Flow<UitResult<List<Heritage>>>
      - Emits Loading initially, followed by Success(List<Heritage>) or Error(String).

- NotificationRepository
  - Purpose: Notification retrieval and read status management.
  - Methods:
    - getNotifications(userId: String): Flow<UitResult<List<Notification>>>
      - Emits Loading initially, followed by Success(List<Notification>) or Error(String).
    - markAsRead(notificationId: String): Flow<UitResult<Unit>>
      - Emits Loading initially, followed by Success(Unit) or Error(String).
    - markAllAsRead(userId: String): Flow<UitResult<Unit>>
      - Emits Loading initially, followed by Success(Unit) or Error(String).

- UitResult Wrapper Pattern
  - Sealed interface with three states:
    - Success<T>(data: T)
    - Error(exception: Throwable?, message: String?)
    - Loading (data object)
  - Utility extensions:
    - getOrNull(): T? — returns data for Success, otherwise null
    - getOrThrow(): T — returns data for Success, throws for Error or Loading
    - onSuccess(action: (T) -> Unit): UitResult<T> — executes action on Success
    - onError(action: (Throwable?, String?) -> Unit): UitResult<T> — executes action on Error
    - isSuccess/isError/isLoading: Boolean — state checks
  - Usage pattern: All repository methods return Flow<UitResult<T>>. Implementations emit Loading first, then either Success or Error. Consumers should branch on state to handle UI updates and error messages.

**Section sources**
- [AuthRepository.kt:7-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L7-L13)
- [EventRepository.kt:7-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/EventRepository.kt#L7-L13)
- [PostRepository.kt:8-17](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/PostRepository.kt#L8-L17)
- [UserRepository.kt:7-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/UserRepository.kt#L7-L14)
- [HeritageRepository.kt:7-11](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/HeritageRepository.kt#L7-L11)
- [NotificationRepository.kt:7-11](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/NotificationRepository.kt#L7-L11)
- [UitResult.kt:3-11](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L3-L11)
- [UitResult.kt:13-37](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L13-L37)

## Architecture Overview
The repository interfaces define the domain contract. Implementations in core-data encapsulate platform-specific logic (Firebase, Firestore, etc.) and expose results via UitResult. Dependency injection binds implementations to interfaces at runtime. Use cases orchestrate repository calls and ViewModels collect Flow emissions to drive UI state.

```mermaid
sequenceDiagram
participant VM as "LoginViewModel"
participant UC as "LoginUseCase"
participant AR as "AuthRepository"
participant IMPL as "AuthRepositoryImpl"
VM->>UC : invoke(email, password)
UC->>AR : login(email, password)
AR->>IMPL : login(email, password)
IMPL-->>AR : Flow<UitResult<User>>
AR-->>UC : Flow<UitResult<User>>
UC-->>VM : Flow<UitResult<User>>
VM->>VM : collect { Loading | Success | Error }
```

**Diagram sources**
- [LoginViewModel.kt:72-94](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L72-L94)
- [LoginUseCase.kt:12-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L12-L13)
- [AuthRepository.kt:8-8](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L8-L8)
- [AuthRepositoryImpl.kt:29-55](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L29-L55)

**Section sources**
- [DataModule.kt:24-25](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt#L24-L25)
- [LoginUseCase.kt:9-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L9-L14)
- [LoginViewModel.kt:21-23](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L21-L23)

## Detailed Component Analysis

### AuthRepository
- Methods and behavior:
  - login(email: String, password: String): Flow<UitResult<User>>
    - Emits Loading, then Success(User) if credentials are valid and profile exists, or Error(String) for invalid credentials or connectivity issues.
  - register(email: String, password: String, displayName: String): Flow<UitResult<User>>
    - Emits Loading, then Success(User) after creating account and persisting profile, or Error(String) for duplicate email or persistence failures.
  - logout(): Flow<UitResult<Unit>>
    - Emits Loading, then Success(Unit) after signing out, or Error(String) on failure.
  - observeAuthState(): Flow<User?>
    - Emits current User? when signed in; emits null on sign-out or errors.
  - getCurrentUser(): suspend User?
    - Returns User? or null if unavailable.
- Implementation highlights:
  - Uses FirebaseAuthService and FirestoreService.
  - Emits UitResult.Error with localized messages for specific exceptions.
  - observeAuthState maps Firebase user to domain User and handles missing profiles gracefully.

```mermaid
flowchart TD
Start(["login() called"]) --> EmitLoading["Emit Loading"]
EmitLoading --> SignIn["Sign in with email/password"]
SignIn --> SignedIn{"Signed in?"}
SignedIn --> |No| EmitError["Emit Error('Login failed')"]
SignedIn --> |Yes| FetchProfile["Fetch user document by uid"]
FetchProfile --> Found{"Profile exists?"}
Found --> |No| EmitError2["Emit Error('User profile not found')"]
Found --> |Yes| EmitSuccess["Emit Success(User)"]
EmitError --> End(["Exit"])
EmitError2 --> End
EmitSuccess --> End
```

**Diagram sources**
- [AuthRepositoryImpl.kt:29-55](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L29-L55)

**Section sources**
- [AuthRepository.kt:8-12](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L8-L12)
- [AuthRepositoryImpl.kt:29-133](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L29-L133)

### EventRepository
- Methods and behavior:
  - getEvents(): Flow<UitResult<List<Event>>>
    - Placeholder implementation emits Loading then Success(emptyList()) or Error("Not implemented").
  - getEventById(eventId: String): Flow<UitResult<Event>>
    - Placeholder implementation emits Loading then Error("Not implemented").
  - observeScoreboard(eventId: String): Flow<UitResult<Event>>
    - Placeholder implementation emits Loading then Success(Event) or Error(String).
  - registerForEvent(eventId: String, userId: String): Flow<UitResult<Unit>>
    - Placeholder implementation emits Loading then Success(Unit).
  - unregisterFromEvent(eventId: String, userId: String): Flow<UitResult<Unit>>
    - Placeholder implementation emits Loading then Success(Unit).
- Notes:
  - Current implementation is stubbed; production logic should integrate with Firestore.

**Section sources**
- [EventRepository.kt:8-12](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/EventRepository.kt#L8-L12)
- [EventRepositoryImpl.kt:14-36](file://core/core-data/src/main/java/com/uit20years/core/data/repository/EventRepositoryImpl.kt#L14-L36)

### PostRepository
- Methods and behavior:
  - getGlobalFeed(pageSize: Int, lastPostId: String?): Flow<UitResult<List<Post>>>
    - Placeholder implementation emits Loading then Success(emptyList()).
  - getPersonalFeed(uid: String): Flow<UitResult<List<Post>>>
    - Placeholder implementation emits Loading then Success(emptyList()).
  - getPostById(postId: String): Flow<UitResult<Post>>
    - Placeholder implementation emits Loading then Success(Post) or Error(String).
  - createPost(post: Post, mediaBytes: List<ByteArray>): Flow<UitResult<String>>
    - Placeholder implementation emits Loading then Success(postId) or Error(String).
  - deletePost(postId: String): Flow<UitResult<Unit>>
    - Placeholder implementation emits Loading then Success(Unit).
  - toggleLike(postId: String, userId: String): Flow<UitResult<Boolean>>
    - Placeholder implementation emits Loading then Success(isLiked) or Error(String).
  - getComments(postId: String): Flow<UitResult<List<Comment>>>
    - Placeholder implementation emits Loading then Success(comments) or Error(String).
  - addComment(postId: String, comment: Comment): Flow<UitResult<String>>
    - Placeholder implementation emits Loading then Success(commentId) or Error(String).
- Notes:
  - Current implementation is stubbed; production logic should integrate with Firestore.

**Section sources**
- [PostRepository.kt:9-17](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/PostRepository.kt#L9-L17)
- [PostRepositoryImpl.kt:14-46](file://core/core-data/src/main/java/com/uit20years/core/data/repository/PostRepositoryImpl.kt#L14-L46)

### UserRepository
- Methods and behavior:
  - getUser(uid: String): Flow<UitResult<User>>
    - Emits Loading, then Success(User) if document exists, or Error("User not found") or Error(exception).
  - updateProfile(user: User): Flow<UitResult<Unit>>
    - Emits Loading, then Success(Unit) after merging profile into Firestore, or Error(exception).
  - followUser(targetUid: String): Flow<UitResult<Unit>>
    - Placeholder implementation emits Loading then Success(Unit).
  - unfollowUser(targetUid: String): Flow<UitResult<Unit>>
    - Placeholder implementation emits Loading then Success(Unit).
  - getFollowers(uid: String): Flow<UitResult<List<User>>>
    - Placeholder implementation emits Loading then Success(emptyList()).
  - getFollowing(uid: String): Flow<UitResult<List<User>>>
    - Placeholder implementation emits Loading then Success(emptyList()).
- Notes:
  - Current implementation is stubbed for follow/unfollow and follower/following queries; production logic should integrate with Firestore.

**Section sources**
- [UserRepository.kt:8-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/UserRepository.kt#L8-L13)
- [UserRepositoryImpl.kt:22-83](file://core/core-data/src/main/java/com/uit20years/core/data/repository/UserRepositoryImpl.kt#L22-L83)

### HeritageRepository
- Methods and behavior:
  - getTimeline(): Flow<UitResult<List<Heritage>>>
    - Placeholder implementation emits Loading then Success(emptyList()).
  - getHeritageById(id: String): Flow<UitResult<Heritage>>
    - Placeholder implementation emits Loading then Error("Not implemented").
  - searchHeritage(query: String): Flow<UitResult<List<Heritage>>>
    - Placeholder implementation emits Loading then Success(emptyList()).
- Notes:
  - Current implementation is stubbed; production logic should integrate with Firestore or Algolia.

**Section sources**
- [HeritageRepository.kt:8-10](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/HeritageRepository.kt#L8-L10)
- [HeritageRepositoryImpl.kt:14-30](file://core/core-data/src/main/java/com/uit20years/core/data/repository/HeritageRepositoryImpl.kt#L14-L30)

### NotificationRepository
- Methods and behavior:
  - getNotifications(userId: String): Flow<UitResult<List<Notification>>>
    - Placeholder implementation emits Loading then Success(emptyList()).
  - markAsRead(notificationId: String): Flow<UitResult<Unit>>
    - Placeholder implementation emits Loading then Success(Unit).
  - markAllAsRead(userId: String): Flow<UitResult<Unit>>
    - Placeholder implementation emits Loading then Success(Unit).
- Notes:
  - Current implementation is stubbed; production logic should integrate with Firestore.

**Section sources**
- [NotificationRepository.kt:8-10](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/NotificationRepository.kt#L8-L10)
- [NotificationRepositoryImpl.kt:14-30](file://core/core-data/src/main/java/com/uit20years/core/data/repository/NotificationRepositoryImpl.kt#L14-L30)

### UitResult Wrapper Pattern
- States:
  - Success<T>(data: T)
  - Error(exception: Throwable?, message: String?)
  - Loading (data object)
- Utilities:
  - getOrNull(), getOrThrow(), onSuccess(), onError(), isSuccess, isError, isLoading
- Usage:
  - Repositories emit Loading then Success or Error.
  - ViewModels collect Flow<UitResult<T>> and branch on state to update UI and handle errors.

**Section sources**
- [UitResult.kt:3-11](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L3-L11)
- [UitResult.kt:13-37](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L13-L37)

### ViewModel Interaction and Dependency Injection
- Dependency injection:
  - DataModule binds each AuthRepository, EventRepository, PostRepository, UserRepository, HeritageRepository, and NotificationRepository to their implementations.
- ViewModel usage:
  - LoginViewModel depends on LoginUseCase, which depends on AuthRepository. It collects Flow<UitResult<User>> and reacts to Loading, Success(User), and Error(String).
  - RegisterViewModel similarly depends on RegisterUseCase and AuthRepository, collecting Flow<UitResult<User>> to navigate on success or show error messages.

```mermaid
classDiagram
class AuthRepository {
+login(email, password) Flow~UitResult<User>~
+register(email, password, displayName) Flow~UitResult<User>~
+logout() Flow~UitResult<Unit>~
+observeAuthState() Flow~User?~
+getCurrentUser() suspend User?
}
class AuthRepositoryImpl {
+login(...)
+register(...)
+logout()
+observeAuthState()
+getCurrentUser()
}
class LoginViewModel {
-loginUseCase : LoginUseCase
+onEvent(...)
+collect Flow~UitResult<User>~
}
class LoginUseCase {
+invoke(email, password) Flow~UitResult<User>~
}
AuthRepository <|.. AuthRepositoryImpl
LoginUseCase --> AuthRepository : "depends on"
LoginViewModel --> LoginUseCase : "uses"
```

**Diagram sources**
- [AuthRepository.kt:7-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L7-L13)
- [AuthRepositoryImpl.kt:24-133](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L24-L133)
- [LoginUseCase.kt:9-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L9-L14)
- [LoginViewModel.kt:21-23](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L21-L23)

**Section sources**
- [DataModule.kt:24-40](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt#L24-L40)
- [LoginViewModel.kt:72-94](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L72-L94)
- [RegisterViewModel.kt:112-133](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt#L112-L133)

## Dependency Analysis
- Binding relationships:
  - DataModule @Binds each repository interface to its implementation in Singleton scope.
- Coupling:
  - ViewModels depend on use cases, which depend on repository interfaces, maintaining clean separation of concerns.
- Cohesion:
  - Each repository encapsulates a cohesive set of operations for a domain concept.

```mermaid
graph LR
DM["DataModule"] --> AR["AuthRepository"]
DM --> ER["EventRepository"]
DM --> PR["PostRepository"]
DM --> UR["UserRepository"]
DM --> HR["HeritageRepository"]
DM --> NR["NotificationRepository"]
AR --> ARImpl["AuthRepositoryImpl"]
ER --> ERImpl["EventRepositoryImpl"]
PR --> PRImpl["PostRepositoryImpl"]
UR --> URImpl["UserRepositoryImpl"]
HR --> HRImpl["HeritageRepositoryImpl"]
NR --> NRImpl["NotificationRepositoryImpl"]
```

**Diagram sources**
- [DataModule.kt:24-40](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt#L24-L40)

**Section sources**
- [DataModule.kt:24-40](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt#L24-L40)

## Performance Considerations
- Prefer emitting Loading early to provide immediate feedback to UI.
- Use pagination parameters (e.g., pageSize, lastPostId) to limit payload sizes in feed queries.
- Cache frequently accessed data (e.g., current user) to reduce repeated network calls.
- Avoid unnecessary Flow transformations; keep pipelines minimal to reduce overhead.
- For real-time features, leverage Firestore streams and map only required fields to minimize bandwidth.

## Troubleshooting Guide
- Common error scenarios:
  - Authentication failures: Invalid credentials or user not found; check repository error messages and exception mapping.
  - Network/database errors: FirebaseFirestoreException mapped to localized messages; ensure connectivity and Firestore rules.
  - Missing profile data: observeAuthState gracefully returns null when user document is absent.
- Debugging tips:
  - Inspect emitted states in ViewModels: Loading indicates async operation; Error contains message; Success contains data.
  - Use UitResult utilities to safely extract data or throw on error for testing.
  - Verify DI bindings in DataModule to ensure correct implementations are injected.

**Section sources**
- [AuthRepositoryImpl.kt:48-54](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L48-L54)
- [AuthRepositoryImpl.kt:81-87](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L81-L87)
- [AuthRepositoryImpl.kt:100-114](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L100-L114)
- [UitResult.kt:18-22](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L18-L22)

## Conclusion
The repository interfaces define a consistent, testable domain layer with Flow-based APIs and a unified UitResult error-handling pattern. Implementations in core-data encapsulate platform-specific logic while preserving the interface contracts. Dependency injection ensures loose coupling between ViewModels, use cases, and repositories, enabling scalable and maintainable feature development.
# Core Domain

<cite>
**Referenced Files in This Document**
- [AuthRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt)
- [EventRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/EventRepository.kt)
- [HeritageRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/HeritageRepository.kt)
- [NotificationRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/NotificationRepository.kt)
- [PostRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/PostRepository.kt)
- [UserRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/UserRepository.kt)
- [LoginUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt)
- [LogoutUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LogoutUseCase.kt)
- [ObserveAuthStateUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/ObserveAuthStateUseCase.kt)
- [RegisterUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt)
- [GetCurrentUserUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/GetCurrentUserUseCase.kt)
- [UitResult.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt)
- [User.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt)
- [Event.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Event.kt)
- [Heritage.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Heritage.kt)
- [Notification.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Notification.kt)
- [Post.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Post.kt)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document describes the core-domain module of the UIT20Years application. It focuses on the business logic and use cases that encapsulate the application’s domain concerns. The module defines repository interfaces for six domains: Authentication, Events, Heritage, Notifications, Posts, and Users. It also documents the use cases orchestrating these repositories, the Unidirectional Data Flow (UDF) patterns, and the Channel effects approach via Kotlin Flows and UitResult. The goal is to help developers understand how business rules are enforced, how state is managed, and how the presentation layer integrates with the domain layer.

## Project Structure
The core-domain module organizes domain logic into two primary packages:
- repository: Defines typed contracts for each domain area, returning reactive streams of results.
- usecase: Implements business logic as small, focused use cases that delegate to repositories.

```mermaid
graph TB
subgraph "core-domain"
subgraph "repository"
AR["AuthRepository.kt"]
ER["EventRepository.kt"]
HR["HeritageRepository.kt"]
NR["NotificationRepository.kt"]
PR["PostRepository.kt"]
UR["UserRepository.kt"]
end
subgraph "usecase"
subgraph "auth"
LU["LoginUseCase.kt"]
RU["RegisterUseCase.kt"]
OU["LogoutUseCase.kt"]
OAU["ObserveAuthStateUseCase.kt"]
end
CGU["GetCurrentUserUseCase.kt"]
end
end
subgraph "core-model"
MU["User.kt"]
ME["Event.kt"]
MH["Heritage.kt"]
MN["Notification.kt"]
MP["Post.kt"]
end
subgraph "core-common"
URes["UitResult.kt"]
end
LU --> AR
RU --> AR
OU --> AR
OAU --> AR
CGU --> AR
AR --- URes
ER --- URes
HR --- URes
NR --- URes
PR --- URes
UR --- URes
AR --- MU
ER --- ME
HR --- MH
NR --- MN
PR --- MP
```

**Diagram sources**
- [AuthRepository.kt:1-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L1-L14)
- [EventRepository.kt:1-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/EventRepository.kt#L1-L14)
- [HeritageRepository.kt:1-12](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/HeritageRepository.kt#L1-L12)
- [NotificationRepository.kt:1-12](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/NotificationRepository.kt#L1-L12)
- [PostRepository.kt:1-18](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/PostRepository.kt#L1-L18)
- [UserRepository.kt:1-15](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/UserRepository.kt#L1-L15)
- [LoginUseCase.kt:1-15](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L1-L15)
- [RegisterUseCase.kt:1-18](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt#L1-L18)
- [LogoutUseCase.kt:1-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LogoutUseCase.kt#L1-L13)
- [ObserveAuthStateUseCase.kt:1-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/ObserveAuthStateUseCase.kt#L1-L13)
- [GetCurrentUserUseCase.kt:1-23](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/GetCurrentUserUseCase.kt#L1-L23)
- [User.kt:1-23](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt#L1-L23)
- [Event.kt:1-28](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Event.kt#L1-L28)
- [Heritage.kt:1-21](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Heritage.kt#L1-L21)
- [Notification.kt:1-22](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Notification.kt#L1-L22)
- [Post.kt:1-23](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Post.kt#L1-L23)
- [UitResult.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt)

**Section sources**
- [AuthRepository.kt:1-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L1-L14)
- [EventRepository.kt:1-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/EventRepository.kt#L1-L14)
- [HeritageRepository.kt:1-12](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/HeritageRepository.kt#L1-L12)
- [NotificationRepository.kt:1-12](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/NotificationRepository.kt#L1-L12)
- [PostRepository.kt:1-18](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/PostRepository.kt#L1-L18)
- [UserRepository.kt:1-15](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/UserRepository.kt#L1-L15)

## Core Components
This section outlines the repository interfaces and their responsibilities, along with the use cases that implement the business logic.

- AuthRepository
  - Responsibilities: Authenticate users, register new users, track current user session, and observe authentication state.
  - Contracts: Methods return reactive streams of results and optional current user snapshots.
  - Related model: User.

- EventRepository
  - Responsibilities: Retrieve events, observe live event updates (scoreboard), and manage registration/unregistration for events.
  - Contracts: Stream lists or single items with result wrappers.
  - Related model: Event.

- HeritageRepository
  - Responsibilities: Fetch timeline items, fetch by ID, and search heritage content.
  - Contracts: Stream lists or single items with result wrappers.
  - Related model: Heritage.

- NotificationRepository
  - Responsibilities: Fetch notifications for a user, mark individual or all notifications as read.
  - Contracts: Stream lists or unit results with result wrappers.
  - Related model: Notification.

- PostRepository
  - Responsibilities: Feed pagination, personal feed, post retrieval, creation/deletion, likes toggling, comments retrieval, and adding comments.
  - Contracts: Stream lists or single items with result wrappers; creation returns identifiers.
  - Related models: Post, Comment.

- UserRepository
  - Responsibilities: Fetch user profiles, update profile, follow/unfollow users, and retrieve followers/following lists.
  - Contracts: Stream single items or lists with result wrappers.
  - Related model: User.

- Use Cases
  - Authentication use cases: Login, Logout, Register, ObserveAuthState. They directly delegate to AuthRepository.
  - Other use cases: GetCurrentUserUseCase wraps repository calls with explicit loading and error signaling.

**Section sources**
- [AuthRepository.kt:7-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L7-L13)
- [EventRepository.kt:7-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/EventRepository.kt#L7-L13)
- [HeritageRepository.kt:7-11](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/HeritageRepository.kt#L7-L11)
- [NotificationRepository.kt:7-11](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/NotificationRepository.kt#L7-L11)
- [PostRepository.kt:8-17](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/PostRepository.kt#L8-L17)
- [UserRepository.kt:7-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/UserRepository.kt#L7-L14)
- [LoginUseCase.kt:9-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L9-L14)
- [LogoutUseCase.kt:8-12](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LogoutUseCase.kt#L8-L12)
- [ObserveAuthStateUseCase.kt:8-12](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/ObserveAuthStateUseCase.kt#L8-L12)
- [RegisterUseCase.kt:9-17](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt#L9-L17)
- [GetCurrentUserUseCase.kt:10-22](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/GetCurrentUserUseCase.kt#L10-L22)

## Architecture Overview
The domain layer follows a Unidirectional Data Flow (UDF) pattern:
- Presentation triggers use cases via ViewModel or similar orchestrators.
- Use cases call repository interfaces to fetch or mutate data.
- Repositories return reactive streams (Flow) of UitResult<T>, enabling the presentation to reactively render Loading, Success, or Error states.
- The Channel effects pattern is realized through Flow emissions and transformations, allowing side effects to be expressed as data streams.

```mermaid
graph TB
VM["Presentation Layer<br/>ViewModel/Screen"] --> UC["Use Case"]
UC --> Repo["Repository Interface"]
Repo --> DS["Data Source<br/>(Firebase/Cloud/Local)"]
DS --> Repo
Repo --> UC
UC --> VM
VM --> |"Render"| UI["UI"]
subgraph "Domain"
UC
Repo
end
subgraph "Data"
DS
end
```

[No sources needed since this diagram shows conceptual workflow, not actual code structure]

## Detailed Component Analysis

### Authentication Domain
- Repository contract: login, register, logout, observeAuthState, getCurrentUser.
- Use cases:
  - LoginUseCase: delegates to AuthRepository.login.
  - RegisterUseCase: delegates to AuthRepository.register.
  - LogoutUseCase: delegates to AuthRepository.logout.
  - ObserveAuthStateUseCase: delegates to AuthRepository.observeAuthState.
  - GetCurrentUserUseCase: emits a Loading state, then either Success(current user) or Error if missing.

```mermaid
classDiagram
class AuthRepository {
+login(email, password) Flow~UitResult~User~~
+register(email, password, displayName) Flow~UitResult~User~~
+logout() Flow~UitResult~Unit~~
+observeAuthState() Flow~User?~
+getCurrentUser() suspend User?
}
class LoginUseCase {
+invoke(email, password) Flow~UitResult~User~~
}
class RegisterUseCase {
+invoke(email, password, displayName) Flow~UitResult~User~~
}
class LogoutUseCase {
+invoke() Flow~UitResult~Unit~~
}
class ObserveAuthStateUseCase {
+invoke() Flow~User?~
}
class GetCurrentUserUseCase {
+invoke() Flow~UitResult~User~~
}
LoginUseCase --> AuthRepository : "delegates"
RegisterUseCase --> AuthRepository : "delegates"
LogoutUseCase --> AuthRepository : "delegates"
ObserveAuthStateUseCase --> AuthRepository : "delegates"
GetCurrentUserUseCase --> AuthRepository : "calls"
```

**Diagram sources**
- [AuthRepository.kt:7-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L7-L13)
- [LoginUseCase.kt:9-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L9-L14)
- [RegisterUseCase.kt:9-17](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt#L9-L17)
- [LogoutUseCase.kt:8-12](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LogoutUseCase.kt#L8-L12)
- [ObserveAuthStateUseCase.kt:8-12](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/ObserveAuthStateUseCase.kt#L8-L12)
- [GetCurrentUserUseCase.kt:10-22](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/GetCurrentUserUseCase.kt#L10-L22)

```mermaid
sequenceDiagram
participant UI as "Presentation"
participant UC as "LoginUseCase"
participant AR as "AuthRepository"
UI->>UC : invoke(email, password)
UC->>AR : login(email, password)
AR-->>UC : Flow<UitResult<User>>
UC-->>UI : Flow<UitResult<User>>
UI-->>UI : Render Loading/Success/Error
```

**Diagram sources**
- [LoginUseCase.kt:12-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L12-L13)
- [AuthRepository.kt:8-8](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L8-L8)

**Section sources**
- [AuthRepository.kt:7-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L7-L13)
- [LoginUseCase.kt:9-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L9-L14)
- [RegisterUseCase.kt:9-17](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt#L9-L17)
- [LogoutUseCase.kt:8-12](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LogoutUseCase.kt#L8-L12)
- [ObserveAuthStateUseCase.kt:8-12](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/ObserveAuthStateUseCase.kt#L8-L12)
- [GetCurrentUserUseCase.kt:10-22](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/GetCurrentUserUseCase.kt#L10-L22)

### Events Domain
- Repository contract: getEvents, getEventById, observeScoreboard, registerForEvent, unregisterFromEvent.
- Business logic patterns:
  - Use cases can enforce preconditions (e.g., check registration limits) before delegating to repositories.
  - Live updates are handled via observeScoreboard, enabling real-time UI updates.

```mermaid
flowchart TD
Start(["Event Use Case Entry"]) --> Validate["Validate Inputs<br/>and Business Rules"]
Validate --> Valid{"Valid?"}
Valid --> |No| EmitError["Emit Error via UitResult"]
Valid --> |Yes| CallRepo["Call EventRepository"]
CallRepo --> RepoResult{"Repository Result"}
RepoResult --> |Success| Transform["Transform to Domain Model"]
RepoResult --> |Failure| EmitError
Transform --> EmitSuccess["Emit Success via Flow"]
EmitError --> End(["Exit"])
EmitSuccess --> End
```

**Diagram sources**
- [EventRepository.kt:7-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/EventRepository.kt#L7-L13)

**Section sources**
- [EventRepository.kt:7-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/EventRepository.kt#L7-L13)

### Heritage Domain
- Repository contract: getTimeline, getHeritageById, searchHeritage.
- Patterns:
  - Search queries can be debounced upstream in presentation or use repository-provided filtering.
  - Timeline pagination can be modeled as a cursor-based stream.

**Section sources**
- [HeritageRepository.kt:7-11](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/HeritageRepository.kt#L7-L11)

### Notifications Domain
- Repository contract: getNotifications, markAsRead, markAllAsRead.
- Patterns:
  - Mark-as-read operations can be batched or triggered per notification depending on UX needs.
  - Read/unread state is reflected in the Notification model.

**Section sources**
- [NotificationRepository.kt:7-11](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/NotificationRepository.kt#L7-L11)
- [Notification.kt:1-22](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Notification.kt#L1-L22)

### Posts Domain
- Repository contract: global/personal feeds, post retrieval, creation/deletion, likes toggling, comments retrieval, adding comments.
- Patterns:
  - Pagination can be implemented with last-seen identifiers.
  - Like toggling returns a boolean indicating the new state.
  - Comments retrieval supports threaded discussions.

**Section sources**
- [PostRepository.kt:8-17](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/PostRepository.kt#L8-L17)
- [Post.kt:1-23](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Post.kt#L1-L23)

### Users Domain
- Repository contract: getUser, updateProfile, follow/unfollow, getFollowers/getFollowing.
- Patterns:
  - Follow/unfollow can trigger side effects (notifications, counters) handled by repositories.
  - Profile updates can be validated before delegation.

**Section sources**
- [UserRepository.kt:7-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/UserRepository.kt#L7-L14)
- [User.kt:1-23](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt#L1-L23)

## Dependency Analysis
- Cohesion: Each repository interface encapsulates a single domain concern, keeping responsibilities focused.
- Coupling: Use cases depend on repository interfaces, not implementations, promoting testability and inversion of control.
- Reactive Streams: All repositories return Flow<UitResult<T>>, ensuring consistent error and state handling across domains.
- Entities: Domain models are stable and used across repositories and use cases.

```mermaid
graph LR
subgraph "Use Cases"
A["Auth Use Cases"]
GCU["GetCurrentUserUseCase"]
E["Event Use Cases"]
H["Heritage Use Cases"]
N["Notification Use Cases"]
P["Post Use Cases"]
U["User Use Cases"]
end
subgraph "Repositories"
AR["AuthRepository"]
ER["EventRepository"]
HR["HeritageRepository"]
NR["NotificationRepository"]
PR["PostRepository"]
UR["UserRepository"]
end
A --> AR
GCU --> AR
E --> ER
H --> HR
N --> NR
P --> PR
U --> UR
```

**Diagram sources**
- [LoginUseCase.kt:9-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L9-L14)
- [LogoutUseCase.kt:8-12](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LogoutUseCase.kt#L8-L12)
- [ObserveAuthStateUseCase.kt:8-12](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/ObserveAuthStateUseCase.kt#L8-L12)
- [RegisterUseCase.kt:9-17](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt#L9-L17)
- [GetCurrentUserUseCase.kt:10-22](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/GetCurrentUserUseCase.kt#L10-L22)
- [EventRepository.kt:7-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/EventRepository.kt#L7-L13)
- [HeritageRepository.kt:7-11](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/HeritageRepository.kt#L7-L11)
- [NotificationRepository.kt:7-11](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/NotificationRepository.kt#L7-L11)
- [PostRepository.kt:8-17](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/PostRepository.kt#L8-L17)
- [UserRepository.kt:7-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/UserRepository.kt#L7-L14)
- [AuthRepository.kt:7-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L7-L13)

**Section sources**
- [UitResult.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt)

## Performance Considerations
- Prefer streaming updates (observe*) for real-time features to minimize polling overhead.
- Use pagination strategies (cursor/page size) to limit payload sizes in feeds.
- Debounce search queries to reduce network churn.
- Cache frequently accessed entities (e.g., current user) to avoid repeated repository calls.
- Keep use cases thin; offload heavy transformations to mappers or services to maintain responsiveness.

## Troubleshooting Guide
- Authentication state not updating:
  - Verify ObserveAuthStateUseCase is emitting and the presentation subscribes to the Flow.
  - Confirm AuthRepository.observeAuthState is emitting non-null values after successful login.
- Login/Registration failures:
  - Inspect emitted UitResult.Error payloads and surface user-friendly messages.
  - Ensure credentials meet backend requirements before invoking use cases.
- Current user missing:
  - GetCurrentUserUseCase emits an explicit error when no user is found; handle this in presentation to redirect to login.
- Event scoreboard not reflecting changes:
  - Ensure observeScoreboard is subscribed and that repository emits updates on data change.
- Notification read state:
  - Confirm markAsRead/markAllAsRead are invoked and repository reflects the updated isRead flag.

**Section sources**
- [ObserveAuthStateUseCase.kt:8-12](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/ObserveAuthStateUseCase.kt#L8-L12)
- [GetCurrentUserUseCase.kt:13-21](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/GetCurrentUserUseCase.kt#L13-L21)
- [EventRepository.kt:10-10](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/EventRepository.kt#L10-L10)
- [NotificationRepository.kt:8-10](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/NotificationRepository.kt#L8-L10)

## Conclusion
The core-domain module cleanly separates business logic from infrastructure via repository interfaces and use cases. By leveraging reactive streams and a unified result wrapper, it enables robust, testable, and observable flows across the application. The UDF architecture and Channel effects pattern (via Flow and UitResult) provide a consistent way to manage state and errors while integrating seamlessly with the presentation layer.
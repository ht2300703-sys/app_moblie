# Core Common

<cite>
**Referenced Files in This Document**
- [AppConstants.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/constants/AppConstants.kt)
- [FirestorePaths.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/constants/FirestorePaths.kt)
- [Dispatchers.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/dispatcher/Dispatchers.kt)
- [UitResult.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt)
- [DateExt.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/DateExt.kt)
- [FlowExt.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/FlowExt.kt)
- [StringExt.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/StringExt.kt)
- [build.gradle.kts](file://core/core-common/build.gradle.kts)
- [DispatcherModule.kt](file://app/src/main/java/com/uit20years/app/di/DispatcherModule.kt)
- [AuthRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt)
- [UserRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/UserRepositoryImpl.kt)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
The core-common module provides foundational utilities and shared functionality used across all modules in the application. It centralizes configuration constants, defines coroutine dispatcher qualifiers, standardizes error handling via a sealed result type, and offers extension functions that enhance Kotlin’s standard library for date formatting, Flow transformations, and string validation/truncation. These utilities promote consistency, reduce duplication, and improve maintainability throughout the codebase.

## Project Structure
The core-common module is organized by responsibility:
- constants: Centralized configuration values for app behavior and Firestore collection names
- dispatcher: Qualifiers for injecting appropriate CoroutineDispatchers
- extensions: Kotlin extension functions for Date, Flow, and String
- result: Sealed interface UitResult for standardized success/error/loading states

```mermaid
graph TB
subgraph "core-common"
C1["constants<br/>AppConstants.kt"]
C2["constants<br/>FirestorePaths.kt"]
D1["dispatcher<br/>Dispatchers.kt"]
E1["extensions<br/>DateExt.kt"]
E2["extensions<br/>FlowExt.kt"]
E3["extensions<br/>StringExt.kt"]
R1["result<br/>UitResult.kt"]
end
subgraph "Dependencies"
K["kotlinx-coroutines-core"]
J["@Qualifier (javax.inject)"]
end
D1 --> J
E2 --> R1
E2 --> K
```

**Diagram sources**
- [Dispatchers.kt:1-16](file://core/core-common/src/main/kotlin/com/uit20years/core/common/dispatcher/Dispatchers.kt#L1-L16)
- [FlowExt.kt:1-13](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/FlowExt.kt#L1-L13)
- [UitResult.kt:1-37](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L1-L37)
- [build.gradle.kts:5-8](file://core/core-common/build.gradle.kts#L5-L8)

**Section sources**
- [build.gradle.kts:1-9](file://core/core-common/build.gradle.kts#L1-L9)

## Core Components
This section documents the primary building blocks of core-common and how they are used across the application.

- AppConstants: Defines global constants such as page size, image dimensions/quality, debounce delay for search, and maximum lengths for posts and comments. These values are referenced across data and domain layers to enforce consistent behavior.
- FirestorePaths: Provides constant identifiers for Firestore collections, ensuring uniform references across repositories and services.
- Dispatchers: Declares qualifier annotations for injecting IO, Default, and Main thread dispatchers. These are bound in DI modules to concrete CoroutineDispatcher instances.
- UitResult: A sealed interface representing three states—Loading, Success, and Error—along with extension helpers for safe unwrapping and state checks.
- DateExt: Converts milliseconds timestamps to formatted dates and human-friendly relative time strings.
- FlowExt: Transforms any Flow into a Flow of UitResult, emitting Loading at start, Success for values, and Error for exceptions.
- StringExt: Validates email format and truncates strings with a configurable suffix.

**Section sources**
- [AppConstants.kt:1-13](file://core/core-common/src/main/kotlin/com/uit20years/core/common/constants/AppConstants.kt#L1-L13)
- [FirestorePaths.kt:1-17](file://core/core-common/src/main/kotlin/com/uit20years/core/common/constants/FirestorePaths.kt#L1-L17)
- [Dispatchers.kt:1-16](file://core/core-common/src/main/kotlin/com/uit20years/core/common/dispatcher/Dispatchers.kt#L1-L16)
- [UitResult.kt:1-37](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L1-L37)
- [DateExt.kt:1-23](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/DateExt.kt#L1-L23)
- [FlowExt.kt:1-13](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/FlowExt.kt#L1-L13)
- [StringExt.kt:1-10](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/StringExt.kt#L1-L10)

## Architecture Overview
The core-common utilities integrate with other modules as follows:
- Constants are consumed by repositories and services to configure requests and validations.
- Dispatchers are injected via DI to ensure proper threading for IO-bound, CPU-bound, and UI-related tasks.
- UitResult and FlowExt standardize asynchronous operation outcomes, enabling consistent UI state handling across features.
- Extensions simplify common operations on dates, strings, and reactive streams.

```mermaid
graph TB
subgraph "App Modules"
APP["app"]
DATA["core-data"]
DOMAIN["core-domain"]
FIRE["core-firebase"]
MEDIA["core-media"]
UI["core-ui"]
end
CC["core-common"]
CONST["AppConstants<br/>FirestorePaths"]
DISP["Dispatchers<br/>Io/Default/Main"]
RES["UitResult<br/>FlowExt"]
EXT["DateExt<br/>StringExt"]
CC --> CONST
CC --> DISP
CC --> RES
CC --> EXT
DATA --> CC
DOMAIN --> CC
FIRE --> CC
MEDIA --> CC
UI --> CC
DATA --> CONST
DATA --> RES
DATA --> DISP
DATA --> EXT
DOMAIN --> RES
FIRE --> CONST
FIRE --> RES
MEDIA --> EXT
UI --> RES
```

**Diagram sources**
- [AppConstants.kt:1-13](file://core/core-common/src/main/kotlin/com/uit20years/core/common/constants/AppConstants.kt#L1-L13)
- [FirestorePaths.kt:1-17](file://core/core-common/src/main/kotlin/com/uit20years/core/common/constants/FirestorePaths.kt#L1-L17)
- [Dispatchers.kt:1-16](file://core/core-common/src/main/kotlin/com/uit20years/core/common/dispatcher/Dispatchers.kt#L1-L16)
- [UitResult.kt:1-37](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L1-L37)
- [FlowExt.kt:1-13](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/FlowExt.kt#L1-L13)
- [DateExt.kt:1-23](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/DateExt.kt#L1-L23)
- [StringExt.kt:1-10](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/StringExt.kt#L1-L10)

## Detailed Component Analysis

### AppConstants
Purpose:
- Centralizes numeric and textual constants used across the app for pagination, media sizing/quality, search debouncing, and content length limits.

Usage patterns:
- Page size and debounce delays are referenced in data-layer paging and search logic.
- Image quality and dimensions are used in media processing and upload flows.
- Maximum lengths are enforced in form validations and DTO conversions.

Best practices:
- Keep values immutable and documented with rationale.
- Prefer constants over magic numbers to improve readability and maintainability.

**Section sources**
- [AppConstants.kt:3-12](file://core/core-common/src/main/kotlin/com/uit20years/core/common/constants/AppConstants.kt#L3-L12)

### FirestorePaths
Purpose:
- Provides a single source of truth for Firestore collection names, preventing typos and ensuring consistency across repositories and services.

Usage patterns:
- Repositories construct references using these constants when reading/writing documents.
- Services and mappers rely on these identifiers to map domain entities to Firestore documents.

Best practices:
- Group related paths logically and avoid hardcoding strings outside this object.
- Add new paths here before using them in any repository/service.

**Section sources**
- [FirestorePaths.kt:3-16](file://core/core-common/src/main/kotlin/com/uit20years/core/common/constants/FirestorePaths.kt#L3-L16)

### Dispatchers
Purpose:
- Declares qualifier annotations for injecting IO, Default, and Main thread dispatchers. These are bound in a DI module to concrete CoroutineDispatcher instances.

Integration pattern:
- Inject the appropriate dispatcher using the qualifiers in repositories, use cases, and services.
- Bind implementations in a dedicated DI module to ensure consistent threading policy across the app.

Example binding locations:
- IO dispatcher bound to Dispatchers.IO
- Default dispatcher bound to Dispatchers.Default
- Main dispatcher bound to Dispatchers.Main

**Section sources**
- [Dispatchers.kt:5-15](file://core/core-common/src/main/kotlin/com/uit20years/core/common/dispatcher/Dispatchers.kt#L5-L15)
- [DispatcherModule.kt:18-24](file://app/src/main/java/com/uit20years/app/di/DispatcherModule.kt#L18-L24)

### UitResult
Purpose:
- Standardizes asynchronous operation outcomes with three states: Loading, Success, and Error. Includes extension helpers for safe unwrapping and state checks.

Processing logic:
- getOrNull returns data for Success, otherwise null.
- getOrThrow returns data for Success, throws for Error or Loading.
- onSuccess executes an action for Success, onError for Error.
- isSuccess/isError/isLoading provide boolean checks.

```mermaid
classDiagram
class UitResult~T~ {
<<sealed interface>>
}
class Success~T~ {
+data : T
}
class Error {
+exception : Throwable?
+message : String?
}
class Loading {
}
UitResult <|.. Success
UitResult <|.. Error
UitResult <|.. Loading
```

**Diagram sources**
- [UitResult.kt:3-11](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L3-L11)

**Section sources**
- [UitResult.kt:13-37](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L13-L37)

### FlowExt
Purpose:
- Transforms a Flow<T> into a Flow<UitResult<T>> by emitting Loading at start, Success for values, and Error for exceptions.

Processing logic:
- onStart emits Loading before upstream emissions.
- map wraps each value in Success.
- catch intercepts errors and emits Error with the exception.

```mermaid
sequenceDiagram
participant F as "Flow<T>"
participant X as "FlowExt.asUitResult()"
participant R as "Flow<UitResult<T>>"
F->>X : "subscribe"
X->>R : "emit Loading"
F-->>X : "value v"
X-->>R : "emit Success(v)"
F-->>X : "throw Exception e"
X-->>R : "emit Error(e)"
```

**Diagram sources**
- [FlowExt.kt:9-12](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/FlowExt.kt#L9-L12)
- [UitResult.kt:4-8](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L4-L8)

**Section sources**
- [FlowExt.kt:9-12](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/FlowExt.kt#L9-L12)

### DateExt
Purpose:
- Formats timestamps into readable strings and computes relative time descriptions.

Processing logic:
- toFormattedDate uses a pattern and locale to render a human-readable date/time.
- toRelativeTime computes a relative description based on current time and the given timestamp, falling back to formatted date for older values.

**Section sources**
- [DateExt.kt:7-22](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/DateExt.kt#L7-L22)

### StringExt
Purpose:
- Validates email addresses and truncates strings with a configurable suffix.

Processing logic:
- isValidEmail uses a compiled regex to match standard email patterns.
- truncate ensures a maximum length by slicing and appending a suffix when needed.

**Section sources**
- [StringExt.kt:3-9](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/StringExt.kt#L3-L9)

## Dependency Analysis
The core-common module depends on:
- kotlinx-coroutines-core for Flow and dispatcher utilities
- javax.inject for @Qualifier annotations used by the Dispatchers module

```mermaid
graph LR
CC["core-common"]
KC["kotlinx-coroutines-core"]
JI["@Qualifier (javax.inject)"]
CC --> KC
CC --> JI
```

**Diagram sources**
- [build.gradle.kts:5-8](file://core/core-common/build.gradle.kts#L5-L8)

**Section sources**
- [build.gradle.kts:5-8](file://core/core-common/build.gradle.kts#L5-L8)

## Performance Considerations
- Use UitResult with FlowExt to avoid manual state management overhead and reduce boilerplate in repositories and use cases.
- Prefer constants from AppConstants and FirestorePaths to minimize repeated string allocations and potential typos.
- Apply Dispatchers qualifiers to ensure work runs on appropriate threads, avoiding main-thread blocking and improving responsiveness.
- Leverage StringExt for lightweight validations and truncations; cache compiled regexes if reused frequently.

## Troubleshooting Guide
Common issues and resolutions:
- Incorrect dispatcher usage: Ensure qualifiers are properly bound in DI and used consistently across modules. Verify bindings in the DI module.
- Flow state confusion: When converting Flows to UitResult, confirm that upstream exceptions are handled and that Loading is emitted before values.
- Constant drift: If a Firestore path changes, update FirestorePaths and propagate the change to all repositories/services referencing it.
- Relative time accuracy: DateExt.toRelativeTime relies on current time; ensure timestamps are in milliseconds and validated before conversion.

Integration examples:
- Using FirestorePaths in repositories:
  - [AuthRepositoryImpl.kt:35](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L35)
  - [UserRepositoryImpl.kt:24](file://core/core-data/src/main/java/com/uit20years/core/data/repository/UserRepositoryImpl.kt#L24)
- Applying Dispatchers qualifiers:
  - [DispatcherModule.kt:18](file://app/src/main/java/com/uit20years/app/di/DispatcherModule.kt#L18)
  - [DispatcherModule.kt:23](file://app/src/main/java/com/uit20years/app/di/DispatcherModule.kt#L23)
- Transforming Flows to UitResult:
  - [FlowExt.kt:9-12](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/FlowExt.kt#L9-L12)
  - [UitResult.kt:4-8](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L4-L8)

**Section sources**
- [AuthRepositoryImpl.kt:29-85](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L29-L85)
- [UserRepositoryImpl.kt:24](file://core/core-data/src/main/java/com/uit20years/core/data/repository/UserRepositoryImpl.kt#L24)
- [DispatcherModule.kt:18-24](file://app/src/main/java/com/uit20years/app/di/DispatcherModule.kt#L18-L24)
- [FlowExt.kt:9-12](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/FlowExt.kt#L9-L12)
- [UitResult.kt:4-8](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L4-L8)

## Conclusion
The core-common module establishes a consistent foundation across the application by centralizing configuration, standardizing asynchronous result handling, and providing practical Kotlin extensions. By adhering to the patterns outlined here—using constants, qualifiers, UitResult, and FlowExt—you can ensure predictable behavior, improved testability, and reduced duplication across features and modules.
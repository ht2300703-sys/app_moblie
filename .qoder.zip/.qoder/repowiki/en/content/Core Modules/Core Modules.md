# Core Modules

<cite>
**Referenced Files in This Document**
- [AppConstants.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/constants/AppConstants.kt)
- [Dispatchers.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/dispatcher/Dispatchers.kt)
- [DateExt.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/DateExt.kt)
- [FlowExt.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/FlowExt.kt)
- [StringExt.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/StringExt.kt)
- [UitResult.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt)
- [User.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt)
- [Post.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Post.kt)
- [Event.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Event.kt)
- [Comment.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Comment.kt)
- [Heritage.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Heritage.kt)
- [Notification.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Notification.kt)
- [Reaction.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Reaction.kt)
- [AuthRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt)
- [PostRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/PostRepository.kt)
- [LoginUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt)
- [RegisterUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt)
- [GetCurrentUserUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/GetCurrentUserUseCase.kt)
- [DataModule.kt](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt)
- [AuthRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt)
- [PostRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/PostRepositoryImpl.kt)
- [FirebaseAuthService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt)
- [FirebaseModule.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt)
- [FirestoreService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt)
- [FirebaseStorageService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/storage/FirebaseStorageService.kt)
- [UitMessagingService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/fcm/UitMessagingService.kt)
- [ImageCompressor.kt](file://core/core-media/src/main/java/com/uit20years/core/media/ImageCompressor.kt)
- [MediaUploader.kt](file://core/core-media/src/main/java/com/uit20years/core/media/MediaUploader.kt)
- [MediaModule.kt](file://core/core-media/src/main/java/com/uit20years/core/media/di/MediaModule.kt)
- [EmptyView.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/EmptyView.kt)
- [ErrorView.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/ErrorView.kt)
- [LoadingIndicator.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/LoadingIndicator.kt)
- [UitButton.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitButton.kt)
- [UitTextField.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTextField.kt)
- [UitTopBar.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTopBar.kt)
- [Theme.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Theme.kt)
- [Color.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Color.kt)
- [Shape.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Shape.kt)
- [Type.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Type.kt)
- [SearchService.kt](file://core/core-search/src/main/java/com/uit20years/core/search/SearchService.kt)
- [AlgoliaSearchServiceImpl.kt](file://core/core-search/src/main/java/com/uit20years/core/search/AlgoliaSearchServiceImpl.kt)
- [DispatcherModule.kt](file://app/src/main/java/com/uit20years/app/di/DispatcherModule.kt)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document explains the core modules that underpin the UIT20Years Android application. It covers shared utilities and extensions (core-common), domain entities (core-model), business logic and repository interfaces (core-domain), data access and repository implementations (core-data), Firebase service abstractions (core-firebase), media compression and upload (core-media), Material 3 theming and reusable UI components (core-ui), and search service interfaces (core-search). For each module, we describe purpose, responsibilities, implementation patterns, and integration points. We also illustrate module relationships, dependency injection patterns, and provide usage guidelines.

## Project Structure
The application follows a modular architecture with a dedicated core package per concern. Feature modules depend on core modules to access models, repositories, UI components, and infrastructure services. The app module integrates DI and orchestrates navigation and application lifecycle.

```mermaid
graph TB
subgraph "App Module"
APP["app module"]
DI_APP["app di<br/>DispatcherModule.kt"]
end
subgraph "Core Modules"
COMMON["core-common"]
MODEL["core-model"]
DOMAIN["core-domain"]
DATA["core-data"]
FIREBASE["core-firebase"]
MEDIA["core-media"]
UI["core-ui"]
SEARCH["core-search"]
end
APP --> DOMAIN
APP --> UI
APP --> DATA
APP --> FIREBASE
APP --> MEDIA
APP --> SEARCH
DOMAIN --> MODEL
DATA --> MODEL
DATA --> DOMAIN
FIREBASE --> DOMAIN
MEDIA --> DOMAIN
SEARCH --> DOMAIN
UI --> MODEL
```

**Diagram sources**
- [DispatcherModule.kt](file://app/src/main/java/com/uit20years/app/di/DispatcherModule.kt)
- [AppConstants.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/constants/AppConstants.kt)
- [User.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt)
- [AuthRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt)
- [AuthRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt)
- [FirebaseAuthService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt)
- [MediaUploader.kt](file://core/core-media/src/main/java/com/uit20years/core/media/MediaUploader.kt)
- [UitButton.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitButton.kt)
- [SearchService.kt](file://core/core-search/src/main/java/com/uit20years/core/search/SearchService.kt)

**Section sources**
- [DispatcherModule.kt](file://app/src/main/java/com/uit20years/app/di/DispatcherModule.kt)

## Core Components
This section summarizes each core module’s purpose and responsibilities.

- core-common: Provides cross-cutting utilities, extension functions, and a unified result type for reactive streams.
- core-model: Defines immutable domain entities and enumerations used across the app.
- core-domain: Encapsulates business logic via use cases and declares repository interfaces for data access.
- core-data: Implements repository interfaces using DTOs and mappers, bridging domain and persistence.
- core-firebase: Abstracts Firebase services (authentication, Firestore, Cloud Storage, FCM) behind service interfaces.
- core-media: Handles image compression and media upload orchestration.
- core-ui: Supplies Material 3 theming and reusable UI components.
- core-search: Defines search service abstractions and provides an Algolia-backed implementation.

**Section sources**
- [AppConstants.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/constants/AppConstants.kt)
- [UitResult.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt)
- [User.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt)
- [Post.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Post.kt)
- [Event.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Event.kt)
- [Comment.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Comment.kt)
- [Heritage.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Heritage.kt)
- [Notification.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Notification.kt)
- [Reaction.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Reaction.kt)
- [AuthRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt)
- [PostRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/PostRepository.kt)
- [DataModule.kt](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt)
- [FirebaseAuthService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt)
- [FirestoreService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt)
- [FirebaseStorageService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/storage/FirebaseStorageService.kt)
- [UitMessagingService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/fcm/UitMessagingService.kt)
- [ImageCompressor.kt](file://core/core-media/src/main/java/com/uit20years/core/media/ImageCompressor.kt)
- [MediaUploader.kt](file://core/core-media/src/main/java/com/uit20years/core/media/MediaUploader.kt)
- [EmptyView.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/EmptyView.kt)
- [ErrorView.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/ErrorView.kt)
- [LoadingIndicator.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/LoadingIndicator.kt)
- [UitButton.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitButton.kt)
- [UitTextField.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTextField.kt)
- [UitTopBar.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTopBar.kt)
- [Theme.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Theme.kt)
- [Color.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Color.kt)
- [Shape.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Shape.kt)
- [Type.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Type.kt)
- [SearchService.kt](file://core/core-search/src/main/java/com/uit20years/core/search/SearchService.kt)
- [AlgoliaSearchServiceImpl.kt](file://core/core-search/src/main/java/com/uit20years/core/search/AlgoliaSearchServiceImpl.kt)

## Architecture Overview
The app enforces separation of concerns:
- UI depends on domain use cases and models.
- Domain encapsulates business logic and exposes repository interfaces.
- Data implements repositories using DTOs and mappers.
- Infrastructure modules (Firebase, Media, Search) provide services consumed by repositories.
- core-common supplies shared utilities and standardized result handling.

```mermaid
graph LR
UI["UI Layer<br/>Features"] --> USE_CASES["Domain Use Cases"]
USE_CASES --> REPO_IF["Repository Interfaces"]
REPO_IF --> REPO_IMPL["Repository Implementations"]
REPO_IMPL --> DTO["DTOs & Mappers"]
REPO_IMPL --> INFRA["Infrastructure Services<br/>Firebase, Media, Search"]
INFRA --> DB["Data Stores<br/>Firestore, Storage, Algolia"]
subgraph "core-common"
COMMON_UTIL["Extensions, Result, Dispatchers"]
end
subgraph "core-model"
MODELS["Entities & Enums"]
end
subgraph "core-domain"
DOMAIN_LAYER["Use Cases & Repositories"]
end
subgraph "core-data"
DATA_LAYER["Repositories Impl"]
end
subgraph "core-firebase"
FIREBASE_LAYER["Firebase Services"]
end
subgraph "core-media"
MEDIA_LAYER["Media Compression & Upload"]
end
subgraph "core-search"
SEARCH_LAYER["Search Abstractions"]
end
UI --> MODELS
UI --> DOMAIN_LAYER
DOMAIN_LAYER --> MODELS
DATA_LAYER --> MODELS
DATA_LAYER --> INFRA
FIREBASE_LAYER --> DATA_LAYER
MEDIA_LAYER --> DATA_LAYER
SEARCH_LAYER --> DATA_LAYER
COMMON_UTIL --> UI
COMMON_UTIL --> DOMAIN_LAYER
COMMON_UTIL --> DATA_LAYER
```

**Diagram sources**
- [UitResult.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt)
- [User.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt)
- [AuthRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt)
- [PostRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/PostRepository.kt)
- [AuthRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt)
- [PostRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/PostRepositoryImpl.kt)
- [FirebaseAuthService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt)
- [FirestoreService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt)
- [FirebaseStorageService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/storage/FirebaseStorageService.kt)
- [UitMessagingService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/fcm/UitMessagingService.kt)
- [ImageCompressor.kt](file://core/core-media/src/main/java/com/uit20years/core/media/ImageCompressor.kt)
- [MediaUploader.kt](file://core/core-media/src/main/java/com/uit20years/core/media/MediaUploader.kt)
- [SearchService.kt](file://core/core-search/src/main/java/com/uit20years/core/search/SearchService.kt)
- [AlgoliaSearchServiceImpl.kt](file://core/core-search/src/main/java/com/uit20years/core/search/AlgoliaSearchServiceImpl.kt)

## Detailed Component Analysis

### core-common
Purpose:
- Provide shared utilities, extension functions, and a standardized reactive result type.
- Offer coroutine dispatcher qualifiers for dependency injection.

Responsibilities:
- Constants for pagination, image sizing/quality, search debounce, and content limits.
- Extensions for date formatting, relative time, Flow transformation to UitResult, email validation, and string truncation.
- UitResult sealed interface with Success, Error, and Loading states and helper extensions.

Implementation highlights:
- Constants centralize tuning knobs for UI and network behavior.
- FlowExt.asUitResult wraps streams with Loading onStart, Success on data, and Error on catch.
- StringExt and DateExt improve readability and reduce duplication across features.

Usage patterns:
- Use UitResult in ViewModels and Composables to drive UI state.
- Apply FlowExt.asUitResult downstream of repository calls.
- Leverage StringExt.isValidEmail and StringExt.truncate for input validation and display.

Integration guidelines:
- Inject dispatchers via qualifiers (IoDispatcher, DefaultDispatcher, MainDispatcher) to control threading.
- Keep constants in AppConstants for global configuration.

**Section sources**
- [AppConstants.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/constants/AppConstants.kt)
- [Dispatchers.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/dispatcher/Dispatchers.kt)
- [DateExt.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/DateExt.kt)
- [FlowExt.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/FlowExt.kt)
- [StringExt.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/StringExt.kt)
- [UitResult.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt)

### core-model
Purpose:
- Define immutable domain entities and enumerations used across the app.

Responsibilities:
- User, Post, Event, Comment, Heritage, Notification, Reaction models with appropriate defaults and enumerations.
- Enumerations for roles, post visibility, event types, notification types, reaction types, and heritage categories.

Implementation highlights:
- Data classes ensure immutability and simplify equality checks.
- Enumerations provide type safety for categorical fields.

Usage patterns:
- Use models in UI for rendering and in repositories for domain operations.
- Convert to/from DTOs in data layer using mappers.

Integration guidelines:
- Keep models free of Android framework dependencies.
- Add new enums or fields only after careful consideration of domain semantics.

**Section sources**
- [User.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt)
- [Post.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Post.kt)
- [Event.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Event.kt)
- [Comment.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Comment.kt)
- [Heritage.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Heritage.kt)
- [Notification.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Notification.kt)
- [Reaction.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Reaction.kt)

### core-domain
Purpose:
- Encapsulate business logic via use cases and define repository interfaces for data access.

Responsibilities:
- Auth use cases: LoginUseCase, RegisterUseCase, LogoutUseCase, ObserveAuthStateUseCase, GetCurrentUserUseCase.
- Repository interfaces: AuthRepository, PostRepository, EventRepository, HeritageRepository, NotificationRepository, UserRepository.
- Expose reactive streams (Flow) and standardized UitResult for outcomes.

Implementation highlights:
- Use cases delegate to repositories, enabling testability and separation of concerns.
- Repository interfaces define contracts for data operations without exposing implementation details.

Usage patterns:
- Invoke use cases from ViewModels to trigger business operations.
- Collect Flow<UitResult<T>> in UI to render Loading, Success, or Error states.

Integration guidelines:
- Do not implement repositories in this module; keep interfaces only.
- Ensure use cases remain free of platform-specific code.

**Section sources**
- [AuthRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt)
- [PostRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/PostRepository.kt)
- [LoginUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt)
- [RegisterUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt)
- [GetCurrentUserUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/GetCurrentUserUseCase.kt)

### core-data
Purpose:
- Implement repository interfaces using DTOs and mappers, bridging domain and persistence.

Responsibilities:
- Repository implementations for Auth, Post, Event, Heritage, Notification, and User.
- DI module wiring repositories to their implementations.
- DTOs and mappers for transforming between domain models and persistence representations.

Implementation highlights:
- DataModule binds repository interfaces to concrete implementations.
- RepositoryImpls coordinate with Firebase services and map DTOs to domain models.

Usage patterns:
- Inject repository interfaces into use cases; do not depend on implementations directly.
- Use mappers to convert between domain and DTO layers.

Integration guidelines:
- Keep repository implementations free of UI code.
- Centralize DI bindings in DataModule for consistent wiring.

**Section sources**
- [DataModule.kt](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt)
- [AuthRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt)
- [PostRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/PostRepositoryImpl.kt)

### core-firebase
Purpose:
- Abstract Firebase services (authentication, Firestore, Cloud Storage, FCM) behind service interfaces.

Responsibilities:
- FirebaseAuthService, FirestoreService, FirebaseStorageService, UitMessagingService.
- FirebaseModule wires service implementations for DI.
- Provide a clean boundary between domain/business logic and Firebase SDK.

Implementation highlights:
- Services encapsulate Firebase SDK calls and return domain-friendly results.
- FirebaseModule ensures consistent provisioning of services.

Usage patterns:
- Inject services into repository implementations.
- Handle errors and map Firebase exceptions to UitResult.

Integration guidelines:
- Treat Firebase as infrastructure; avoid leaking SDK specifics into domain.
- Centralize initialization and configuration in FirebaseModule.

**Section sources**
- [FirebaseAuthService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt)
- [FirebaseModule.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt)
- [FirestoreService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt)
- [FirebaseStorageService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/storage/FirebaseStorageService.kt)
- [UitMessagingService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/fcm/UitMessagingService.kt)

### core-media
Purpose:
- Provide image compression and media upload orchestration.

Responsibilities:
- ImageCompressor for resizing and quality adjustment.
- MediaUploader for coordinating uploads to cloud storage.
- MediaModule for DI wiring.

Implementation highlights:
- ImageCompressor uses constants from core-common for sizing and quality.
- MediaUploader delegates to FirebaseStorageService and returns UitResult.

Usage patterns:
- Compress images before upload to optimize bandwidth and storage.
- Use MediaUploader in post creation or profile updates.

Integration guidelines:
- Keep media processing off the main thread using injected dispatchers.
- Centralize DI in MediaModule.

**Section sources**
- [ImageCompressor.kt](file://core/core-media/src/main/java/com/uit20years/core/media/ImageCompressor.kt)
- [MediaUploader.kt](file://core/core-media/src/main/java/com/uit20years/core/media/MediaUploader.kt)
- [MediaModule.kt](file://core/core-media/src/main/java/com/uit20years/core/media/di/MediaModule.kt)

### core-ui
Purpose:
- Supply Material 3 theming and reusable UI components.

Responsibilities:
- Theme definitions (Color, Shape, Type, Theme).
- Reusable components: EmptyView, ErrorView, LoadingIndicator, UitButton, UitTextField, UitTopBar.

Implementation highlights:
- Material 3 tokens defined centrally for consistent design.
- Components encapsulate common UI patterns and state handling.

Usage patterns:
- Import theme resources and apply theming in CompositionRoot.
- Use components to reduce duplication and enforce design consistency.

Integration guidelines:
- Keep UI components stateless where possible; push state up to ViewModels.
- Avoid platform-specific code inside components.

**Section sources**
- [EmptyView.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/EmptyView.kt)
- [ErrorView.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/ErrorView.kt)
- [LoadingIndicator.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/LoadingIndicator.kt)
- [UitButton.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitButton.kt)
- [UitTextField.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTextField.kt)
- [UitTopBar.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTopBar.kt)
- [Theme.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Theme.kt)
- [Color.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Color.kt)
- [Shape.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Shape.kt)
- [Type.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Type.kt)

### core-search
Purpose:
- Define search service abstractions and provide an Algolia-backed implementation.

Responsibilities:
- SearchService interface for search operations.
- AlgoliaSearchServiceImpl implementing the interface.

Implementation highlights:
- Abstract search to support pluggable providers.
- Algolia implementation encapsulates search logic.

Usage patterns:
- Inject SearchService into features requiring search capabilities.
- Use SearchService in ViewModels to fetch and present results.

Integration guidelines:
- Treat search as infrastructure; keep queries and filters in domain or features.
- Centralize DI for search services.

**Section sources**
- [SearchService.kt](file://core/core-search/src/main/java/com/uit20years/core/search/SearchService.kt)
- [AlgoliaSearchServiceImpl.kt](file://core/core-search/src/main/java/com/uit20years/core/search/AlgoliaSearchServiceImpl.kt)

## Dependency Analysis
This section maps module dependencies and DI wiring.

```mermaid
graph TB
subgraph "DI Wiring"
DM["DataModule"]
FM["FirebaseModule"]
MM["MediaModule"]
DPM["DispatcherModule"]
end
subgraph "Domain"
AR["AuthRepository"]
PR["PostRepository"]
end
subgraph "Data"
ARI["AuthRepositoryImpl"]
PRI["PostRepositoryImpl"]
end
subgraph "Firebase"
FBS["FirebaseAuthService"]
FSS["FirestoreService"]
FGS["FirebaseStorageService"]
end
DM --> ARI
DM --> PRI
ARI --> FBS
ARI --> FSS
PRI --> FSS
PRI --> FGS
FM --> FBS
FM --> FSS
FM --> FGS
MM --> FGS
DPM --> DM
DPM --> FM
DPM --> MM
```

**Diagram sources**
- [DataModule.kt](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt)
- [FirebaseModule.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt)
- [MediaModule.kt](file://core/core-media/src/main/java/com/uit20years/core/media/di/MediaModule.kt)
- [DispatcherModule.kt](file://app/src/main/java/com/uit20years/app/di/DispatcherModule.kt)
- [AuthRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt)
- [PostRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/PostRepository.kt)
- [AuthRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt)
- [PostRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/PostRepositoryImpl.kt)
- [FirebaseAuthService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt)
- [FirestoreService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt)
- [FirebaseStorageService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/storage/FirebaseStorageService.kt)

Key observations:
- DataModule binds repository interfaces to implementations.
- FirebaseModule provides service implementations for authentication, Firestore, and storage.
- MediaModule wires media upload services.
- DispatcherModule configures coroutine dispatchers used across modules.

**Section sources**
- [DataModule.kt](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt)
- [FirebaseModule.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt)
- [MediaModule.kt](file://core/core-media/src/main/java/com/uit20years/core/media/di/MediaModule.kt)
- [DispatcherModule.kt](file://app/src/main/java/com/uit20years/app/di/DispatcherModule.kt)

## Performance Considerations
- Pagination: Use PAGE_SIZE constants to limit initial loads and implement cursor-based pagination.
- Image optimization: Compress images before upload using MAX_IMAGE_WIDTH/HEIGHT and IMAGE_QUALITY to reduce payload sizes.
- Debounced search: SEARCH_DEBOUNCE_MS reduces redundant search requests during typing.
- Reactive streams: Use FlowExt.asUitResult to minimize UI thrashing and clearly separate Loading/Success/Error states.
- Threading: Inject IoDispatcher/DefaultDispatcher/MainDispatcher to offload work appropriately and keep UI responsive.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and resolutions:
- Authentication failures: Verify Firebase authentication service wiring and error mapping in repository implementations.
- Upload failures: Confirm media compression and storage permissions; check FirebaseStorageService error propagation.
- UI not reflecting loading state: Ensure FlowExt.asUitResult is applied to repository streams.
- Email validation errors: Use StringExt.isValidEmail in forms before submitting to use cases.
- Relative time formatting: Use DateExt.toRelativeTime for localized human-readable timestamps.

**Section sources**
- [UitResult.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt)
- [StringExt.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/StringExt.kt)
- [DateExt.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/DateExt.kt)
- [FlowExt.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/FlowExt.kt)

## Conclusion
The core modules establish a robust, testable, and maintainable foundation for UIT20Years. They enforce clear boundaries between UI, domain, data, and infrastructure concerns, while providing reusable utilities, consistent UI theming, and standardized result handling. Proper DI wiring and repository abstractions enable easy testing and future extensibility.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### Example: Using a Use Case with Repository Implementation
```mermaid
sequenceDiagram
participant VM as "ViewModel"
participant UC as "LoginUseCase"
participant Repo as "AuthRepositoryImpl"
participant Svc as "FirebaseAuthService"
VM->>UC : invoke(email, password)
UC->>Repo : login(email, password)
Repo->>Svc : authenticate(email, password)
Svc-->>Repo : User or Exception
Repo-->>UC : Flow<UitResult<User>>
UC-->>VM : Flow<UitResult<User>>
VM->>VM : collect and update UI state
```

**Diagram sources**
- [LoginUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt)
- [AuthRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt)
- [AuthRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt)
- [FirebaseAuthService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt)

### Example: Media Upload Flow
```mermaid
flowchart TD
Start(["Start"]) --> Compress["Compress Image"]
Compress --> Upload["Upload to Cloud Storage"]
Upload --> Success{"Upload Success?"}
Success --> |Yes| Done(["Done"])
Success --> |No| Error["Emit Error via UitResult"]
Error --> Done
```

**Diagram sources**
- [ImageCompressor.kt](file://core/core-media/src/main/java/com/uit20years/core/media/ImageCompressor.kt)
- [MediaUploader.kt](file://core/core-media/src/main/java/com/uit20years/core/media/MediaUploader.kt)
- [FirebaseStorageService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/storage/FirebaseStorageService.kt)
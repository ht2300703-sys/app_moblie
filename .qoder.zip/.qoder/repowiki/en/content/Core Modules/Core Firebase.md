# Core Firebase

<cite>
**Referenced Files in This Document**
- [FirebaseModule.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt)
- [FirebaseAuthService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt)
- [FirestoreService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt)
- [FirebaseStorageService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/storage/FirebaseStorageService.kt)
- [UitMessagingService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/fcm/UitMessagingService.kt)
- [AuthRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt)
- [AuthRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt)
- [LoginUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt)
- [LoginViewModel.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt)
- [RegisterViewModel.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt)
- [UserMapper.kt](file://core/core-data/src/main/java/com/uit20years/core/data/mapper/UserMapper.kt)
- [FirestorePaths.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/constants/FirestorePaths.kt)
- [DispatcherModule.kt](file://app/src/main/java/com/uit20years/app/di/DispatcherModule.kt)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document describes the core-firebase module that provides Firebase service abstractions and implementations for the UIT20Years application. It covers:
- FirebaseAuthService for authentication operations including sign-in, sign-up, sign-out, and observing user state
- FirestoreService for database operations including CRUD, querying, and real-time listeners
- FirebaseStorageService for media upload, download, and deletion
- UitMessagingService for Firebase Cloud Messaging integration and push notification handling
It also documents dependency injection configuration, service initialization patterns, usage examples, error handling strategies, security considerations, and integration with the data layer repositories.

## Project Structure
The core-firebase module exposes clean service interfaces for Firebase SDKs and integrates with Hilt for dependency injection. The services are consumed by repositories and exposed to features via use cases and ViewModels.

```mermaid
graph TB
subgraph "core-firebase"
FM["FirebaseModule<br/>provides FirebaseAuth, Firestore, Storage"]
FA["FirebaseAuthService"]
FS["FirestoreService"]
FU["FirebaseStorageService"]
FCM["UitMessagingService"]
end
subgraph "core-data"
AR["AuthRepositoryImpl"]
end
subgraph "core-domain"
AIR["AuthRepository (interface)"]
LUC["LoginUseCase"]
end
subgraph "feature-auth"
LVM["LoginViewModel"]
RVM["RegisterViewModel"]
end
FM --> FA
FM --> FS
FM --> FU
AR --> FA
AR --> FS
LUC --> AIR
LVM --> LUC
RVM --> LUC
```

**Diagram sources**
- [FirebaseModule.kt:12-27](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt#L12-L27)
- [FirebaseAuthService.kt:14-36](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L14-L36)
- [FirestoreService.kt:16-106](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt#L16-L106)
- [FirebaseStorageService.kt:10-31](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/storage/FirebaseStorageService.kt#L10-L31)
- [UitMessagingService.kt:7-20](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/fcm/UitMessagingService.kt#L7-L20)
- [AuthRepositoryImpl.kt:24-146](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L24-L146)
- [AuthRepository.kt:7-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L7-L13)
- [LoginUseCase.kt:9-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L9-L14)
- [LoginViewModel.kt:21-99](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L21-L99)
- [RegisterViewModel.kt:21-140](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt#L21-L140)

**Section sources**
- [FirebaseModule.kt:12-27](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt#L12-L27)
- [FirebaseAuthService.kt:14-36](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L14-L36)
- [FirestoreService.kt:16-106](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt#L16-L106)
- [FirebaseStorageService.kt:10-31](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/storage/FirebaseStorageService.kt#L10-L31)
- [UitMessagingService.kt:7-20](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/fcm/UitMessagingService.kt#L7-L20)

## Core Components
This section documents the primary Firebase service abstractions and their responsibilities.

- FirebaseAuthService
  - Provides sign-in, sign-up, sign-out, current user retrieval, and auth state observation
  - Exposes a Flow for reactive auth state changes
  - Uses Firebase SDK tasks with coroutine suspension for async operations

- FirestoreService
  - Supports document and collection reads/writes
  - Offers real-time listeners for documents and collections
  - Includes transaction support and optional merge writes
  - Accepts a query builder lambda for flexible queries

- FirebaseStorageService
  - Uploads bytes or files to storage references
  - Returns download URLs after successful uploads
  - Deletes files and fetches download URLs

- UitMessagingService
  - Extends FirebaseMessagingService
  - Logs new FCM tokens and incoming messages
  - Intended to persist tokens and show notifications

**Section sources**
- [FirebaseAuthService.kt:14-36](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L14-L36)
- [FirestoreService.kt:16-106](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt#L16-L106)
- [FirebaseStorageService.kt:10-31](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/storage/FirebaseStorageService.kt#L10-L31)
- [UitMessagingService.kt:7-20](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/fcm/UitMessagingService.kt#L7-L20)

## Architecture Overview
The Firebase services are provided as singletons via Hilt and consumed by repositories. Repositories encapsulate business logic and map DTOs to domain models. Features consume repositories through use cases and ViewModels.

```mermaid
sequenceDiagram
participant VM as "LoginViewModel"
participant UC as "LoginUseCase"
participant Repo as "AuthRepositoryImpl"
participant Auth as "FirebaseAuthService"
participant Store as "FirestoreService"
VM->>UC : invoke(email, password)
UC->>Repo : login(email, password)
Repo->>Auth : signInWithEmail(email, password)
Auth-->>Repo : AuthResult
Repo->>Store : getDocument(users, uid)
Store-->>Repo : DocumentSnapshot
Repo-->>UC : Flow<UitResult<User>>
UC-->>VM : Flow<UitResult<User>>
VM-->>VM : Update UI state
```

**Diagram sources**
- [LoginViewModel.kt:72-94](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L72-L94)
- [LoginUseCase.kt:12-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L12-L13)
- [AuthRepositoryImpl.kt:29-55](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L29-L55)
- [FirebaseAuthService.kt:17-18](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L17-L18)
- [FirestoreService.kt:19-20](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt#L19-L20)

## Detailed Component Analysis

### FirebaseAuthService
- Responsibilities
  - Authenticate users via email/password
  - Create new accounts
  - Sign out and retrieve current user
  - Observe auth state changes via a Flow

- Implementation highlights
  - Uses Firebase SDK’s Task-based APIs with coroutine suspension
  - Exposes a callbackFlow-based listener for auth state changes
  - Thread-safe and lifecycle-aware through Hilt singleton scope

- Usage pattern
  - Inject into repositories or ViewModels
  - Combine with FirestoreService to load user profiles after sign-in

**Section sources**
- [FirebaseAuthService.kt:14-36](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L14-L36)

### FirestoreService
- Responsibilities
  - Read documents and collections
  - Write/update/delete documents
  - Real-time listeners for documents and collections
  - Transactions

- Implementation highlights
  - Accepts a query builder lambda to compose filters/sorts
  - Listeners are registered via addSnapshotListener and cleaned up on close
  - Merge writes supported via SetOptions

- Usage pattern
  - Used by repositories to fetch user profiles and other domain entities
  - Supports pagination and filtering through query builder

**Section sources**
- [FirestoreService.kt:16-106](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt#L16-L106)

### FirebaseStorageService
- Responsibilities
  - Upload bytes or files
  - Delete files
  - Retrieve download URLs

- Implementation highlights
  - Uses Firebase Storage references and await() for coroutine-friendly APIs
  - Returns download URLs after successful uploads

- Usage pattern
  - Typically used by media upload flows to store images and retrieve public URLs

**Section sources**
- [FirebaseStorageService.kt:10-31](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/storage/FirebaseStorageService.kt#L10-L31)

### UitMessagingService
- Responsibilities
  - Handle new FCM tokens and incoming messages
  - Log token refresh and message receipt

- Implementation highlights
  - Extends FirebaseMessagingService
  - Intended to persist tokens and trigger local notifications

- Security note
  - Token persistence and notification delivery are marked as TODOs and should be implemented with secure storage and proper foreground/background handling

**Section sources**
- [UitMessagingService.kt:7-20](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/fcm/UitMessagingService.kt#L7-L20)

### Dependency Injection and Initialization
- FirebaseModule
  - Provides FirebaseAuth, FirebaseFirestore, and FirebaseStorage singletons
  - Installed in SingletonComponent for global availability

- DispatcherModule
  - Provides IO and default dispatchers for coroutines
  - Ensures consistent threading across Firebase operations

- Repository integration
  - AuthRepositoryImpl depends on FirebaseAuthService and FirestoreService
  - Mappers convert between DTOs and domain models

```mermaid
classDiagram
class FirebaseModule {
+provideFirebaseAuth() FirebaseAuth
+provideFirebaseFirestore() FirebaseFirestore
+provideFirebaseStorage() FirebaseStorage
}
class FirebaseAuthService {
+signInWithEmail(email, password)
+createUser(email, password)
+signOut()
+getCurrentUser()
+observeAuthState() Flow
}
class FirestoreService {
+getDocument(...)
+getCollection(...)
+observeDocument(...)
+observeCollection(...)
+setDocument(...)
+addDocument(...)
+updateDocument(...)
+deleteDocument(...)
+runTransaction(...)
}
class FirebaseStorageService {
+uploadBytes(...)
+uploadFile(...)
+deleteFile(...)
+getDownloadUrl(...)
}
class AuthRepositoryImpl {
+login(...)
+register(...)
+logout()
+observeAuthState()
+getCurrentUser()
}
FirebaseModule --> FirebaseAuthService : "provides"
FirebaseModule --> FirestoreService : "provides"
FirebaseModule --> FirebaseStorageService : "provides"
AuthRepositoryImpl --> FirebaseAuthService : "uses"
AuthRepositoryImpl --> FirestoreService : "uses"
```

**Diagram sources**
- [FirebaseModule.kt:16-26](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt#L16-L26)
- [FirebaseAuthService.kt:14-36](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L14-L36)
- [FirestoreService.kt:16-106](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt#L16-L106)
- [FirebaseStorageService.kt:10-31](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/storage/FirebaseStorageService.kt#L10-L31)
- [AuthRepositoryImpl.kt:24-146](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L24-L146)

**Section sources**
- [FirebaseModule.kt:12-27](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt#L12-L27)
- [DispatcherModule.kt:14-26](file://app/src/main/java/com/uit20years/app/di/DispatcherModule.kt#L14-L26)
- [AuthRepositoryImpl.kt:24-146](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L24-L146)

### Usage Examples and Integration Patterns
- Authentication flow
  - LoginViewModel triggers LoginUseCase, which delegates to AuthRepositoryImpl
  - AuthRepositoryImpl uses FirebaseAuthService for credentials and FirestoreService to load user profile
  - On success, emits UitResult.Success with mapped User model

- Registration flow
  - RegisterViewModel triggers RegisterUseCase, which delegates to AuthRepositoryImpl
  - On success, creates user record in Firestore and emits UitResult.Success

- Real-time updates
  - FirestoreService supports observeDocument and observeCollection
  - AuthRepositoryImpl maps auth state changes to user state for UI consumption

```mermaid
sequenceDiagram
participant UI as "RegisterViewModel"
participant UC as "RegisterUseCase"
participant Repo as "AuthRepositoryImpl"
participant Auth as "FirebaseAuthService"
participant Store as "FirestoreService"
UI->>UC : invoke(email, password, displayName)
UC->>Repo : register(email, password, displayName)
Repo->>Auth : createUser(email, password)
Auth-->>Repo : AuthResult
Repo->>Store : setDocument(users, uid, userDto)
Store-->>Repo : success
Repo-->>UC : Flow<UitResult<User>>
UC-->>UI : Flow<UitResult<User>>
UI-->>UI : Navigate to login
```

**Diagram sources**
- [RegisterViewModel.kt:112-134](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt#L112-L134)
- [AuthRepositoryImpl.kt:61-88](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L61-L88)
- [FirebaseAuthService.kt:20-21](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L20-L21)
- [FirestoreService.kt:64-76](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt#L64-L76)

**Section sources**
- [LoginViewModel.kt:72-94](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L72-L94)
- [RegisterViewModel.kt:112-134](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt#L112-L134)
- [AuthRepositoryImpl.kt:29-133](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L29-L133)
- [UserMapper.kt:6-28](file://core/core-data/src/main/java/com/uit20years/core/data/mapper/UserMapper.kt#L6-L28)

## Dependency Analysis
- Coupling
  - Services are loosely coupled via Hilt-provided singletons
  - Repositories depend on service interfaces, not concrete Firebase SDKs

- Cohesion
  - Each service encapsulates a single Firebase subsystem
  - AuthRepositoryImpl orchestrates auth and Firestore operations

- External dependencies
  - Firebase SDKs (Auth, Firestore, Storage)
  - Dagger Hilt for DI
  - Coroutines for async operations

```mermaid
graph LR
Hilt["Hilt DI Container"] --> FA["FirebaseAuthService"]
Hilt --> FS["FirestoreService"]
Hilt --> FU["FirebaseStorageService"]
AR["AuthRepositoryImpl"] --> FA
AR --> FS
LUC["LoginUseCase"] --> AR
LVM["LoginViewModel"] --> LUC
RVM["RegisterViewModel"] --> LUC
```

**Diagram sources**
- [FirebaseModule.kt:16-26](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt#L16-L26)
- [AuthRepositoryImpl.kt:24-146](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L24-L146)
- [LoginUseCase.kt:9-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L9-L14)
- [LoginViewModel.kt:21-99](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L21-L99)
- [RegisterViewModel.kt:21-140](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt#L21-L140)

**Section sources**
- [FirebaseModule.kt:12-27](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt#L12-L27)
- [AuthRepositoryImpl.kt:24-146](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L24-L146)

## Performance Considerations
- Prefer real-time listeners for frequently changing data to avoid polling
- Use Firestore query builders to limit result sets and reduce bandwidth
- Batch writes and transactions when updating multiple documents
- Compress media before uploading to reduce transfer time
- Use appropriate coroutine dispatchers for IO-bound operations

## Troubleshooting Guide
- Authentication errors
  - Invalid credentials: handled by catching invalid credentials exceptions and emitting localized error messages
  - Account collision: handled by catching user collision exceptions during registration

- Firestore errors
  - Network/database exceptions: caught and emitted as UitResult.Error with user-friendly messages
  - Document not found: repository emits an error when user profile does not exist post-login

- Real-time listeners
  - Listener cleanup: ensure registrations are removed when collectors cancel to prevent leaks
  - Snapshot handling: handle null snapshots and propagate errors to the Flow

- FCM integration
  - Token persistence: implement saving tokens to Firestore under user documents
  - Notification delivery: implement notification creation via NotificationManager

**Section sources**
- [AuthRepositoryImpl.kt:48-54](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L48-L54)
- [AuthRepositoryImpl.kt:81-87](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L81-L87)
- [AuthRepositoryImpl.kt:100-114](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L100-L114)
- [UitMessagingService.kt:12-19](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/fcm/UitMessagingService.kt#L12-L19)

## Conclusion
The core-firebase module cleanly abstracts Firebase services behind simple, testable interfaces. With Hilt-driven dependency injection, repositories orchestrate auth and data operations, while features consume them via use cases and ViewModels. The design enables scalable, maintainable integration with Firestore, Authentication, Storage, and FCM.

## Appendices

### Security Rules Considerations
- Firestore
  - Enforce read/write permissions per user ID for sensitive collections (e.g., users)
  - Limit query scopes and sizes to prevent excessive reads
- Authentication
  - Enforce strong password policies and email verification if enabled
- Storage
  - Restrict uploads to authenticated users and sanitize filenames
  - Use signed URLs with short expiration for downloads

### Example: Real-time Listener Flow
```mermaid
flowchart TD
Start(["observeDocument called"]) --> AddListener["Add snapshot listener"]
AddListener --> OnSnapshot{"Snapshot or Error?"}
OnSnapshot --> |Error| CloseWithError["Close with error"]
OnSnapshot --> |Snapshot| HasData{"Snapshot exists?"}
HasData --> |Yes| TrySend["Try send snapshot"]
HasData --> |No| Wait["Wait for next event"]
TrySend --> AwaitClose{"Collector cancelled?"}
Wait --> AwaitClose
AwaitClose --> |No| OnSnapshot
AwaitClose --> |Yes| RemoveListener["Remove listener and close"]
CloseWithError --> End(["End"])
RemoveListener --> End
```

**Diagram sources**
- [FirestoreService.kt:30-44](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt#L30-L44)

### Example: Transaction Usage
- Use runTransaction for atomic updates across documents
- Wrap transactional logic in try/catch and surface errors via UitResult

**Section sources**
- [FirestoreService.kt:98-105](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt#L98-L105)
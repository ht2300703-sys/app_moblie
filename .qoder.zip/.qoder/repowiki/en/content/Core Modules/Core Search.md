# Core Search

<cite>
**Referenced Files in This Document**
- [SearchService.kt](file://core/core-search/src/main/java/com/uit20years/core/search/SearchService.kt)
- [AlgoliaSearchServiceImpl.kt](file://core/core-search/src/main/java/com/uit20years/core/search/AlgoliaSearchServiceImpl.kt)
- [build.gradle.kts](file://core/core-search/build.gradle.kts)
- [UitResult.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt)
- [Heritage.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Heritage.kt)
- [HeritageRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/HeritageRepository.kt)
- [HeritageRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/HeritageRepositoryImpl.kt)
- [DispatcherModule.kt](file://app/src/main/java/com/uit20years/app/di/DispatcherModule.kt)
- [app build.gradle.kts](file://app/build.gradle.kts)
- [FlowExt.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/FlowExt.kt)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document describes the core-search module for the UIT20Years application. It defines the search service contract, outlines the planned Algolia-backed implementation, and explains how the module integrates with the broader architecture via dependency injection and the repository pattern. It also provides guidance on query building, pagination, analytics, caching, and performance optimization for scalable search.

## Project Structure
The core-search module is organized around a clean separation of concerns:
- Contract: SearchService interface defines the search API surface.
- Implementation: AlgoliaSearchServiceImpl provides a placeholder implementation intended to integrate with Algolia.
- Dependencies: The module depends on core-common and core-model, and is configured for Hilt dependency injection.

```mermaid
graph TB
subgraph "core-search"
SS["SearchService.kt"]
ASI["AlgoliaSearchServiceImpl.kt"]
BS["build.gradle.kts"]
end
subgraph "core-common"
UR["UitResult.kt"]
end
subgraph "core-model"
HM["Heritage.kt"]
end
subgraph "core-domain"
HRD["HeritageRepository.kt"]
end
subgraph "core-data"
HRI["HeritageRepositoryImpl.kt"]
end
subgraph "app"
DM["DispatcherModule.kt"]
ABG["app build.gradle.kts"]
end
ASI --> SS
ASI --> UR
ASI --> HM
HRI --> HRD
HRI --> UR
HRI --> HM
DM --> UR
ABG --> ASI
```

**Diagram sources**
- [SearchService.kt](file://core/core-search/src/main/java/com/uit20years/core/search/SearchService.kt)
- [AlgoliaSearchServiceImpl.kt](file://core/core-search/src/main/java/com/uit20years/core/search/AlgoliaSearchServiceImpl.kt)
- [build.gradle.kts](file://core/core-search/build.gradle.kts)
- [UitResult.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt)
- [Heritage.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Heritage.kt)
- [HeritageRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/HeritageRepository.kt)
- [HeritageRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/HeritageRepositoryImpl.kt)
- [DispatcherModule.kt](file://app/src/main/java/com/uit20years/app/di/DispatcherModule.kt)
- [app build.gradle.kts](file://app/build.gradle.kts)

**Section sources**
- [build.gradle.kts](file://core/core-search/build.gradle.kts)
- [app build.gradle.kts](file://app/build.gradle.kts)

## Core Components
- SearchService: Defines a single method to search heritage items by query and returns a Flow of UitResult wrapping a list of Heritage.
- AlgoliaSearchServiceImpl: Implements SearchService with a placeholder that emits Loading followed by an empty Success list. The implementation is annotated as Singleton and uses Hilt injection.
- UitResult: A sealed interface representing asynchronous operation outcomes (Loading, Success, Error) with helpers for safe unwrapping and branching.
- Heritage: The domain model returned by search, including metadata such as title, content, category, year, tags, and timestamps.

Key characteristics:
- Asynchronous streaming: Results are emitted as a Flow to support reactive UI updates.
- Domain-first: The service returns domain models (Heritage), not DTOs.
- Extensible contract: The interface currently supports heritage search; it can be extended to cover users, posts, and events.

**Section sources**
- [SearchService.kt](file://core/core-search/src/main/java/com/uit20years/core/search/SearchService.kt)
- [AlgoliaSearchServiceImpl.kt](file://core/core-search/src/main/java/com/uit20years/core/search/AlgoliaSearchServiceImpl.kt)
- [UitResult.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt)
- [Heritage.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Heritage.kt)

## Architecture Overview
The search capability follows a layered architecture:
- Presentation layer receives user queries and observes Flow emissions.
- Domain layer defines repository contracts.
- Data layer implements repositories and delegates search to SearchService.
- SearchService encapsulates external search provider integration (Algolia).

```mermaid
sequenceDiagram
participant UI as "UI Layer"
participant Repo as "HeritageRepositoryImpl"
participant Svc as "AlgoliaSearchServiceImpl"
participant Model as "Heritage"
UI->>Repo : "searchHeritage(query)"
Repo->>Svc : "searchHeritage(query)"
Svc-->>Repo : "Flow<UitResult<List<Heritage>>"
Repo-->>UI : "Flow<UitResult<List<Heritage>>"
Note over Svc,Model : "Algolia client would transform hits to domain models"
```

**Diagram sources**
- [HeritageRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/HeritageRepositoryImpl.kt)
- [AlgoliaSearchServiceImpl.kt](file://core/core-search/src/main/java/com/uit20years/core/search/AlgoliaSearchServiceImpl.kt)
- [Heritage.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Heritage.kt)

## Detailed Component Analysis

### SearchService Interface
- Purpose: Define the search contract for heritage items.
- Method: searchHeritage(query) returns Flow<UitResult<List<Heritage>>>.
- Design: Single-responsibility interface; can be extended for other domains (users, posts, events).

Implementation pattern:
- Emit Loading at the start of the Flow.
- Transform provider-specific results to domain models.
- Emit Success with mapped results or Error on failure.

**Section sources**
- [SearchService.kt](file://core/core-search/src/main/java/com/uit20years/core/search/SearchService.kt)

### AlgoliaSearchServiceImpl
- Responsibilities:
  - Implement SearchService.
  - Integrate Algolia Kotlin client (placeholder).
  - Map Algolia hits to domain models.
  - Emit Loading, Success, or Error.
- Current behavior: Emits Loading then an empty Success list; Algolia integration is marked as TODO.
- Injection: Singleton-scoped with Hilt constructor injection.

Recommended implementation steps:
- Add Algolia client dependency in build.gradle.kts.
- Initialize client and index in a Hilt-provided module.
- Build Algolia Query with optional filters, facets, and ranking.
- Map hits to domain models and handle pagination.

```mermaid
classDiagram
class SearchService {
+searchHeritage(query : String) Flow~UitResult~Heritage[]~~
}
class AlgoliaSearchServiceImpl {
+searchHeritage(query : String) Flow~UitResult~Heritage[]~~
}
class UitResult {
<<sealed>>
}
class Heritage {
+id : String
+title : String
+content : String
+category : HeritageCategory
+year : Int
+tags : String[]
+createdAt : Long
}
SearchService <|.. AlgoliaSearchServiceImpl
AlgoliaSearchServiceImpl --> UitResult : "emits"
AlgoliaSearchServiceImpl --> Heritage : "maps to"
```

**Diagram sources**
- [SearchService.kt](file://core/core-search/src/main/java/com/uit20years/core/search/SearchService.kt)
- [AlgoliaSearchServiceImpl.kt](file://core/core-search/src/main/java/com/uit20years/core/search/AlgoliaSearchServiceImpl.kt)
- [UitResult.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt)
- [Heritage.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Heritage.kt)

**Section sources**
- [AlgoliaSearchServiceImpl.kt](file://core/core-search/src/main/java/com/uit20years/core/search/AlgoliaSearchServiceImpl.kt)
- [build.gradle.kts](file://core/core-search/build.gradle.kts)

### Repository Integration
- HeritageRepository defines searchHeritage(query) in the domain layer.
- HeritageRepositoryImpl delegates to SearchService in the data layer.
- Current implementation mirrors SearchService behavior with TODO comments indicating Algolia or Firestore integration.

```mermaid
flowchart TD
Start(["Call searchHeritage(query)"]) --> EmitLoading["Emit Loading"]
EmitLoading --> ProviderCall{"Provider Available?"}
ProviderCall --> |Yes| FetchResults["Fetch from SearchProvider"]
ProviderCall --> |No| ReturnEmpty["Return Empty Results"]
FetchResults --> MapToDomain["Map to Domain Models"]
MapToDomain --> EmitSuccess["Emit Success(List<Heritage>)"]
ReturnEmpty --> EmitSuccess
EmitSuccess --> End(["Done"])
```

**Diagram sources**
- [HeritageRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/HeritageRepository.kt)
- [HeritageRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/HeritageRepositoryImpl.kt)
- [SearchService.kt](file://core/core-search/src/main/java/com/uit20years/core/search/SearchService.kt)

**Section sources**
- [HeritageRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/HeritageRepository.kt)
- [HeritageRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/HeritageRepositoryImpl.kt)

### Dependency Injection Configuration
- Hilt setup:
  - core-search applies Hilt Android plugin and depends on core-common and core-model.
  - app module declares DispatcherModule providing coroutine dispatchers annotated with @IoDispatcher and @DefaultDispatcher.
  - app build.gradle.kts includes core-search as an implementation dependency.
- Injection points:
  - AlgoliaSearchServiceImpl is annotated Singleton and uses constructor injection.
  - A Hilt module should provide the Algolia client and index.

Integration guidance:
- Create a dedicated DI module in core-search to provide Algolia client and index.
- Bind SearchService to AlgoliaSearchServiceImpl using Dagger/Hilt.
- Inject SearchService into repositories or use cases as needed.

**Section sources**
- [build.gradle.kts](file://core/core-search/build.gradle.kts)
- [DispatcherModule.kt](file://app/src/main/java/com/uit20years/app/di/DispatcherModule.kt)
- [app build.gradle.kts](file://app/build.gradle.kts)

## Dependency Analysis
- Internal dependencies:
  - core-search depends on core-common (UitResult) and core-model (Heritage).
- External dependencies:
  - Algolia client dependency is currently commented out; add when integrating.
- Application integration:
  - app module includes core-search, enabling downstream features to consume search capabilities.

Potential circular dependencies:
- None observed among core-search, core-common, and core-model.
- Ensure DI modules are scoped to SingletonComponent to avoid lifecycle issues.

**Section sources**
- [build.gradle.kts](file://core/core-search/build.gradle.kts)
- [app build.gradle.kts](file://app/build.gradle.kts)

## Performance Considerations
- Query optimization:
  - Use filters and facets to narrow results early.
  - Apply typo-tolerant settings judiciously to balance relevance and performance.
- Pagination:
  - Use Algolia’s built-in pagination (page, hitsPerPage) to limit payload size.
  - Implement cursor-based pagination for deep paging scenarios.
- Ranking:
  - Configure custom ranking attributes (e.g., recency, popularity) to improve relevance.
  - Use search rules and query rules to adjust ranking dynamically.
- Caching:
  - Cache frequent queries with short TTLs to reduce latency.
  - Invalidate cache entries on data changes.
- Analytics:
  - Track search volume, click-through rates, and conversion metrics.
  - Use analytics to refine ranking and filters.
- Concurrency:
  - Use IO dispatcher for network-bound search operations.
  - Debounce user input to avoid excessive requests.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and resolutions:
- Empty results:
  - Verify index configuration and records presence.
  - Confirm query parameters and filters are set correctly.
- No Algolia client:
  - Add Algolia client dependency and initialize in a Hilt module.
  - Ensure the index name matches the configured index.
- Incorrect mapping:
  - Validate DTO-to-domain mapping logic and field alignment.
- Dispatcher errors:
  - Ensure IO dispatcher is provided and used for search operations.

Related utilities:
- UitResult helpers for safe unwrapping and branching.
- FlowExt extension to convert arbitrary Flows to UitResult streams.

**Section sources**
- [UitResult.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt)
- [FlowExt.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/FlowExt.kt)

## Conclusion
The core-search module establishes a clean contract for search operations and a clear path to integrate Algolia. By adhering to the repository pattern, leveraging Hilt for DI, and following performance and observability best practices, the module can evolve to support scalable, fast, and relevant search across multiple domains.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### Example Implementation Patterns
- Query building:
  - Construct Algolia Query with filters, facets, and custom ranking.
  - Apply optional tags or categories to refine results.
- Result pagination:
  - Use page-based pagination with configurable page size.
  - For deep pagination, adopt cursor-based approaches.
- Analytics:
  - Log search queries, refinement actions, and clicks.
  - Measure latency and error rates per endpoint.
- Caching:
  - Cache recent queries with short TTLs.
  - Invalidate on content updates.

[No sources needed since this section provides general guidance]
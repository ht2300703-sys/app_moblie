# Core Media

<cite>
**Referenced Files in This Document**
- [ImageCompressor.kt](file://core/core-media/src/main/java/com/uit20years/core/media/ImageCompressor.kt)
- [MediaUploader.kt](file://core/core-media/src/main/java/com/uit20years/core/media/MediaUploader.kt)
- [MediaModule.kt](file://core/core-media/src/main/java/com/uit20years/core/media/di/MediaModule.kt)
- [FirebaseStorageService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/storage/FirebaseStorageService.kt)
- [FirebaseModule.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt)
- [UIT20YearsApplication.kt](file://app/src/main/java/com/uit20years/app/UIT20YearsApplication.kt)
- [AppConstants.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/constants/AppConstants.kt)
- [Dispatchers.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/dispatcher/Dispatchers.kt)
- [build.gradle.kts (core-media)](file://core/core-media/build.gradle.kts)
- [build.gradle.kts (core-firebase)](file://core/core-firebase/build.gradle.kts)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document describes the core-media module responsible for media processing and upload functionality in the UIT20Years application. It focuses on:
- ImageCompressor: resizing and compressing images to reduce file size while preserving visual fidelity.
- MediaUploader: orchestrating image uploads to Firebase Storage with quality control and progress-like feedback.
- Dependency Injection: Hilt-based configuration that wires ImageCompressor and MediaUploader into the application.
- Integration points: How these services connect with Firebase Storage and the broader application architecture.

The goal is to provide a practical guide for developers to understand workflows, compression strategies, upload pipelines, error recovery, performance, and best practices for handling various media formats.

## Project Structure
The core-media module is organized around two primary utilities and a DI module:
- ImageCompressor: performs bitmap resizing and JPEG compression.
- MediaUploader: reads URIs, compresses images, uploads to Firebase Storage, and returns download URLs.
- MediaModule: provides Hilt bindings for ImageCompressor and MediaUploader.

```mermaid
graph TB
subgraph "core-media"
IC["ImageCompressor.kt"]
MU["MediaUploader.kt"]
MM["MediaModule.kt"]
end
subgraph "core-firebase"
FSS["FirebaseStorageService.kt"]
FM["FirebaseModule.kt"]
end
subgraph "app"
APP["UIT20YearsApplication.kt"]
end
MU --> IC
MU --> FSS
MM --> IC
MM --> MU
FM --> FSS
APP --> MM
APP --> FM
```

**Diagram sources**
- [ImageCompressor.kt:1-59](file://core/core-media/src/main/java/com/uit20years/core/media/ImageCompressor.kt#L1-L59)
- [MediaUploader.kt:1-52](file://core/core-media/src/main/java/com/uit20years/core/media/MediaUploader.kt#L1-L52)
- [MediaModule.kt:1-28](file://core/core-media/src/main/java/com/uit20years/core/media/di/MediaModule.kt#L1-L28)
- [FirebaseStorageService.kt:1-32](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/storage/FirebaseStorageService.kt#L1-L32)
- [FirebaseModule.kt:1-28](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt#L1-L28)
- [UIT20YearsApplication.kt:1-8](file://app/src/main/java/com/uit20years/app/UIT20YearsApplication.kt#L1-L8)

**Section sources**
- [build.gradle.kts (core-media):1-17](file://core/core-media/build.gradle.kts#L1-L17)
- [build.gradle.kts (core-firebase):1-17](file://core/core-firebase/build.gradle.kts#L1-L17)

## Core Components
- ImageCompressor
  - Resizes bitmaps to fit within maximum width/height while preserving aspect ratio.
  - Compresses to JPEG with configurable quality.
  - Exposes methods to compress from a Bitmap or from raw bytes.
- MediaUploader
  - Opens content URIs, reads bytes, compresses, uploads to Firebase Storage, and retrieves a download URL.
  - Supports single and batch uploads with generated paths.
  - Uses IO dispatchers for background processing.
- MediaModule
  - Provides singleton instances of ImageCompressor and MediaUploader.
  - Injects FirebaseStorageService and Android Context.

**Section sources**
- [ImageCompressor.kt:12-32](file://core/core-media/src/main/java/com/uit20years/core/media/ImageCompressor.kt#L12-L32)
- [MediaUploader.kt:20-46](file://core/core-media/src/main/java/com/uit20years/core/media/MediaUploader.kt#L20-L46)
- [MediaModule.kt:14-26](file://core/core-media/src/main/java/com/uit20years/core/media/di/MediaModule.kt#L14-L26)

## Architecture Overview
The media pipeline integrates with Firebase Storage via a dedicated service. Hilt provides dependency injection across the app.

```mermaid
sequenceDiagram
participant Caller as "Caller"
participant MU as "MediaUploader"
participant IC as "ImageCompressor"
participant FS as "FirebaseStorageService"
Caller->>MU : "uploadImage(uri, path, quality)"
MU->>MU : "open content stream"
MU->>IC : "compressFromBytes(bytes, quality)"
IC-->>MU : "compressed bytes"
MU->>FS : "uploadImage(path, compressedBytes)"
FS-->>MU : "download URL"
MU-->>Caller : "download URL"
```

**Diagram sources**
- [MediaUploader.kt:20-35](file://core/core-media/src/main/java/com/uit20years/core/media/MediaUploader.kt#L20-L35)
- [ImageCompressor.kt:24-32](file://core/core-media/src/main/java/com/uit20years/core/media/ImageCompressor.kt#L24-L32)
- [FirebaseStorageService.kt:13-17](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/storage/FirebaseStorageService.kt#L13-L17)

## Detailed Component Analysis

### ImageCompressor
Responsibilities:
- Resize bitmaps to fit within configured bounds while preserving aspect ratio.
- Compress to JPEG with configurable quality.
- Provide convenience methods for Bitmap and byte arrays.

Key behaviors:
- Aspect-ratio-aware scaling ensures images do not stretch.
- Default quality and max dimensions are defined as constants.
- Output is a JPEG byte array suitable for upload.

```mermaid
flowchart TD
Start(["compressFromBytes(imageBytes, quality, maxWidth, maxHeight)"]) --> Decode["Decode bytes to Bitmap"]
Decode --> Resize["resizeBitmap(width, height, maxWidth, maxHeight)"]
Resize --> Compress["compress Bitmap to JPEG with quality"]
Compress --> Return["Return JPEG bytes"]
```

**Diagram sources**
- [ImageCompressor.kt:24-32](file://core/core-media/src/main/java/com/uit20years/core/media/ImageCompressor.kt#L24-L32)
- [ImageCompressor.kt:34-51](file://core/core-media/src/main/java/com/uit20years/core/media/ImageCompressor.kt#L34-L51)

**Section sources**
- [ImageCompressor.kt:12-32](file://core/core-media/src/main/java/com/uit20years/core/media/ImageCompressor.kt#L12-L32)
- [ImageCompressor.kt:34-51](file://core/core-media/src/main/java/com/uit20years/core/media/ImageCompressor.kt#L34-L51)

### MediaUploader
Responsibilities:
- Open content URIs, read bytes, compress, upload to Firebase Storage, and return a download URL.
- Support batch uploads with unique paths.
- Manage background execution using IO dispatcher.

Processing logic:
- Validates input stream availability.
- Reads all bytes from the URI.
- Delegates compression to ImageCompressor.
- Uploads to Firebase Storage and returns the download URL.

```mermaid
sequenceDiagram
participant Caller as "Caller"
participant MU as "MediaUploader"
participant IC as "ImageCompressor"
participant FS as "FirebaseStorageService"
Caller->>MU : "uploadImages(uris, basePath, quality)"
loop "for each uri"
MU->>MU : "generate path"
MU->>MU : "open content stream"
MU->>IC : "compressFromBytes(bytes, quality)"
IC-->>MU : "compressed bytes"
MU->>FS : "uploadImage(path, compressedBytes)"
FS-->>MU : "download URL"
end
MU-->>Caller : "List of download URLs"
```

**Diagram sources**
- [MediaUploader.kt:37-46](file://core/core-media/src/main/java/com/uit20years/core/media/MediaUploader.kt#L37-L46)
- [MediaUploader.kt:20-35](file://core/core-media/src/main/java/com/uit20years/core/media/MediaUploader.kt#L20-L35)
- [FirebaseStorageService.kt:13-17](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/storage/FirebaseStorageService.kt#L13-L17)

**Section sources**
- [MediaUploader.kt:20-46](file://core/core-media/src/main/java/com/uit20years/core/media/MediaUploader.kt#L20-L46)

### Dependency Injection Configuration
- MediaModule provides:
  - ImageCompressor as a singleton.
  - MediaUploader with injected ImageCompressor, FirebaseStorageService, and Android Context.
- FirebaseModule provides FirebaseStorage as a singleton.
- UIT20YearsApplication is annotated with @HiltAndroidApp to enable DI.

```mermaid
classDiagram
class ImageCompressor
class MediaUploader
class FirebaseStorageService
class MediaModule
class FirebaseModule
class UIT20YearsApplication
MediaModule --> ImageCompressor : "provides"
MediaModule --> MediaUploader : "provides"
MediaUploader --> ImageCompressor : "depends on"
MediaUploader --> FirebaseStorageService : "depends on"
FirebaseModule --> FirebaseStorageService : "provides"
UIT20YearsApplication --> MediaModule : "install in"
UIT20YearsApplication --> FirebaseModule : "install in"
```

**Diagram sources**
- [MediaModule.kt:14-26](file://core/core-media/src/main/java/com/uit20years/core/media/di/MediaModule.kt#L14-L26)
- [FirebaseModule.kt:24-26](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt#L24-L26)
- [UIT20YearsApplication.kt:6-7](file://app/src/main/java/com/uit20years/app/UIT20YearsApplication.kt#L6-L7)

**Section sources**
- [MediaModule.kt:14-26](file://core/core-media/src/main/java/com/uit20years/core/media/di/MediaModule.kt#L14-L26)
- [FirebaseModule.kt:24-26](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt#L24-L26)
- [UIT20YearsApplication.kt:6-7](file://app/src/main/java/com/uit20years/app/UIT20YearsApplication.kt#L6-L7)

## Dependency Analysis
- core-media depends on:
  - core-firebase for FirebaseStorageService.
  - core-common for shared utilities and constants.
  - AndroidX Core KTX and Kotlin Coroutines for IO operations.
- core-firebase provides FirebaseStorage via FirebaseModule.
- MediaModule composes these dependencies into MediaUploader.

```mermaid
graph LR
CM["core-media"] --> CF["core-firebase"]
CM --> CC["core-common"]
CF --> GS["Google Services SDK"]
CM --> AND["AndroidX Core KTX"]
CM --> KC["Kotlin Coroutines"]
```

**Diagram sources**
- [build.gradle.kts (core-media):10-16](file://core/core-media/build.gradle.kts#L10-L16)
- [build.gradle.kts (core-firebase):1-17](file://core/core-firebase/build.gradle.kts#L1-L17)

**Section sources**
- [build.gradle.kts (core-media):10-16](file://core/core-media/build.gradle.kts#L10-L16)
- [build.gradle.kts (core-firebase):1-17](file://core/core-firebase/build.gradle.kts#L1-L17)

## Performance Considerations
- Image compression defaults:
  - Quality: 80 (balanced compression vs. fidelity).
  - Max dimensions: 1920x1080 (default in ImageCompressor).
  - Shared constants define 1080x1080 for images in AppConstants.
- Background processing:
  - MediaUploader executes on IO dispatcher to avoid blocking the main thread.
- Memory management:
  - Prefer compressFromBytes to avoid loading large bitmaps unnecessarily.
  - Use appropriate max dimensions to limit decoded bitmap size.
- Batch uploads:
  - uploadImages generates unique paths to prevent collisions and simplify cleanup.

Best practices:
- Tune quality and max dimensions based on use case (e.g., profile photos vs. posts).
- Validate input URIs and handle null streams gracefully.
- Consider caching download URLs to avoid repeated network calls.

**Section sources**
- [ImageCompressor.kt:53-57](file://core/core-media/src/main/java/com/uit20years/core/media/ImageCompressor.kt#L53-L57)
- [AppConstants.kt:5-7](file://core/core-common/src/main/kotlin/com/uit20years/core/common/constants/AppConstants.kt#L5-L7)
- [MediaUploader.kt:24-35](file://core/core-media/src/main/java/com/uit20years/core/media/MediaUploader.kt#L24-L35)

## Troubleshooting Guide
Common issues and resolutions:
- Cannot open image stream:
  - Symptom: IllegalStateException thrown when opening content stream.
  - Resolution: Verify URI validity and permissions; ensure the content provider allows access.
- Large memory usage during decoding:
  - Symptom: OutOfMemoryError when decoding large images.
  - Resolution: Use compressFromBytes to avoid loading full-resolution bitmaps; adjust max dimensions.
- Upload failures:
  - Symptom: Exceptions during upload or URL retrieval.
  - Resolution: Retry logic and network checks; confirm Firebase credentials and storage rules.
- Incorrect aspect ratio or stretched images:
  - Symptom: Distorted images after compression.
  - Resolution: Ensure resizeBitmap preserves aspect ratio; verify max width/height constraints.

Recovery mechanisms:
- Validate input stream before reading bytes.
- Wrap upload operations in try-catch blocks to surface meaningful errors.
- Use unique paths for batch uploads to simplify cleanup and deduplication.

**Section sources**
- [MediaUploader.kt:25-28](file://core/core-media/src/main/java/com/uit20years/core/media/MediaUploader.kt#L25-L28)
- [ImageCompressor.kt:34-51](file://core/core-media/src/main/java/com/uit20years/core/media/ImageCompressor.kt#L34-L51)
- [FirebaseStorageService.kt:13-17](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/storage/FirebaseStorageService.kt#L13-L17)

## Conclusion
The core-media module provides a focused, DI-driven solution for image compression and upload. ImageCompressor efficiently reduces file sizes while preserving visual quality, and MediaUploader orchestrates the upload process with robust error handling. Together with FirebaseStorageService and Hilt’s dependency graph, the module integrates cleanly into the broader application architecture.

## Appendices

### Compression Strategies
- Choose quality and max dimensions based on the intended use:
  - Profile photos: lower max dimensions and moderate quality.
  - Posts: higher max dimensions with balanced quality.
- Use compressFromBytes to avoid unnecessary bitmap allocations.
- Consider pre-scaling images before capture to reduce workload.

### Upload Pipelines
- Single upload:
  - Resolve URI to bytes, compress, upload, and retrieve URL.
- Batch upload:
  - Iterate over URIs, generate unique paths, and collect download URLs.

### Error Recovery
- Stream errors: validate URI and permissions.
- Compression errors: adjust quality/max dimensions.
- Upload errors: retry with exponential backoff and fallback URLs.
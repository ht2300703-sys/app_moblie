# Core UI

<cite>
**Referenced Files in This Document**
- [Color.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Color.kt)
- [Shape.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Shape.kt)
- [Type.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Type.kt)
- [Theme.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Theme.kt)
- [UitButton.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitButton.kt)
- [UitTextField.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTextField.kt)
- [UitTopBar.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTopBar.kt)
- [LoadingIndicator.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/LoadingIndicator.kt)
- [EmptyView.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/EmptyView.kt)
- [ErrorView.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/ErrorView.kt)
- [build.gradle.kts](file://core/core-ui/build.gradle.kts)
- [libs.versions.toml](file://gradle/libs.versions.toml)
- [MainActivity.kt](file://app/src/main/java/com/uit20years/app/MainActivity.kt)
- [AppNavHost.kt](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document describes the core-ui module that powers Material 3 theming and reusable UI components for the UIT20Years application. It explains the theme system (Color, Shape, Type, and Theme), details each reusable component (UitButton, UitTextField, UitTopBar, LoadingIndicator, EmptyView, and ErrorView), and shows how to integrate them with Jetpack Compose navigation. Accessibility, responsive design, dark mode support, and performance optimization are covered to help teams build consistent, accessible, and efficient UIs.

## Project Structure
The core-ui module is organized into two main packages:
- theme: Defines Material 3 color palettes, shapes, typography, and the top-level theme wrapper.
- component: Provides reusable UI components built on Material 3 primitives.

Key integration points:
- The application initializes the theme via a top-level composable and wraps the navigation host.
- Components consume Material 3 tokens from the current theme to remain consistent across light/dark modes.

```mermaid
graph TB
subgraph "core-ui Module"
THEME["Theme.kt<br/>UIT20YearsTheme"]
COLOR["Color.kt<br/>Brand & Extended Colors"]
SHAPE["Shape.kt<br/>RoundedCornerShape Sizes"]
TYPE["Type.kt<br/>Typography Scale"]
BTN["UitButton.kt"]
TXT["UitTextField.kt"]
TOPBAR["UitTopBar.kt"]
LOADER["LoadingIndicator.kt"]
EMPTY["EmptyView.kt"]
ERROR["ErrorView.kt"]
end
APP["MainActivity.kt<br/>UIT20YearsTheme + Surface + AppNavHost"]
NAV["AppNavHost.kt"]
APP --> THEME
THEME --> COLOR
THEME --> SHAPE
THEME --> TYPE
APP --> NAV
NAV --> BTN
NAV --> TXT
NAV --> TOPBAR
NAV --> LOADER
NAV --> EMPTY
NAV --> ERROR
```

**Diagram sources**
- [Theme.kt:57-82](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Theme.kt#L57-L82)
- [Color.kt:1-31](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Color.kt#L1-L31)
- [Shape.kt:1-14](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Shape.kt#L1-L14)
- [Type.kt:1-110](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Type.kt#L1-L110)
- [UitButton.kt:1-42](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitButton.kt#L1-L42)
- [UitTextField.kt:1-52](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTextField.kt#L1-L52)
- [UitTopBar.kt:1-43](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTopBar.kt#L1-L43)
- [LoadingIndicator.kt:1-23](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/LoadingIndicator.kt#L1-L23)
- [EmptyView.kt:1-31](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/EmptyView.kt#L1-L31)
- [ErrorView.kt:1-41](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/ErrorView.kt#L1-L41)
- [MainActivity.kt:15-26](file://app/src/main/java/com/uit20years/app/MainActivity.kt#L15-L26)
- [AppNavHost.kt:10-25](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L10-L25)

**Section sources**
- [Theme.kt:1-83](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Theme.kt#L1-L83)
- [UitButton.kt:1-42](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitButton.kt#L1-L42)
- [UitTextField.kt:1-52](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTextField.kt#L1-L52)
- [UitTopBar.kt:1-43](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTopBar.kt#L1-L43)
- [LoadingIndicator.kt:1-23](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/LoadingIndicator.kt#L1-L23)
- [EmptyView.kt:1-31](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/EmptyView.kt#L1-L31)
- [ErrorView.kt:1-41](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/ErrorView.kt#L1-L41)
- [MainActivity.kt:15-26](file://app/src/main/java/com/uit20years/app/MainActivity.kt#L15-L26)
- [AppNavHost.kt:10-25](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L10-L25)

## Core Components
This section documents the Material 3 theme system and reusable UI components.

### Material 3 Theme System
- Color: Defines brand colors and extended palettes for light and dark modes, plus status colors.
- Shape: Provides rounded corner sizes aligned with Material 3 scale.
- Type: Establishes a complete typography scale with font sizes, line heights, and letter spacing.
- Theme: Exposes a single composable that sets colorScheme, typography, and shapes, and configures status bar appearance.

Implementation highlights:
- Color palettes are derived from brand colors and extended tokens, ensuring consistent semantics across light/dark modes.
- Shapes and typography are centralized to enforce design consistency.
- The theme composable adapts to system dark mode and updates the status bar color accordingly.

**Section sources**
- [Color.kt:1-31](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Color.kt#L1-L31)
- [Shape.kt:1-14](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Shape.kt#L1-L14)
- [Type.kt:1-110](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Type.kt#L1-L110)
- [Theme.kt:15-82](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Theme.kt#L15-L82)

### Reusable Components
Each component is designed to be self-contained, theme-aware, and easy to customize.

- UitButton
  - Props: text, onClick, modifier, enabled, isLoading, backgroundColor.
  - Behavior: Displays a loading indicator when isLoading is true; disables interaction while loading; supports custom background color.
  - Accessibility: Inherits Material 3 button semantics; ensure sufficient contrast against backgroundColor.
  - Usage pattern: Place within screens; wire to ViewModel or state holders.

- UitTextField
  - Props: value, onValueChange, label, modifier, enabled, isError, errorMessage, visualTransformation, isPassword, maxLines.
  - Behavior: Renders outlined text field with custom indicator colors; displays error message below when isError is true.
  - Accessibility: Supports single-line vs multi-line via maxLines; ensure labels and error messages are localized.

- UitTopBar
  - Props: title, onBackClick?, actions.
  - Behavior: Provides a center-aligned top app bar with optional back navigation icon; action slot for contextual actions.
  - Accessibility: Back icon has content description; ensure actions are keyboard accessible.

- LoadingIndicator
  - Props: modifier, color.
  - Behavior: Centers a progress indicator in its container; useful during async operations.
  - Accessibility: Consider adding contentDescription for screen reader contexts.

- EmptyView
  - Props: message, modifier.
  - Behavior: Displays a centered message using onSurfaceVariant color for low prominence.
  - Accessibility: Keep messages concise and localized.

- ErrorView
  - Props: message, onRetry?, modifier.
  - Behavior: Displays an error message in error color and optionally a retry button.
  - Accessibility: Ensure retry button is reachable and labeled clearly.

**Section sources**
- [UitButton.kt:13-41](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitButton.kt#L13-L41)
- [UitTextField.kt:13-51](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTextField.kt#L13-L51)
- [UitTopBar.kt:15-42](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTopBar.kt#L15-L42)
- [LoadingIndicator.kt:11-22](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/LoadingIndicator.kt#L11-L22)
- [EmptyView.kt:13-30](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/EmptyView.kt#L13-L30)
- [ErrorView.kt:14-40](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/ErrorView.kt#L14-L40)

## Architecture Overview
The theme and components are wired at the application level to ensure global consistency.

```mermaid
sequenceDiagram
participant Activity as "MainActivity"
participant Theme as "UIT20YearsTheme"
participant Surface as "Surface"
participant NavHost as "AppNavHost"
participant Screen as "Feature Screens"
Activity->>Theme : "Invoke with content"
Theme->>Theme : "Select colorScheme (light/dark)"
Theme->>Theme : "Apply typography and shapes"
Theme-->>Activity : "Theme applied"
Activity->>Surface : "Wrap content"
Surface->>NavHost : "Render"
NavHost->>Screen : "Navigate to destinations"
Screen->>Screen : "Use components (buttons, text fields, top bars)"
```

**Diagram sources**
- [MainActivity.kt:15-26](file://app/src/main/java/com/uit20years/app/MainActivity.kt#L15-L26)
- [Theme.kt:57-82](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Theme.kt#L57-L82)
- [AppNavHost.kt:10-25](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L10-L25)

## Detailed Component Analysis

### UitButton
- Composition pattern: Delegates to Material 3 Button; conditionally renders a progress indicator when isLoading is true.
- State management integration: onClick triggers external callbacks; callers manage enabled and isLoading states.
- Accessibility: Uses Material defaults; ensure backgroundColor meets contrast guidelines.

```mermaid
flowchart TD
Start(["UitButton invoked"]) --> CheckLoading{"isLoading?"}
CheckLoading --> |Yes| RenderLoader["Render CircularProgressIndicator"]
CheckLoading --> |No| RenderText["Render Text(label)"]
RenderLoader --> End(["Button ready"])
RenderText --> End
```

**Diagram sources**
- [UitButton.kt:22-40](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitButton.kt#L22-L40)

**Section sources**
- [UitButton.kt:13-41](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitButton.kt#L13-L41)

### UitTextField
- Composition pattern: Uses OutlinedTextField with custom indicator colors; error message rendered below when isError is true.
- State management integration: Expects caller to manage value and isError; integrates with form validation flows.
- Accessibility: Single-line mode when maxLines == 1; ensure labels and error messages are localized.

```mermaid
flowchart TD
Start(["UitTextField invoked"]) --> RenderField["Render OutlinedTextField"]
RenderField --> IsError{"isError?"}
IsError --> |Yes| ShowError["Render errorMessage in red"]
IsError --> |No| Done["Done"]
ShowError --> Done
```

**Diagram sources**
- [UitTextField.kt:26-43](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTextField.kt#L26-L43)
- [UitTextField.kt:44-50](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTextField.kt#L44-L50)

**Section sources**
- [UitTextField.kt:13-51](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTextField.kt#L13-L51)

### UitTopBar
- Composition pattern: Uses CenterAlignedTopAppBar with optional back navigation and action slot.
- State management integration: onBackClick is optional; actions are composables for flexibility.
- Accessibility: Back icon has content description; ensure actions are keyboard accessible.

```mermaid
sequenceDiagram
participant Bar as "UitTopBar"
participant Back as "Back IconButton"
participant Actions as "Actions Slot"
Bar->>Back : "Show if onBackClick provided"
Bar->>Actions : "Render action composable"
Back-->>Bar : "onClick invokes onBackClick"
```

**Diagram sources**
- [UitTopBar.kt:22-41](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTopBar.kt#L22-L41)

**Section sources**
- [UitTopBar.kt:15-42](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTopBar.kt#L15-L42)

### LoadingIndicator
- Composition pattern: Centers a progress indicator inside a Box with fillMaxSize.
- State management integration: Typically shown during loading states; callers hide when data arrives.

```mermaid
flowchart TD
Start(["LoadingIndicator invoked"]) --> Container["Box fillMaxSize"]
Container --> Center["Alignment.Center"]
Center --> Spinner["CircularProgressIndicator"]
Spinner --> End(["Visible until hidden"])
```

**Diagram sources**
- [LoadingIndicator.kt:16-21](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/LoadingIndicator.kt#L16-L21)

**Section sources**
- [LoadingIndicator.kt:11-22](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/LoadingIndicator.kt#L11-L22)

### EmptyView
- Composition pattern: Column with centered text using onSurfaceVariant color.
- State management integration: Receives a message; callers decide when to show based on data state.

```mermaid
flowchart TD
Start(["EmptyView invoked"]) --> Layout["Column fillMaxSize + padding"]
Layout --> CenterText["Centered Text with bodyLarge"]
CenterText --> End(["Rendered"])
```

**Diagram sources**
- [EmptyView.kt:18-29](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/EmptyView.kt#L18-L29)

**Section sources**
- [EmptyView.kt:13-30](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/EmptyView.kt#L13-L30)

### ErrorView
- Composition pattern: Column with error-colored message and optional retry button.
- State management integration: onRetry allows callers to trigger re-fetch or re-attempt actions.

```mermaid
flowchart TD
Start(["ErrorView invoked"]) --> Message["Render error message"]
Message --> RetryCheck{"onRetry provided?"}
RetryCheck --> |Yes| Button["Render Retry Button"]
RetryCheck --> |No| End(["Rendered"])
Button --> End
```

**Diagram sources**
- [ErrorView.kt:20-39](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/ErrorView.kt#L20-L39)

**Section sources**
- [ErrorView.kt:14-40](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/ErrorView.kt#L14-L40)

## Dependency Analysis
The core-ui module depends on Compose BOM and lifecycle libraries, and integrates with the application via a theme wrapper and navigation host.

```mermaid
graph TB
COREUI["core-ui build.gradle.kts"]
COMPOSE["Compose BOM (material3, ui, icons)"]
LIFE["Lifecycle Compose (runtime, viewmodel)"]
APPMAIN["MainActivity.kt"]
NAVHOST["AppNavHost.kt"]
COREUI --> COMPOSE
COREUI --> LIFE
APPMAIN --> COREUI
NAVHOST --> COREUI
```

**Diagram sources**
- [build.gradle.kts:10-17](file://core/core-ui/build.gradle.kts#L10-L17)
- [libs.versions.toml:29-44](file://gradle/libs.versions.toml#L29-L44)
- [MainActivity.kt:15-26](file://app/src/main/java/com/uit20years/app/MainActivity.kt#L15-L26)
- [AppNavHost.kt:10-25](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L10-L25)

**Section sources**
- [build.gradle.kts:10-17](file://core/core-ui/build.gradle.kts#L10-L17)
- [libs.versions.toml:29-44](file://gradle/libs.versions.toml#L29-L44)

## Performance Considerations
- Prefer lightweight composables: Keep component bodies small and avoid unnecessary recompositions by passing stable lambdas and immutable data.
- Use Modifier.fillMaxWidth judiciously: Ensure full-width layouts are needed; otherwise prefer constrained widths for better layout stability.
- Minimize nested layouts: Flatten hierarchies where possible to reduce measure/layout cost.
- Leverage lazy lists: For long lists, use LazyColumn/LazyRow to render only visible items.
- Avoid heavy work on the main thread: Offload to appropriate dispatchers and expose loading states via isLoading flags.
- Theme consistency: Using Material 3 tokens reduces duplication and improves rendering performance by relying on shared resources.

## Troubleshooting Guide
Common issues and resolutions:
- Incorrect contrast in custom backgrounds: Ensure backgroundColor passes accessibility contrast checks against onPrimary/onSurface.
- Status bar visibility in dark mode: The theme adjusts status bar appearance automatically; verify system dark mode settings and window insets.
- Error message not visible: For UitTextField, ensure isError is set true when validation fails and errorMessage is non-null.
- Navigation not updating: Confirm AppNavHost is wrapped by UIT20YearsTheme and Surface.

**Section sources**
- [Theme.kt:67-74](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Theme.kt#L67-L74)
- [UitTextField.kt:44-50](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitTextField.kt#L44-L50)
- [AppNavHost.kt:10-25](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L10-L25)

## Conclusion
The core-ui module establishes a cohesive Material 3 foundation and a set of reusable components that are theme-aware, accessible, and easy to integrate. By centralizing theme definitions and composing components thoughtfully, teams can maintain consistency, improve developer productivity, and deliver high-quality user experiences across light and dark modes.

## Appendices

### Theme Customization Examples
- Override brand colors: Modify brand tokens in Color.kt and rebuild the theme.
- Adjust typography: Update Type.kt to change font scales; ensure readability across devices.
- Customize shapes: Change shape radii in Shape.kt to reflect product personality.
- Theme overrides per screen: Wrap a subtree with a custom MaterialTheme to temporarily override tokens.

**Section sources**
- [Color.kt:5-30](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Color.kt#L5-L30)
- [Type.kt:9-109](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Type.kt#L9-L109)
- [Shape.kt:7-13](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Shape.kt#L7-L13)
- [Theme.kt:57-82](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Theme.kt#L57-L82)

### Integration with Jetpack Compose Navigation
- Initialize theme at activity startup and wrap the NavHost.
- Use AppNavHost to define destinations and pass a NavController.
- Render components within composables that are part of the navigation graph.

```mermaid
sequenceDiagram
participant Activity as "MainActivity"
participant Theme as "UIT20YearsTheme"
participant Surface as "Surface"
participant NavHost as "AppNavHost"
participant Dest as "Destination Screen"
Activity->>Theme : "Apply theme"
Theme->>Surface : "Provide theme to content"
Surface->>NavHost : "Render NavHost"
NavHost->>Dest : "Navigate to destination"
Dest->>Dest : "Use core-ui components"
```

**Diagram sources**
- [MainActivity.kt:15-26](file://app/src/main/java/com/uit20years/app/MainActivity.kt#L15-L26)
- [AppNavHost.kt:10-25](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L10-L25)

**Section sources**
- [MainActivity.kt:15-26](file://app/src/main/java/com/uit20years/app/MainActivity.kt#L15-L26)
- [AppNavHost.kt:10-25](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L10-L25)
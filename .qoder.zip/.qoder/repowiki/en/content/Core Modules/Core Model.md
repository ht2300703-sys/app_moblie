# Core Model

<cite>
**Referenced Files in This Document**
- [User.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt)
- [Post.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Post.kt)
- [Comment.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Comment.kt)
- [Event.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Event.kt)
- [Heritage.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Heritage.kt)
- [Notification.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Notification.kt)
- [Reaction.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Reaction.kt)
- [UserDto.kt](file://core/core-data/src/main/java/com/uit20years/core/data/dto/UserDto.kt)
- [PostDto.kt](file://core/core-data/src/main/java/com/uit20years/core/data/dto/PostDto.kt)
- [CommentDto.kt](file://core/core-data/src/main/java/com/uit20years/core/data/dto/CommentDto.kt)
- [EventDto.kt](file://core/core-data/src/main/java/com/uit20years/core/data/dto/EventDto.kt)
- [HeritageDto.kt](file://core/core-data/src/main/java/com/uit20years/core/data/dto/HeritageDto.kt)
- [NotificationDto.kt](file://core/core-data/src/main/java/com/uit20years/core/data/dto/NotificationDto.kt)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document describes the core-model module that defines the domain entities and data structures used across the UIT20Years application. It documents each model class (User, Post, Comment, Event, Heritage, Notification, and Reaction), their properties, relationships, and business significance. It also explains validation rules, immutability patterns, serialization requirements, and mapping between DTOs and domain models. Finally, it outlines best practices for extending or modifying models while maintaining data consistency and supporting the overall application architecture.

## Project Structure
The core-model module contains immutable data classes representing domain entities. These models are intentionally lightweight and free of business logic, enabling reuse across features and layers. Related DTOs live in the core-data module to separate persistence concerns from domain semantics.

```mermaid
graph TB
subgraph "core-model"
UM["User.kt"]
PM["Post.kt"]
CM["Comment.kt"]
EM["Event.kt"]
HM["Heritage.kt"]
NM["Notification.kt"]
RM["Reaction.kt"]
end
subgraph "core-data"
UDTO["UserDto.kt"]
PDTO["PostDto.kt"]
CDTO["CommentDto.kt"]
EDTO["EventDto.kt"]
HDTO["HeritageDto.kt"]
NDTO["NotificationDto.kt"]
end
UM --> UDTO
PM --> PDTO
CM --> CDTO
EM --> EDTO
HM --> HDTO
NM --> NDTO
```

**Diagram sources**
- [User.kt:1-23](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt#L1-L23)
- [Post.kt:1-23](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Post.kt#L1-L23)
- [Comment.kt:1-12](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Comment.kt#L1-L12)
- [Event.kt:1-28](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Event.kt#L1-L28)
- [Heritage.kt:1-21](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Heritage.kt#L1-L21)
- [Notification.kt:1-22](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Notification.kt#L1-L22)
- [Reaction.kt:1-14](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Reaction.kt#L1-L14)
- [UserDto.kt:1-19](file://core/core-data/src/main/java/com/uit20years/core/data/dto/UserDto.kt#L1-L19)
- [PostDto.kt:1-18](file://core/core-data/src/main/java/com/uit20years/core/data/dto/PostDto.kt#L1-L18)
- [CommentDto.kt:1-14](file://core/core-data/src/main/java/com/uit20years/core/data/dto/CommentDto.kt#L1-L14)
- [EventDto.kt:1-19](file://core/core-data/src/main/java/com/uit20years/core/data/dto/EventDto.kt#L1-L19)
- [HeritageDto.kt:1-17](file://core/core-data/src/main/java/com/uit20years/core/data/dto/HeritageDto.kt#L1-L17)
- [NotificationDto.kt:1-17](file://core/core-data/src/main/java/com/uit20years/core/data/dto/NotificationDto.kt#L1-L17)

**Section sources**
- [User.kt:1-23](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt#L1-L23)
- [Post.kt:1-23](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Post.kt#L1-L23)
- [Comment.kt:1-12](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Comment.kt#L1-L12)
- [Event.kt:1-28](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Event.kt#L1-L28)
- [Heritage.kt:1-21](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Heritage.kt#L1-L21)
- [Notification.kt:1-22](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Notification.kt#L1-L22)
- [Reaction.kt:1-14](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Reaction.kt#L1-L14)

## Core Components
This section introduces each domain entity, its purpose, and key characteristics.

- User
  - Purpose: Represents an application user with profile metadata and role-based permissions.
  - Key properties: Identifier, contact info, display identity, optional avatar/bio/faculty/graduation year, role enumeration, counts, timestamps.
  - Business significance: Central identity for posts, comments, reactions, and notifications; role governs access and actions.

- Post
  - Purpose: Represents a user-generated post with content, media, and engagement metrics.
  - Key properties: Author identity, content, optional media URLs and hashtags, counts, visibility flag, timestamps, and current-user like flag.
  - Business significance: Core social feed item; supports public/private visibility and engagement analytics.

- Comment
  - Purpose: Represents a comment on a post with author attribution and creation time.
  - Key properties: Post reference, author identity, content, timestamps.
  - Business significance: Enables threaded discussions under posts.

- Event
  - Purpose: Represents an activity or gathering with scheduling, registration, and metadata.
  - Key properties: Title, description/location, image, timing, organizer, attendance count, capacity, type, livestream URL, registration flag, timestamps.
  - Business significance: Supports event discovery, registration, reminders, and updates.

- Heritage
  - Purpose: Represents institutional milestones and achievements with categorization and tagging.
  - Key properties: Title, content, media, category, year, tags, timestamps.
  - Business significance: Curates historical narrative and showcases institutional progress.

- Notification
  - Purpose: Represents user-targeted alerts with contextual references.
  - Key properties: Recipient, title/body, type, optional reference ID, read state, timestamps.
  - Business significance: Drives user engagement via timely updates.

- Reaction
  - Purpose: Represents a quick sentiment expression on posts or comments.
  - Key properties: Actor, reaction type, timestamp.
  - Business significance: Captures immediate feedback and sentiment trends.

Validation and immutability:
- All models are declared as immutable data classes, ensuring value equality and safe sharing across threads.
- Optional fields indicate nullable or missing data; defaults are provided where appropriate to avoid null checks in consumers.
- Enumerations constrain values to predefined sets, preventing invalid states.

Serialization requirements:
- Domain models are designed for clarity and portability; consumers may serialize them as needed.
- DTOs carry Firestore-specific annotations and server-side timestamps, while domain models keep logical semantics.

**Section sources**
- [User.kt:1-23](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt#L1-L23)
- [Post.kt:1-23](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Post.kt#L1-L23)
- [Comment.kt:1-12](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Comment.kt#L1-L12)
- [Event.kt:1-28](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Event.kt#L1-L28)
- [Heritage.kt:1-21](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Heritage.kt#L1-L21)
- [Notification.kt:1-22](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Notification.kt#L1-L22)
- [Reaction.kt:1-14](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Reaction.kt#L1-L14)

## Architecture Overview
Domain models are intentionally thin and reside in core-model. They are mapped to/from DTOs in core-data for persistence and transport. This separation ensures:
- Domain purity: Business logic remains decoupled from storage specifics.
- Clear boundaries: DTOs encapsulate persistence concerns (e.g., server timestamps).
- Extensibility: New fields can be added to DTOs without changing domain contracts.

```mermaid
graph TB
DM["Domain Models<br/>core-model"]
DTO["DTOs<br/>core-data"]
FS["Firestore"]
NET["Network Layer"]
DM --> DTO
DTO --> FS
DTO --> NET
FS --> DTO
NET --> DTO
DTO --> DM
```

[No sources needed since this diagram shows conceptual workflow, not actual code structure]

## Detailed Component Analysis

### User
- Properties and roles:
  - Identity: unique identifier, email, display name.
  - Profile: optional avatar, bio, faculty, graduation year.
  - Access control: role enumeration with student/alumni/lecturer/admin tiers.
  - Metrics: follower and following counts.
  - Timestamps: creation time.
- Validation:
  - Non-empty identifiers and emails in practice; enforce at edges (UI/API).
  - Role defaults to a safe default if absent.
- Serialization:
  - Suitable for JSON/network transport; consider trimming optional fields when null.
- Relationships:
  - Author of Posts and Comments.
  - Triggers Notifications and Reactions.
- Usage examples:
  - Display profile cards with avatar and bio.
  - Enforce role-based UI and actions.
  - Track followers for social graph features.

**Section sources**
- [User.kt:1-23](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt#L1-L23)

### Post
- Properties and visibility:
  - Author identity and optional avatar/name for display.
  - Content, optional media and hashtags.
  - Engagement: like/comment counts, current-user like flag.
  - Visibility: public/private.
  - Timestamps: created/updated.
- Validation:
  - Content should be non-empty for published posts.
  - Media URLs should be validated at ingestion points.
- Serialization:
  - Serialize minimal payload for feeds; expand on demand.
- Relationships:
  - Contains Comments and Reactions.
  - Linked to Author (User).
- Usage examples:
  - Feed rendering with pagination and filtering by visibility.
  - Like/unlike toggling updates counts and current-user flag.

**Section sources**
- [Post.kt:1-23](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Post.kt#L1-L23)

### Comment
- Properties:
  - Post reference, author identity, content, timestamps.
- Validation:
  - Content should be non-empty; enforce length limits at edges.
- Serialization:
  - Include author display attributes for rich UI rendering.
- Relationships:
  - Belongs to Post; authored by User.
- Usage examples:
  - Threaded comment lists under a Post.
  - Real-time updates via listeners.

**Section sources**
- [Comment.kt:1-12](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Comment.kt#L1-L12)

### Event
- Properties:
  - Title, description/location, optional image and livestream URL.
  - Timing: start/end timestamps.
  - Organizer, attendance count, optional capacity.
  - Type enumeration covering general, sport, marathon, job fair, academic, ceremony.
  - Registration flag and timestamps.
- Validation:
  - End time must be after start time.
  - Capacity must be non-negative if present.
- Serialization:
  - Normalize dates to epoch milliseconds for cross-platform compatibility.
- Relationships:
  - Attendees represented by IDs; derived counts reflect registration.
- Usage examples:
  - Calendar views and event listings.
  - Registration flow and reminders.

**Section sources**
- [Event.kt:1-28](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Event.kt#L1-L28)

### Heritage
- Properties:
  - Title, content, optional media.
  - Category enumeration: milestone, achievement, infrastructure, academic, award.
  - Year and tags for discoverability.
  - Timestamps.
- Validation:
  - Year should be within reasonable bounds.
  - Tags should be curated or normalized.
- Serialization:
  - Efficient listing with minimal fields; full details on demand.
- Relationships:
  - Standalone archival items; may link to related Posts/Events historically.
- Usage examples:
  - Timeline and gallery views.
  - Search and filtering by category/year/tags.

**Section sources**
- [Heritage.kt:1-21](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Heritage.kt#L1-L21)

### Notification
- Properties:
  - Recipient, title/body, type enumeration, optional reference ID, read state, timestamps.
- Validation:
  - Reference ID should match the referenced entity type.
  - Read state should be consistent with backend updates.
- Serialization:
  - Include only necessary fields for push/alert delivery.
- Relationships:
  - Targets a User; references other entities (Post, Comment, Event).
- Usage examples:
  - Inbox with read/unread indicators.
  - Push notifications and deep links.

**Section sources**
- [Notification.kt:1-22](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Notification.kt#L1-L22)

### Reaction
- Properties:
  - Actor, reaction type enumeration (like, love, celebrate), timestamp.
- Validation:
  - Only allowed reaction types are permitted.
- Serialization:
  - Lightweight payload for real-time updates.
- Relationships:
  - Tied to Post or Comment; contributes to engagement analytics.
- Usage examples:
  - Live sentiment counters and trending reactions.

**Section sources**
- [Reaction.kt:1-14](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Reaction.kt#L1-L14)

## Architecture Overview

### Domain Model Class Diagram
```mermaid
classDiagram
class User {
+String uid
+String email
+String displayName
+String? avatarUrl
+String? bio
+String? faculty
+Int? graduationYear
+UserRole role
+Int followerCount
+Int followingCount
+Long createdAt
}
class Post {
+String id
+String authorId
+String authorName
+String? authorAvatarUrl
+String content
+String[] mediaUrls
+String[] hashtags
+Int likeCount
+Int commentCount
+Boolean isLikedByCurrentUser
+PostVisibility visibility
+Long createdAt
+Long updatedAt
}
class Comment {
+String id
+String postId
+String authorId
+String authorName
+String? authorAvatarUrl
+String content
+Long createdAt
}
class Event {
+String id
+String title
+String description
+String location
+String? imageUrl
+Long startTime
+Long endTime
+String organizerId
+Int attendeeCount
+Int? maxAttendees
+EventType type
+String? livestreamUrl
+Boolean isRegistered
+Long createdAt
}
class Heritage {
+String id
+String title
+String content
+String[] mediaUrls
+HeritageCategory category
+Int year
+String[] tags
+Long createdAt
}
class Notification {
+String id
+String userId
+String title
+String body
+NotificationType type
+String? referenceId
+Boolean isRead
+Long createdAt
}
class Reaction {
+String userId
+ReactionType type
+Long createdAt
}
class UserRole
class PostVisibility
class EventType
class HeritageCategory
class NotificationType
class ReactionType
Post --> User : "authorId"
Comment --> Post : "postId"
Comment --> User : "authorId"
Event --> User : "organizerId"
Notification --> User : "userId"
Reaction --> Post : "target"
Reaction --> Comment : "target"
```

**Diagram sources**
- [User.kt:1-23](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt#L1-L23)
- [Post.kt:1-23](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Post.kt#L1-L23)
- [Comment.kt:1-12](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Comment.kt#L1-L12)
- [Event.kt:1-28](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Event.kt#L1-L28)
- [Heritage.kt:1-21](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Heritage.kt#L1-L21)
- [Notification.kt:1-22](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Notification.kt#L1-L22)
- [Reaction.kt:1-14](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Reaction.kt#L1-L14)

### DTO Mapping Overview
Domain models are mapped to DTOs for persistence and transport. DTOs include server-managed timestamps and normalized fields.

```mermaid
graph LR
subgraph "Domain"
D_User["User"]
D_Post["Post"]
D_Comment["Comment"]
D_Event["Event"]
D_Heritage["Heritage"]
D_Notification["Notification"]
end
subgraph "DTO"
DTO_User["UserDto"]
DTO_Post["PostDto"]
DTO_Comment["CommentDto"]
DTO_Event["EventDto"]
DTO_Heritage["HeritageDto"]
DTO_Notification["NotificationDto"]
end
D_User --> DTO_User
D_Post --> DTO_Post
D_Comment --> DTO_Comment
D_Event --> DTO_Event
D_Heritage --> DTO_Heritage
D_Notification --> DTO_Notification
```

**Diagram sources**
- [User.kt:1-23](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt#L1-L23)
- [Post.kt:1-23](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Post.kt#L1-L23)
- [Comment.kt:1-12](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Comment.kt#L1-L12)
- [Event.kt:1-28](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Event.kt#L1-L28)
- [Heritage.kt:1-21](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Heritage.kt#L1-L21)
- [Notification.kt:1-22](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Notification.kt#L1-L22)
- [UserDto.kt:1-19](file://core/core-data/src/main/java/com/uit20years/core/data/dto/UserDto.kt#L1-L19)
- [PostDto.kt:1-18](file://core/core-data/src/main/java/com/uit20years/core/data/dto/PostDto.kt#L1-L18)
- [CommentDto.kt:1-14](file://core/core-data/src/main/java/com/uit20years/core/data/dto/CommentDto.kt#L1-L14)
- [EventDto.kt:1-19](file://core/core-data/src/main/java/com/uit20years/core/data/dto/EventDto.kt#L1-L19)
- [HeritageDto.kt:1-17](file://core/core-data/src/main/java/com/uit20years/core/data/dto/HeritageDto.kt#L1-L17)
- [NotificationDto.kt:1-17](file://core/core-data/src/main/java/com/uit20years/core/data/dto/NotificationDto.kt#L1-L17)

## Detailed Component Analysis

### Mapping Between DTOs and Domain Models
- User
  - Domain: uid, email, displayName, avatarUrl?, bio?, faculty?, graduationYear?, role, followerCount, followingCount, createdAt.
  - DTO: uid, email, displayName, avatarUrl, bio, faculty, graduationYear, createdAt?, updatedAt?.
  - Notes: Defaults in domain align with DTO empties; role is absent in DTO and set to default in domain.

- Post
  - Domain: id, authorId, authorName, authorAvatarUrl?, content, mediaUrls, hashtags, likeCount, commentCount, isLikedByCurrentUser, visibility, createdAt, updatedAt.
  - DTO: id, authorId, content, mediaUrls, likeCount, commentCount, createdAt?, updatedAt?.
  - Notes: Author display fields are not persisted; populated at runtime from User.

- Comment
  - Domain: id, postId, authorId, authorName, authorAvatarUrl?, content, createdAt.
  - DTO: id, postId, authorId, content, createdAt?.
  - Notes: Author display fields are not persisted; populated at runtime from User.

- Event
  - Domain: id, title, description, location, imageUrl?, startTime, endTime, organizerId, attendeeCount, maxAttendees?, type, livestreamUrl?, isRegistered, createdAt.
  - DTO: id, title, description, location, organizerId, attendeeIds, startTime, endTime, imageUrl, createdAt?.
  - Notes: Attendee IDs are normalized; derived counts computed; type is not persisted as enum in DTO.

- Heritage
  - Domain: id, title, content, mediaUrls, category, year, tags, createdAt.
  - DTO: id, title, content, category, year, imageUrl, tags, createdAt?.
  - Notes: Category stored as string in DTO; mapped to enum in domain.

- Notification
  - Domain: id, userId, title, body, type, referenceId?, isRead, createdAt.
  - DTO: id, userId, title, body, type, isRead, relatedId, createdAt?.
  - Notes: Type stored as string in DTO; mapped to enum in domain; relatedId maps to referenceId.

Best practices for mapping:
- Always populate denormalized display fields (authorName, authorAvatarUrl) from User when constructing domain models.
- Convert string enums to domain enums during mapping.
- Normalize collections (e.g., attendeeIds) to counts and flags in domain.
- Preserve server timestamps from DTOs for audit trails.

**Section sources**
- [User.kt:1-23](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt#L1-L23)
- [Post.kt:1-23](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Post.kt#L1-L23)
- [Comment.kt:1-12](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Comment.kt#L1-L12)
- [Event.kt:1-28](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Event.kt#L1-L28)
- [Heritage.kt:1-21](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Heritage.kt#L1-L21)
- [Notification.kt:1-22](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Notification.kt#L1-L22)
- [UserDto.kt:1-19](file://core/core-data/src/main/java/com/uit20years/core/data/dto/UserDto.kt#L1-L19)
- [PostDto.kt:1-18](file://core/core-data/src/main/java/com/uit20years/core/data/dto/PostDto.kt#L1-L18)
- [CommentDto.kt:1-14](file://core/core-data/src/main/java/com/uit20years/core/data/dto/CommentDto.kt#L1-L14)
- [EventDto.kt:1-19](file://core/core-data/src/main/java/com/uit20years/core/data/dto/EventDto.kt#L1-L19)
- [HeritageDto.kt:1-17](file://core/core-data/src/main/java/com/uit20years/core/data/dto/HeritageDto.kt#L1-L17)
- [NotificationDto.kt:1-17](file://core/core-data/src/main/java/com/uit20years/core/data/dto/NotificationDto.kt#L1-L17)

### Data Validation Flow
```mermaid
flowchart TD
Start(["Receive raw data"]) --> Parse["Parse DTO to Domain"]
Parse --> Validate["Validate Required Fields"]
Validate --> Valid{"Valid?"}
Valid --> |No| Reject["Reject with Error"]
Valid --> |Yes| Normalize["Normalize Enums and Collections"]
Normalize --> Enrich["Enrich with Derived Fields"]
Enrich --> Persist["Persist/Return Domain Model"]
Reject --> End(["End"])
Persist --> End
```

[No sources needed since this diagram shows conceptual workflow, not actual code structure]

Validation rules summary:
- Non-empty identifiers and content for posts/comments.
- Time boundaries: end time after start time for events.
- Numeric bounds: non-negative counts and years.
- Enum constraints: only allowed values for role, visibility, types.

**Section sources**
- [Post.kt:1-23](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Post.kt#L1-L23)
- [Event.kt:1-28](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Event.kt#L1-L28)
- [Heritage.kt:1-21](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Heritage.kt#L1-L21)

### Immutability and Serialization Patterns
- Immutability:
  - All models are data classes; treat instances as immutable.
  - Prefer copy(...) for transformations to maintain immutability.
- Serialization:
  - Use concise field sets for network transport.
  - Omit optional fields when null to reduce payload size.
  - For persistence, rely on DTOs carrying server timestamps.

**Section sources**
- [User.kt:1-23](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt#L1-L23)
- [Post.kt:1-23](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Post.kt#L1-L23)
- [Comment.kt:1-12](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Comment.kt#L1-L12)
- [Event.kt:1-28](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Event.kt#L1-L28)
- [Heritage.kt:1-21](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Heritage.kt#L1-L21)
- [Notification.kt:1-22](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Notification.kt#L1-L22)
- [Reaction.kt:1-14](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Reaction.kt#L1-L14)

### Extending and Modifying Models
Guidelines:
- Add new fields as optional with sensible defaults to preserve backward compatibility.
- Introduce enums for constrained values; map string enums from DTOs to domain enums.
- Keep domain models free of persistence annotations; place them in DTOs.
- When adding relationships, prefer IDs and enrich at runtime from repositories/services.
- Update mapping logic consistently in both directions (DTO-to-domain and domain-to-DTO).

**Section sources**
- [User.kt:1-23](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt#L1-L23)
- [Post.kt:1-23](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Post.kt#L1-L23)
- [Comment.kt:1-12](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Comment.kt#L1-L12)
- [Event.kt:1-28](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Event.kt#L1-L28)
- [Heritage.kt:1-21](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Heritage.kt#L1-L21)
- [Notification.kt:1-22](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Notification.kt#L1-L22)
- [Reaction.kt:1-14](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Reaction.kt#L1-L14)

## Dependency Analysis
- Cohesion: Each model encapsulates a single responsibility and is self-contained.
- Coupling: Models are loosely coupled; relationships are expressed via IDs and enrichment.
- External dependencies: DTOs depend on Firestore annotations; domain models remain annotation-free.
- Persistence boundary: core-data handles DTOs and server timestamps; core-model remains pure domain.

```mermaid
graph TB
subgraph "core-model"
M1["User"]
M2["Post"]
M3["Comment"]
M4["Event"]
M5["Heritage"]
M6["Notification"]
M7["Reaction"]
end
subgraph "core-data"
D1["UserDto"]
D2["PostDto"]
D3["CommentDto"]
D4["EventDto"]
D5["HeritageDto"]
D6["NotificationDto"]
end
M1 -.-> D1
M2 -.-> D2
M3 -.-> D3
M4 -.-> D4
M5 -.-> D5
M6 -.-> D6
```

**Diagram sources**
- [User.kt:1-23](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt#L1-L23)
- [Post.kt:1-23](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Post.kt#L1-L23)
- [Comment.kt:1-12](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Comment.kt#L1-L12)
- [Event.kt:1-28](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Event.kt#L1-L28)
- [Heritage.kt:1-21](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Heritage.kt#L1-L21)
- [Notification.kt:1-22](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Notification.kt#L1-L22)
- [UserDto.kt:1-19](file://core/core-data/src/main/java/com/uit20years/core/data/dto/UserDto.kt#L1-L19)
- [PostDto.kt:1-18](file://core/core-data/src/main/java/com/uit20years/core/data/dto/PostDto.kt#L1-L18)
- [CommentDto.kt:1-14](file://core/core-data/src/main/java/com/uit20years/core/data/dto/CommentDto.kt#L1-L14)
- [EventDto.kt:1-19](file://core/core-data/src/main/java/com/uit20years/core/data/dto/EventDto.kt#L1-L19)
- [HeritageDto.kt:1-17](file://core/core-data/src/main/java/com/uit20years/core/data/dto/HeritageDto.kt#L1-L17)
- [NotificationDto.kt:1-17](file://core/core-data/src/main/java/com/uit20years/core/data/dto/NotificationDto.kt#L1-L17)

**Section sources**
- [User.kt:1-23](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt#L1-L23)
- [Post.kt:1-23](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Post.kt#L1-L23)
- [Comment.kt:1-12](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Comment.kt#L1-L12)
- [Event.kt:1-28](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Event.kt#L1-L28)
- [Heritage.kt:1-21](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Heritage.kt#L1-L21)
- [Notification.kt:1-22](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Notification.kt#L1-L22)
- [UserDto.kt:1-19](file://core/core-data/src/main/java/com/uit20years/core/data/dto/UserDto.kt#L1-L19)
- [PostDto.kt:1-18](file://core/core-data/src/main/java/com/uit20years/core/data/dto/PostDto.kt#L1-L18)
- [CommentDto.kt:1-14](file://core/core-data/src/main/java/com/uit20years/core/data/dto/CommentDto.kt#L1-L14)
- [EventDto.kt:1-19](file://core/core-data/src/main/java/com/uit20years/core/data/dto/EventDto.kt#L1-L19)
- [HeritageDto.kt:1-17](file://core/core-data/src/main/java/com/uit20years/core/data/dto/HeritageDto.kt#L1-L17)
- [NotificationDto.kt:1-17](file://core/core-data/src/main/java/com/uit20years/core/data/dto/NotificationDto.kt#L1-L17)

## Performance Considerations
- Prefer lazy loading of enriched fields (e.g., author avatars) to minimize payload sizes.
- Use compact enumerations and booleans to reduce bandwidth.
- Cache frequently accessed domain models in memory to avoid repeated mapping.
- Batch reads/writes to Firestore to minimize round trips; map in bulk to reduce overhead.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and resolutions:
- Null pointer exceptions on optional fields:
  - Guard against nulls when accessing optional avatar/bio/faculty fields; use safe defaults.
- Enum mismatch between DTO and domain:
  - Validate string enums before mapping; provide fallbacks for unknown values.
- Incorrect counts or flags:
  - Recalculate derived fields (e.g., attendeeCount, isRegistered) after updates.
- Timestamp inconsistencies:
  - Use server timestamps from DTOs for audit trails; convert to local epoch for domain.

**Section sources**
- [User.kt:1-23](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt#L1-L23)
- [Post.kt:1-23](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Post.kt#L1-L23)
- [Comment.kt:1-12](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Comment.kt#L1-L12)
- [Event.kt:1-28](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Event.kt#L1-L28)
- [Heritage.kt:1-21](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Heritage.kt#L1-L21)
- [Notification.kt:1-22](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Notification.kt#L1-L22)
- [UserDto.kt:1-19](file://core/core-data/src/main/java/com/uit20years/core/data/dto/UserDto.kt#L1-L19)
- [PostDto.kt:1-18](file://core/core-data/src/main/java/com/uit20years/core/data/dto/PostDto.kt#L1-L18)
- [CommentDto.kt:1-14](file://core/core-data/src/main/java/com/uit20years/core/data/dto/CommentDto.kt#L1-L14)
- [EventDto.kt:1-19](file://core/core-data/src/main/java/com/uit20years/core/data/dto/EventDto.kt#L1-L19)
- [HeritageDto.kt:1-17](file://core/core-data/src/main/java/com/uit20years/core/data/dto/HeritageDto.kt#L1-L17)
- [NotificationDto.kt:1-17](file://core/core-data/src/main/java/com/uit20years/core/data/dto/NotificationDto.kt#L1-L17)

## Conclusion
The core-model module provides a clean, immutable foundation for the UIT20Years application. By separating domain semantics from persistence concerns and enforcing validation and immutability, it enables scalable development, predictable behavior, and easy evolution. Following the mapping guidelines and best practices outlined here will help maintain data consistency and support the overall architecture.
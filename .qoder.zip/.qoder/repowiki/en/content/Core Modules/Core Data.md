# Core Data

<cite>
**Referenced Files in This Document**
- [DataModule.kt](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt)
- [CommentDto.kt](file://core/core-data/src/main/java/com/uit20years/core/data/dto/CommentDto.kt)
- [EventDto.kt](file://core/core-data/src/main/java/com/uit20years/core/data/dto/EventDto.kt)
- [HeritageDto.kt](file://core/core-data/src/main/java/com/uit20years/core/data/dto/HeritageDto.kt)
- [NotificationDto.kt](file://core/core-data/src/main/java/com/uit20years/core/data/dto/NotificationDto.kt)
- [PostDto.kt](file://core/core-data/src/main/java/com/uit20years/core/data/dto/PostDto.kt)
- [UserDto.kt](file://core/core-data/src/main/java/com/uit20years/core/data/dto/UserDto.kt)
- [EventMapper.kt](file://core/core-data/src/main/java/com/uit20years/core/data/mapper/EventMapper.kt)
- [PostMapper.kt](file://core/core-data/src/main/java/com/uit20years/core/data/mapper/PostMapper.kt)
- [UserMapper.kt](file://core/core-data/src/main/java/com/uit20years/core/data/mapper/UserMapper.kt)
- [AuthRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt)
- [EventRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/EventRepositoryImpl.kt)
- [PostRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/PostRepositoryImpl.kt)
- [UserRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/UserRepositoryImpl.kt)
- [HeritageRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/HeritageRepositoryImpl.kt)
- [NotificationRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/NotificationRepositoryImpl.kt)
- [AppConstants.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/constants/AppConstants.kt)
- [FirestorePaths.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/constants/FirestorePaths.kt)
- [UitResult.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt)
- [FirebaseAuthService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt)
- [FirestoreService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt)
- [Event.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Event.kt)
- [Post.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Post.kt)
- [User.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt)
- [Comment.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Comment.kt)
- [Heritage.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Heritage.kt)
- [Notification.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Notification.kt)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document describes the core-data module responsible for data access and persistence in the UIT20Years application. It focuses on:
- DTOs for domain entities and their role in Firestore communication
- Mapper implementations converting between DTOs and domain models
- Repository implementations providing concrete data access logic using Firebase services
- Dependency injection configuration and module setup
- Examples of CRUD operations, data transformation patterns, error handling strategies
- Integration with Firebase services and considerations for caching and offline support

## Project Structure
The core-data module organizes data-layer concerns into cohesive packages:
- dto: Firestore-bound data transfer objects annotated for server timestamps
- mapper: Extension functions mapping DTOs to domain models and vice versa
- repository: Repository implementations for each domain feature
- di: Hilt bindings that wire repositories to their domain interfaces

```mermaid
graph TB
subgraph "core-data"
DTOs["DTOs<br/>CommentDto, EventDto, HeritageDto, NotificationDto, PostDto, UserDto"]
Mappers["Mappers<br/>EventMapper, PostMapper, UserMapper"]
Repos["Repositories<br/>AuthRepositoryImpl, EventRepositoryImpl,<br/>PostRepositoryImpl, UserRepositoryImpl,<br/>HeritageRepositoryImpl, NotificationRepositoryImpl"]
DI["DI Module<br/>DataModule"]
end
subgraph "core-common"
Paths["FirestorePaths"]
Result["UitResult"]
end
subgraph "core-firebase"
FBA["FirebaseAuthService"]
FBS["FirestoreService"]
end
subgraph "core-model"
Models["Domain Models<br/>Event, Post, User, Comment, Heritage, Notification"]
end
DTOs --> Mappers
Mappers --> Repos
DI --> Repos
Repos --> FBA
Repos --> FBS
Repos --> Paths
Repos --> Result
Mappers --> Models
```

**Diagram sources**
- [DataModule.kt:1-42](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt#L1-L42)
- [CommentDto.kt:1-14](file://core/core-data/src/main/java/com/uit20years/core/data/dto/CommentDto.kt#L1-L14)
- [EventDto.kt:1-19](file://core/core-data/src/main/java/com/uit20years/core/data/dto/EventDto.kt#L1-L19)
- [HeritageDto.kt:1-17](file://core/core-data/src/main/java/com/uit20years/core/data/dto/HeritageDto.kt#L1-L17)
- [NotificationDto.kt:1-17](file://core/core-data/src/main/java/com/uit20years/core/data/dto/NotificationDto.kt#L1-L17)
- [PostDto.kt:1-18](file://core/core-data/src/main/java/com/uit20years/core/data/dto/PostDto.kt#L1-L18)
- [UserDto.kt:1-19](file://core/core-data/src/main/java/com/uit20years/core/data/dto/UserDto.kt#L1-L19)
- [EventMapper.kt:1-33](file://core/core-data/src/main/java/com/uit20years/core/data/mapper/EventMapper.kt#L1-L33)
- [PostMapper.kt:1-27](file://core/core-data/src/main/java/com/uit20years/core/data/mapper/PostMapper.kt#L1-L27)
- [UserMapper.kt:1-29](file://core/core-data/src/main/java/com/uit20years/core/data/mapper/UserMapper.kt#L1-L29)
- [AuthRepositoryImpl.kt:1-147](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L1-L147)
- [EventRepositoryImpl.kt:1-38](file://core/core-data/src/main/java/com/uit20years/core/data/repository/EventRepositoryImpl.kt#L1-L38)
- [PostRepositoryImpl.kt:1-48](file://core/core-data/src/main/java/com/uit20years/core/data/repository/PostRepositoryImpl.kt#L1-L48)
- [UserRepositoryImpl.kt:1-97](file://core/core-data/src/main/java/com/uit20years/core/data/repository/UserRepositoryImpl.kt#L1-L97)
- [HeritageRepositoryImpl.kt:1-32](file://core/core-data/src/main/java/com/uit20years/core/data/repository/HeritageRepositoryImpl.kt#L1-L32)
- [NotificationRepositoryImpl.kt:1-32](file://core/core-data/src/main/java/com/uit20years/core/data/repository/NotificationRepositoryImpl.kt#L1-L32)
- [FirestorePaths.kt:1-200](file://core/core-common/src/main/kotlin/com/uit20years/core/common/constants/FirestorePaths.kt#L1-L200)
- [UitResult.kt:1-200](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L1-L200)
- [FirebaseAuthService.kt:1-200](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L1-L200)
- [FirestoreService.kt:1-200](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt#L1-L200)
- [Event.kt:1-28](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Event.kt#L1-L28)
- [Post.kt:1-23](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Post.kt#L1-L23)
- [User.kt:1-23](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt#L1-L23)
- [Comment.kt:1-12](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Comment.kt#L1-L12)
- [Heritage.kt:1-21](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Heritage.kt#L1-L21)
- [Notification.kt:1-22](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Notification.kt#L1-L22)

**Section sources**
- [DataModule.kt:1-42](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt#L1-L42)

## Core Components
This section documents the primary building blocks of the core-data module.

- DTOs
  - CommentDto: Represents comments with identifiers, post association, author, and server-stamped creation timestamp.
  - EventDto: Represents events with metadata, scheduling, attendees, and server-stamped creation timestamp.
  - HeritageDto: Represents heritage items with categorization, year, tags, and server-stamped creation timestamp.
  - NotificationDto: Represents notifications with user association, read state, related identifiers, and server-stamped timestamps.
  - PostDto: Represents posts with authorship, media, counts, and server-stamped creation/update timestamps.
  - UserDto: Represents user profiles with personal attributes and server-stamped creation/update timestamps.

- Mappers
  - EventMapper: Converts EventDto to Event and vice versa.
  - PostMapper: Converts PostDto to Post and vice versa.
  - UserMapper: Converts UserDto to User and vice versa.

- Repositories
  - AuthRepositoryImpl: Implements authentication, registration, logout, and current user retrieval using FirebaseAuthService and FirestoreService.
  - UserRepositoryImpl: Implements user retrieval and profile updates using FirestoreService.
  - EventRepositoryImpl: Placeholder implementations for event listing, fetching, and registration/unregistration.
  - PostRepositoryImpl: Placeholder implementations for post listing, creation, likes, and deletion.
  - HeritageRepositoryImpl: Placeholder implementations for heritage listing, search, and item retrieval.
  - NotificationRepositoryImpl: Placeholder implementations for notification listing, marking as read, and deletion.

- Dependency Injection
  - DataModule binds each repository implementation to its domain interface at the SingletonComponent scope.

**Section sources**
- [CommentDto.kt:1-14](file://core/core-data/src/main/java/com/uit20years/core/data/dto/CommentDto.kt#L1-L14)
- [EventDto.kt:1-19](file://core/core-data/src/main/java/com/uit20years/core/data/dto/EventDto.kt#L1-L19)
- [HeritageDto.kt:1-17](file://core/core-data/src/main/java/com/uit20years/core/data/dto/HeritageDto.kt#L1-L17)
- [NotificationDto.kt:1-17](file://core/core-data/src/main/java/com/uit20years/core/data/dto/NotificationDto.kt#L1-L17)
- [PostDto.kt:1-18](file://core/core-data/src/main/java/com/uit20years/core/data/dto/PostDto.kt#L1-L18)
- [UserDto.kt:1-19](file://core/core-data/src/main/java/com/uit20years/core/data/dto/UserDto.kt#L1-L19)
- [EventMapper.kt:1-33](file://core/core-data/src/main/java/com/uit20years/core/data/mapper/EventMapper.kt#L1-L33)
- [PostMapper.kt:1-27](file://core/core-data/src/main/java/com/uit20years/core/data/mapper/PostMapper.kt#L1-L27)
- [UserMapper.kt:1-29](file://core/core-data/src/main/java/com/uit20years/core/data/mapper/UserMapper.kt#L1-L29)
- [AuthRepositoryImpl.kt:1-147](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L1-L147)
- [UserRepositoryImpl.kt:1-97](file://core/core-data/src/main/java/com/uit20years/core/data/repository/UserRepositoryImpl.kt#L1-L97)
- [EventRepositoryImpl.kt:1-38](file://core/core-data/src/main/java/com/uit20years/core/data/repository/EventRepositoryImpl.kt#L1-L38)
- [PostRepositoryImpl.kt:1-48](file://core/core-data/src/main/java/com/uit20years/core/data/repository/PostRepositoryImpl.kt#L1-L48)
- [HeritageRepositoryImpl.kt:1-32](file://core/core-data/src/main/java/com/uit20years/core/data/repository/HeritageRepositoryImpl.kt#L1-L32)
- [NotificationRepositoryImpl.kt:1-32](file://core/core-data/src/main/java/com/uit20years/core/data/repository/NotificationRepositoryImpl.kt#L1-L32)
- [DataModule.kt:1-42](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt#L1-L42)

## Architecture Overview
The core-data module follows a layered architecture:
- Domain models define the application’s business entities.
- DTOs encapsulate Firestore-compatible structures with server timestamps.
- Mappers translate between DTOs and domain models.
- Repositories implement use-case-specific data access using Firebase services.
- DI module binds implementations to interfaces for dependency injection.

```mermaid
graph TB
subgraph "Domain Layer"
DM_User["User"]
DM_Post["Post"]
DM_Event["Event"]
DM_Heritage["Heritage"]
DM_Notification["Notification"]
DM_Comment["Comment"]
end
subgraph "Data Layer"
DTO_User["UserDto"]
DTO_Post["PostDto"]
DTO_Event["EventDto"]
DTO_Heritage["HeritageDto"]
DTO_Notification["NotificationDto"]
DTO_Comment["CommentDto"]
Mapper_User["UserMapper"]
Mapper_Post["PostMapper"]
Mapper_Event["EventMapper"]
Repo_Auth["AuthRepositoryImpl"]
Repo_User["UserRepositoryImpl"]
Repo_Post["PostRepositoryImpl"]
Repo_Event["EventRepositoryImpl"]
Repo_Heritage["HeritageRepositoryImpl"]
Repo_Notif["NotificationRepositoryImpl"]
end
subgraph "Infrastructure"
FB_Auth["FirebaseAuthService"]
FB_Store["FirestoreService"]
Const_Paths["FirestorePaths"]
Result["UitResult"]
end
DM_User <- --> DTO_User
DM_Post <- --> DTO_Post
DM_Event <- --> DTO_Event
DM_Heritage <- --> DTO_Heritage
DM_Notification <- --> DTO_Notification
DM_Comment <- --> DTO_Comment
Mapper_User --> Repo_User
Mapper_Post --> Repo_Post
Mapper_Event --> Repo_Event
Repo_Auth --> FB_Auth
Repo_User --> FB_Store
Repo_Post --> FB_Store
Repo_Event --> FB_Store
Repo_Heritage --> FB_Store
Repo_Notif --> FB_Store
Repo_Auth --> Const_Paths
Repo_User --> Const_Paths
Repo_Post --> Const_Paths
Repo_Event --> Const_Paths
Repo_Heritage --> Const_Paths
Repo_Notif --> Const_Paths
Repo_Auth --> Result
Repo_User --> Result
Repo_Post --> Result
Repo_Event --> Result
Repo_Heritage --> Result
Repo_Notif --> Result
```

**Diagram sources**
- [User.kt:1-23](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt#L1-L23)
- [Post.kt:1-23](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Post.kt#L1-L23)
- [Event.kt:1-28](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Event.kt#L1-L28)
- [Heritage.kt:1-21](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Heritage.kt#L1-L21)
- [Notification.kt:1-22](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Notification.kt#L1-L22)
- [Comment.kt:1-12](file://core/core-model/src/main/kotlin/com/uit20years/core/model/Comment.kt#L1-L12)
- [UserDto.kt:1-19](file://core/core-data/src/main/java/com/uit20years/core/data/dto/UserDto.kt#L1-L19)
- [PostDto.kt:1-18](file://core/core-data/src/main/java/com/uit20years/core/data/dto/PostDto.kt#L1-L18)
- [EventDto.kt:1-19](file://core/core-data/src/main/java/com/uit20years/core/data/dto/EventDto.kt#L1-L19)
- [HeritageDto.kt:1-17](file://core/core-data/src/main/java/com/uit20years/core/data/dto/HeritageDto.kt#L1-L17)
- [NotificationDto.kt:1-17](file://core/core-data/src/main/java/com/uit20years/core/data/dto/NotificationDto.kt#L1-L17)
- [CommentDto.kt:1-14](file://core/core-data/src/main/java/com/uit20years/core/data/dto/CommentDto.kt#L1-L14)
- [UserMapper.kt:1-29](file://core/core-data/src/main/java/com/uit20years/core/data/mapper/UserMapper.kt#L1-L29)
- [PostMapper.kt:1-27](file://core/core-data/src/main/java/com/uit20years/core/data/mapper/PostMapper.kt#L1-L27)
- [EventMapper.kt:1-33](file://core/core-data/src/main/java/com/uit20years/core/data/mapper/EventMapper.kt#L1-L33)
- [AuthRepositoryImpl.kt:1-147](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L1-L147)
- [UserRepositoryImpl.kt:1-97](file://core/core-data/src/main/java/com/uit20years/core/data/repository/UserRepositoryImpl.kt#L1-L97)
- [PostRepositoryImpl.kt:1-48](file://core/core-data/src/main/java/com/uit20years/core/data/repository/PostRepositoryImpl.kt#L1-L48)
- [EventRepositoryImpl.kt:1-38](file://core/core-data/src/main/java/com/uit20years/core/data/repository/EventRepositoryImpl.kt#L1-L38)
- [HeritageRepositoryImpl.kt:1-32](file://core/core-data/src/main/java/com/uit20years/core/data/repository/HeritageRepositoryImpl.kt#L1-L32)
- [NotificationRepositoryImpl.kt:1-32](file://core/core-data/src/main/java/com/uit20years/core/data/repository/NotificationRepositoryImpl.kt#L1-L32)
- [FirebaseAuthService.kt:1-200](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L1-L200)
- [FirestoreService.kt:1-200](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt#L1-L200)
- [FirestorePaths.kt:1-200](file://core/core-common/src/main/kotlin/com/uit20years/core/common/constants/FirestorePaths.kt#L1-L200)
- [UitResult.kt:1-200](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L1-L200)

## Detailed Component Analysis

### DTOs and Firestore Communication
- Purpose: DTOs represent Firestore documents with typed fields and server-stamped timestamps. They decouple domain models from Firestore specifics.
- Timestamps: ServerTimestamp annotations ensure createdAt/updatedAt are set by Firestore server time.
- Example roles:
  - UserDto aligns with the USERS collection path.
  - PostDto aligns with the POSTS collection path.
  - EventDto aligns with the EVENTS collection path.
  - HeritageDto aligns with the HERITAGE collection path.
  - NotificationDto aligns with the NOTIFICATIONS collection path.
  - CommentDto aligns with the COMMENTS collection path.

**Section sources**
- [UserDto.kt:1-19](file://core/core-data/src/main/java/com/uit20years/core/data/dto/UserDto.kt#L1-L19)
- [PostDto.kt:1-18](file://core/core-data/src/main/java/com/uit20years/core/data/dto/PostDto.kt#L1-L18)
- [EventDto.kt:1-19](file://core/core-data/src/main/java/com/uit20years/core/data/dto/EventDto.kt#L1-L19)
- [HeritageDto.kt:1-17](file://core/core-data/src/main/java/com/uit20years/core/data/dto/HeritageDto.kt#L1-L17)
- [NotificationDto.kt:1-17](file://core/core-data/src/main/java/com/uit20years/core/data/dto/NotificationDto.kt#L1-L17)
- [CommentDto.kt:1-14](file://core/core-data/src/main/java/com/uit20years/core/data/dto/CommentDto.kt#L1-L14)
- [FirestorePaths.kt:1-200](file://core/core-common/src/main/kotlin/com/uit20years/core/common/constants/FirestorePaths.kt#L1-L200)

### Mappers: DTO-to-Domain and Domain-to-DTO
- Mapping strategy: Extension functions transform DTOs to domain models and vice versa. They preserve essential fields while adapting to domain model shapes.
- Examples:
  - EventMapper: Converts EventDto to Event and PostDto to Post.
  - PostMapper: Converts PostDto to Post and UserDto to User via UserMapper.
  - UserMapper: Converts UserDto to User and vice versa.

```mermaid
classDiagram
class UserDto {
+string uid
+string email
+string displayName
+string avatarUrl
+string bio
+string faculty
+int graduationYear
}
class User {
+string uid
+string email
+string displayName
+string avatarUrl
+string bio
+string faculty
+int graduationYear
}
class UserMapper {
+toDomain() User
+toDto() UserDto
}
UserDto <.. UserMapper : "maps"
User <.. UserMapper : "maps"
```

**Diagram sources**
- [UserDto.kt:1-19](file://core/core-data/src/main/java/com/uit20years/core/data/dto/UserDto.kt#L1-L19)
- [User.kt:1-23](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt#L1-L23)
- [UserMapper.kt:1-29](file://core/core-data/src/main/java/com/uit20years/core/data/mapper/UserMapper.kt#L1-L29)

**Section sources**
- [EventMapper.kt:1-33](file://core/core-data/src/main/java/com/uit20years/core/data/mapper/EventMapper.kt#L1-L33)
- [PostMapper.kt:1-27](file://core/core-data/src/main/java/com/uit20years/core/data/mapper/PostMapper.kt#L1-L27)
- [UserMapper.kt:1-29](file://core/core-data/src/main/java/com/uit20years/core/data/mapper/UserMapper.kt#L1-L29)

### Authentication Repository Implementation
AuthRepositoryImpl integrates FirebaseAuthService and FirestoreService to:
- Login: Authenticate via email/password, fetch user document, and map to domain User.
- Register: Create user account, construct UserDto, write to Firestore, and return mapped User.
- Logout: Sign out and return success.
- Observe auth state: Stream Firebase user and resolve profile.
- Get current user: Synchronously resolve current user profile.

```mermaid
sequenceDiagram
participant VM as "ViewModel"
participant AR as "AuthRepositoryImpl"
participant FA as "FirebaseAuthService"
participant FS as "FirestoreService"
VM->>AR : login(email, password)
AR->>FA : signInWithEmail(email, password)
FA-->>AR : AuthResult
AR->>FS : getDocument(USERS, uid)
FS-->>AR : DocumentSnapshot
AR->>AR : map to UserDto then to User
AR-->>VM : UitResult.Success(User)
VM->>AR : register(email, password, displayName)
AR->>FA : createUser(email, password)
FA-->>AR : AuthResult
AR->>FS : setDocument(USERS, uid, userDto.toMap(), merge=true)
AR-->>VM : UitResult.Success(User)
```

**Diagram sources**
- [AuthRepositoryImpl.kt:29-88](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L29-L88)
- [FirebaseAuthService.kt:1-200](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L1-L200)
- [FirestoreService.kt:1-200](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt#L1-L200)
- [FirestorePaths.kt:1-200](file://core/core-common/src/main/kotlin/com/uit20years/core/common/constants/FirestorePaths.kt#L1-L200)
- [UitResult.kt:1-200](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L1-L200)

**Section sources**
- [AuthRepositoryImpl.kt:29-133](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L29-L133)

### User Repository Implementation
UserRepositoryImpl provides:
- getUser: Retrieve a user by uid from Firestore and map to domain User.
- updateProfile: Merge updates to the user document using UserDto.toMap().
- Follow/unfollow/getFollowers/getFollowing: Placeholders for future implementation.

```mermaid
flowchart TD
Start(["getUser(uid)"]) --> EmitLoading["Emit Loading"]
EmitLoading --> FetchDoc["FirestoreService.getDocument(USERS, uid)"]
FetchDoc --> Exists{"Document exists?"}
Exists --> |Yes| ToDto["Convert to UserDto"]
ToDto --> ToDomain["Map to User"]
ToDomain --> EmitSuccess["Emit Success(User)"]
Exists --> |No| EmitErrorNotFound["Emit Error('User not found')"]
EmitSuccess --> End(["Done"])
EmitErrorNotFound --> End
```

**Diagram sources**
- [UserRepositoryImpl.kt:22-35](file://core/core-data/src/main/java/com/uit20years/core/data/repository/UserRepositoryImpl.kt#L22-L35)
- [FirestoreService.kt:1-200](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt#L1-L200)
- [FirestorePaths.kt:1-200](file://core/core-common/src/main/kotlin/com/uit20years/core/common/constants/FirestorePaths.kt#L1-L200)
- [UitResult.kt:1-200](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L1-L200)

**Section sources**
- [UserRepositoryImpl.kt:22-97](file://core/core-data/src/main/java/com/uit20years/core/data/repository/UserRepositoryImpl.kt#L22-L97)

### Post Repository Implementation
PostRepositoryImpl provides placeholders for:
- Listing posts with a limit
- Creating posts with author, content, and media URLs
- Liking/unliking posts
- Deleting posts

These methods emit Loading initially and are intended to integrate with FirestoreService in future iterations.

**Section sources**
- [PostRepositoryImpl.kt:14-47](file://core/core-data/src/main/java/com/uit20years/core/data/repository/PostRepositoryImpl.kt#L14-L47)

### Event Repository Implementation
EventRepositoryImpl provides placeholders for:
- Listing events with a limit
- Retrieving a single event by ID
- Registering/unregistering for events

**Section sources**
- [EventRepositoryImpl.kt:14-37](file://core/core-data/src/main/java/com/uit20years/core/data/repository/EventRepositoryImpl.kt#L14-L37)

### Heritage Repository Implementation
HeritageRepositoryImpl provides placeholders for:
- Listing heritage items with a limit
- Searching heritage by query
- Retrieving a single heritage item by ID

**Section sources**
- [HeritageRepositoryImpl.kt:14-31](file://core/core-data/src/main/java/com/uit20years/core/data/repository/HeritageRepositoryImpl.kt#L14-L31)

### Notification Repository Implementation
NotificationRepositoryImpl provides placeholders for:
- Listing notifications for a user with a limit
- Marking a notification as read
- Deleting a notification

**Section sources**
- [NotificationRepositoryImpl.kt:14-31](file://core/core-data/src/main/java/com/uit20years/core/data/repository/NotificationRepositoryImpl.kt#L14-L31)

### Dependency Injection Configuration
DataModule binds each repository implementation to its domain interface at the SingletonComponent scope, enabling Hilt to inject the appropriate implementation wherever the domain interface is requested.

```mermaid
graph LR
DM["DataModule"]
AR["AuthRepositoryImpl"]
UR["UserRepositoryImpl"]
PR["PostRepositoryImpl"]
ER["EventRepositoryImpl"]
HR["HeritageRepositoryImpl"]
NR["NotificationRepositoryImpl"]
ARepo["AuthRepository"]
URepo["UserRepository"]
PRepo["PostRepository"]
ERepo["EventRepository"]
HRepo["HeritageRepository"]
NRepo["NotificationRepository"]
DM --> AR
DM --> UR
DM --> PR
DM --> ER
DM --> HR
DM --> NR
AR --> ARepo
UR --> URepo
PR --> PRepo
ER --> ERepo
HR --> HRepo
NR --> NRepo
```

**Diagram sources**
- [DataModule.kt:24-41](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt#L24-L41)

**Section sources**
- [DataModule.kt:20-41](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt#L20-L41)

## Dependency Analysis
- Internal dependencies:
  - Repositories depend on FirestoreService and FirestorePaths for document operations.
  - AuthRepositoryImpl additionally depends on FirebaseAuthService for authentication.
  - Mappers depend on DTOs and domain models for conversion.
- External dependencies:
  - Firebase services for authentication and Firestore operations.
  - Hilt for dependency injection wiring.

```mermaid
graph TB
AR["AuthRepositoryImpl"] --> FBA["FirebaseAuthService"]
AR --> FBS["FirestoreService"]
UR["UserRepositoryImpl"] --> FBS
PR["PostRepositoryImpl"] --> FBS
ER["EventRepositoryImpl"] --> FBS
HR["HeritageRepositoryImpl"] --> FBS
NR["NotificationRepositoryImpl"] --> FBS
AR --> FP["FirestorePaths"]
UR --> FP
PR --> FP
ER --> FP
HR --> FP
NR --> FP
AR --> R["UitResult"]
UR --> R
PR --> R
ER --> R
HR --> R
NR --> R
```

**Diagram sources**
- [AuthRepositoryImpl.kt:12-27](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L12-L27)
- [UserRepositoryImpl.kt:18-20](file://core/core-data/src/main/java/com/uit20years/core/data/repository/UserRepositoryImpl.kt#L18-L20)
- [PostRepositoryImpl.kt:11-12](file://core/core-data/src/main/java/com/uit20years/core/data/repository/PostRepositoryImpl.kt#L11-L12)
- [EventRepositoryImpl.kt:11-12](file://core/core-data/src/main/java/com/uit20years/core/data/repository/EventRepositoryImpl.kt#L11-L12)
- [HeritageRepositoryImpl.kt:11-12](file://core/core-data/src/main/java/com/uit20years/core/data/repository/HeritageRepositoryImpl.kt#L11-L12)
- [NotificationRepositoryImpl.kt:11-12](file://core/core-data/src/main/java/com/uit20years/core/data/repository/NotificationRepositoryImpl.kt#L11-L12)
- [FirebaseAuthService.kt:1-200](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L1-L200)
- [FirestoreService.kt:1-200](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt#L1-L200)
- [FirestorePaths.kt:1-200](file://core/core-common/src/main/kotlin/com/uit20years/core/common/constants/FirestorePaths.kt#L1-L200)
- [UitResult.kt:1-200](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L1-L200)

**Section sources**
- [AuthRepositoryImpl.kt:12-27](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L12-L27)
- [UserRepositoryImpl.kt:18-20](file://core/core-data/src/main/java/com/uit20years/core/data/repository/UserRepositoryImpl.kt#L18-L20)
- [PostRepositoryImpl.kt:11-12](file://core/core-data/src/main/java/com/uit20years/core/data/repository/PostRepositoryImpl.kt#L11-L12)
- [EventRepositoryImpl.kt:11-12](file://core/core-data/src/main/java/com/uit20years/core/data/repository/EventRepositoryImpl.kt#L11-L12)
- [HeritageRepositoryImpl.kt:11-12](file://core/core-data/src/main/java/com/uit20years/core/data/repository/HeritageRepositoryImpl.kt#L11-L12)
- [NotificationRepositoryImpl.kt:11-12](file://core/core-data/src/main/java/com/uit20years/core/data/repository/NotificationRepositoryImpl.kt#L11-L12)

## Performance Considerations
- Minimize round trips: Batch reads/writes where possible using FirestoreService batch APIs.
- Use server timestamps: Leverage @ServerTimestamp to avoid client clock drift and reduce synchronization overhead.
- Limit field selection: Query only required fields to reduce payload sizes.
- Pagination: Implement cursor-based pagination for lists (posts, events, notifications).
- Offline persistence: Enable Firestore offline persistence to improve responsiveness and reliability.
- Caching: Cache frequently accessed entities (e.g., current user profile) in memory to reduce repeated reads.
- Concurrency: Use Flow streams judiciously; avoid excessive recomposition by collecting at appropriate scopes.

## Troubleshooting Guide
Common issues and strategies:
- Authentication errors:
  - Invalid credentials: Map FirebaseAuthInvalidCredentialsException to localized messages.
  - Account collision: Handle FirebaseAuthUserCollisionException during registration.
- Firestore connectivity:
  - Wrap exceptions from FirestoreService in UitResult.Error and surface user-friendly messages.
- Null or missing documents:
  - Validate document existence before mapping to DTOs; handle missing profiles gracefully.
- Unexpected errors:
  - Catch generic exceptions and emit UitResult.Error with localized messages.

**Section sources**
- [AuthRepositoryImpl.kt:48-54](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L48-L54)
- [AuthRepositoryImpl.kt:81-87](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L81-L87)
- [UserRepositoryImpl.kt:32-35](file://core/core-data/src/main/java/com/uit20years/core/data/repository/UserRepositoryImpl.kt#L32-L35)

## Conclusion
The core-data module establishes a clean separation between domain models and Firestore-backed DTOs, with mappers ensuring smooth transformations. Repositories encapsulate data access logic and integrate with Firebase services, while Hilt wiring ensures testable and maintainable dependency management. Placeholder implementations indicate future work for posts, events, heritage, and notifications, with authentication and user management already functional.

## Appendices
- Data Transformation Patterns:
  - DTO to Domain: Use mapper extension functions to convert Firestore snapshots to domain models.
  - Domain to DTO: Build DTOs from domain models for writes and merges.
- CRUD Examples:
  - Read: getUser(uid) retrieves a user document and maps to User.
  - Write: updateProfile merges UserDto fields into Firestore.
  - Auth: login and register orchestrate FirebaseAuthService and FirestoreService.
- Error Handling:
  - Emit UitResult.Loading, UitResult.Success, and UitResult.Error consistently across repositories.
  - Catch specific Firebase exceptions and map to user-friendly messages.
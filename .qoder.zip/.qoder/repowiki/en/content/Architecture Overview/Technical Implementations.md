# Technical Implementations

<cite>
**Referenced Files in This Document**
- [AndroidApplicationConventionPlugin.kt](file://build-logic/convention/src/main/kotlin/AndroidApplicationConventionPlugin.kt)
- [AndroidHiltConventionPlugin.kt](file://build-logic/convention/src/main/kotlin/AndroidHiltConventionPlugin.kt)
- [KotlinAndroid.kt](file://build-logic/convention/src/main/kotlin/KotlinAndroid.kt)
- [build.gradle.kts](file://build.gradle.kts)
- [settings.gradle.kts](file://settings.gradle.kts)
- [app/build.gradle.kts](file://app/build.gradle.kts)
- [DispatcherModule.kt](file://app/src/main/java/com/uit20years/app/di/DispatcherModule.kt)
- [Dispatchers.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/dispatcher/Dispatchers.kt)
- [DataModule.kt](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt)
- [FirebaseModule.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt)
- [MediaModule.kt](file://core/core-media/src/main/java/com/uit20years/core/media/di/MediaModule.kt)
- [Theme.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Theme.kt)
- [Color.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Color.kt)
- [Type.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Type.kt)
- [Shape.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Shape.kt)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the key technical implementations in UIT20Years, focusing on:
- Custom Gradle convention plugins that standardize build configuration across modules
- Dependency Injection with Hilt, including module definitions and service provisioning
- Coroutine dispatchers abstraction and threading management
- Material 3 theming system including color schemes, typography, and shapes
- Build logic ensuring consistency and simplified configuration management

## Project Structure
The project follows a modular Gradle setup with a dedicated build-logic convention plugin module. The app module applies convention plugins to unify Android and Kotlin configuration, while core modules encapsulate domain, data, platform integrations, and UI theming. Feature modules depend on core modules to deliver product features.

```mermaid
graph TB
subgraph "Root Build Scripts"
ROOT_GRADLE["build.gradle.kts"]
SETTINGS["settings.gradle.kts"]
end
subgraph "Build Logic"
CONV_APP["AndroidApplicationConventionPlugin.kt"]
CONV_HILT["AndroidHiltConventionPlugin.kt"]
KOTLIN_ANDROID["KotlinAndroid.kt"]
end
subgraph "App Module"
APP_GRADLE["app/build.gradle.kts"]
end
subgraph "Core Modules"
CORE_COMMON["core:core-common"]
CORE_MODEL["core:core-model"]
CORE_DOMAIN["core:core-domain"]
CORE_DATA["core:core-data"]
CORE_FIREBASE["core:core-firebase"]
CORE_SEARCH["core:core-search"]
CORE_MEDIA["core:core-media"]
CORE_UI["core:core-ui"]
end
subgraph "Feature Modules"
FEAT_AUTH["feature:feature-auth"]
FEAT_MOMENTS["feature:feature-moments"]
FEAT_EVENTS["feature:feature-events"]
FEAT_HERITAGE["feature:feature-heritage"]
FEAT_PROFILE["feature:feature-profile"]
FEAT_NOTIF["feature:feature-notifications"]
end
ROOT_GRADLE --> SETTINGS
SETTINGS --> CONV_APP
SETTINGS --> CONV_HILT
SETTINGS --> KOTLIN_ANDROID
APP_GRADLE --> CONV_APP
APP_GRADLE --> CONV_HILT
APP_GRADLE --> CORE_COMMON
APP_GRADLE --> CORE_MODEL
APP_GRADLE --> CORE_DOMAIN
APP_GRADLE --> CORE_DATA
APP_GRADLE --> CORE_FIREBASE
APP_GRADLE --> CORE_SEARCH
APP_GRADLE --> CORE_MEDIA
APP_GRADLE --> CORE_UI
APP_GRADLE --> FEAT_AUTH
APP_GRADLE --> FEAT_MOMENTS
APP_GRADLE --> FEAT_EVENTS
APP_GRADLE --> FEAT_HERITAGE
APP_GRADLE --> FEAT_PROFILE
APP_GRADLE --> FEAT_NOTIF
```

**Diagram sources**
- [settings.gradle.kts:1-39](file://settings.gradle.kts#L1-L39)
- [AndroidApplicationConventionPlugin.kt:1-20](file://build-logic/convention/src/main/kotlin/AndroidApplicationConventionPlugin.kt#L1-L20)
- [AndroidHiltConventionPlugin.kt:1-19](file://build-logic/convention/src/main/kotlin/AndroidHiltConventionPlugin.kt#L1-L19)
- [KotlinAndroid.kt:1-29](file://build-logic/convention/src/main/kotlin/KotlinAndroid.kt#L1-L29)
- [app/build.gradle.kts:1-82](file://app/build.gradle.kts#L1-L82)

**Section sources**
- [settings.gradle.kts:1-39](file://settings.gradle.kts#L1-L39)
- [build.gradle.kts:1-12](file://build.gradle.kts#L1-L12)

## Core Components
- Convention Plugins: Centralize Android and Hilt setup, plus shared Kotlin/Java toolchain configuration.
- DI Modules: Provide dispatchers, repositories, Firebase services, and media services via Hilt.
- Themed UI: Material 3 color schemes, typography, and shapes packaged under a single theme entry point.
- Coroutine Dispatchers: Qualifiers and providers to select appropriate dispatchers for IO, default, and main threads.

**Section sources**
- [AndroidApplicationConventionPlugin.kt:1-20](file://build-logic/convention/src/main/kotlin/AndroidApplicationConventionPlugin.kt#L1-L20)
- [AndroidHiltConventionPlugin.kt:1-19](file://build-logic/convention/src/main/kotlin/AndroidHiltConventionPlugin.kt#L1-L19)
- [KotlinAndroid.kt:1-29](file://build-logic/convention/src/main/kotlin/KotlinAndroid.kt#L1-L29)
- [DispatcherModule.kt:1-27](file://app/src/main/java/com/uit20years/app/di/DispatcherModule.kt#L1-L27)
- [Dispatchers.kt:1-16](file://core/core-common/src/main/kotlin/com/uit20years/core/common/dispatcher/Dispatchers.kt#L1-L16)
- [Theme.kt:1-83](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Theme.kt#L1-L83)
- [Color.kt:1-31](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Color.kt#L1-L31)
- [Type.kt:1-110](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Type.kt#L1-L110)
- [Shape.kt:1-14](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Shape.kt#L1-L14)

## Architecture Overview
The build-time architecture enforces consistency across modules using convention plugins applied by the app module. At runtime, Hilt provides a centralized DI graph that supplies dispatchers, repositories, and platform services. UI theming is standardized through Material 3 tokens and a unified theme wrapper.

```mermaid
graph TB
subgraph "Build-Time"
APP_GRADLE["app/build.gradle.kts"]
CONV_APP["AndroidApplicationConventionPlugin.kt"]
CONV_HILT["AndroidHiltConventionPlugin.kt"]
KOTLIN_ANDROID["KotlinAndroid.kt"]
end
subgraph "Runtime DI Graph"
DISPATCHERS_MOD["DispatcherModule.kt"]
DATA_MOD["DataModule.kt"]
FIREBASE_MOD["FirebaseModule.kt"]
MEDIA_MOD["MediaModule.kt"]
end
subgraph "UI Theming"
THEME["Theme.kt"]
COLOR["Color.kt"]
TYPE["Type.kt"]
SHAPE["Shape.kt"]
end
APP_GRADLE --> CONV_APP
APP_GRADLE --> CONV_HILT
CONV_APP --> KOTLIN_ANDROID
DISPATCHERS_MOD --> THEME
DATA_MOD --> THEME
FIREBASE_MOD --> THEME
MEDIA_MOD --> THEME
```

**Diagram sources**
- [app/build.gradle.kts:1-82](file://app/build.gradle.kts#L1-L82)
- [AndroidApplicationConventionPlugin.kt:1-20](file://build-logic/convention/src/main/kotlin/AndroidApplicationConventionPlugin.kt#L1-L20)
- [AndroidHiltConventionPlugin.kt:1-19](file://build-logic/convention/src/main/kotlin/AndroidHiltConventionPlugin.kt#L1-L19)
- [KotlinAndroid.kt:1-29](file://build-logic/convention/src/main/kotlin/KotlinAndroid.kt#L1-L29)
- [DispatcherModule.kt:1-27](file://app/src/main/java/com/uit20years/app/di/DispatcherModule.kt#L1-L27)
- [DataModule.kt:1-42](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt#L1-L42)
- [FirebaseModule.kt:1-28](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt#L1-L28)
- [MediaModule.kt:1-28](file://core/core-media/src/main/java/com/uit20years/core/media/di/MediaModule.kt#L1-L28)
- [Theme.kt:1-83](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Theme.kt#L1-L83)

## Detailed Component Analysis

### Gradle Convention Plugins
The convention plugins encapsulate Android application setup, Hilt and KSP wiring, and shared Kotlin/Java toolchain configuration. They are applied in the app module to ensure uniformity across all modules.

- AndroidApplicationConventionPlugin
  - Applies Android Application and Kotlin Android plugins
  - Configures Kotlin/Android options via a shared helper
  - Sets target SDK at the extension level

- AndroidHiltConventionPlugin
  - Applies Hilt and KSP plugins
  - Adds Hilt runtime and KSP compiler dependencies via the libs catalog

- KotlinAndroid (shared helper)
  - Sets compileSdk, minSdk, Java 17 compatibility, and Kotlin JVM target

Practical usage example (from app module):
- Apply convention plugins via alias entries in the app build script
- Remove per-module duplication of Android/Hilt/Kotlin configurations

**Section sources**
- [AndroidApplicationConventionPlugin.kt:1-20](file://build-logic/convention/src/main/kotlin/AndroidApplicationConventionPlugin.kt#L1-L20)
- [AndroidHiltConventionPlugin.kt:1-19](file://build-logic/convention/src/main/kotlin/AndroidHiltConventionPlugin.kt#L1-L19)
- [KotlinAndroid.kt:1-29](file://build-logic/convention/src/main/kotlin/KotlinAndroid.kt#L1-L29)
- [app/build.gradle.kts:1-82](file://app/build.gradle.kts#L1-L82)
- [build.gradle.kts:1-12](file://build.gradle.kts#L1-L12)

### Dependency Injection with Hilt
Hilt modules are installed in the Singleton component and provide:
- Dispatchers: IO and Default dispatchers annotated for injection
- Repositories: Binds implementations to domain interfaces
- Firebase services: FirebaseAuth, FirebaseFirestore, FirebaseStorage singletons
- Media services: ImageCompressor and MediaUploader with constructor injection

```mermaid
classDiagram
class DispatcherModule {
+providesIoDispatcher() CoroutineDispatcher
+providesDefaultDispatcher() CoroutineDispatcher
}
class DataModule {
+bindAuthRepository(AuthRepositoryImpl) AuthRepository
+bindUserRepository(UserRepositoryImpl) UserRepository
+bindPostRepository(PostRepositoryImpl) PostRepository
+bindEventRepository(EventRepositoryImpl) EventRepository
+bindHeritageRepository(HeritageRepositoryImpl) HeritageRepository
+bindNotificationRepository(NotificationRepositoryImpl) NotificationRepository
}
class FirebaseModule {
+provideFirebaseAuth() FirebaseAuth
+provideFirebaseFirestore() FirebaseFirestore
+provideFirebaseStorage() FirebaseStorage
}
class MediaModule {
+provideImageCompressor() ImageCompressor
+provideMediaUploader(ImageCompressor, FirebaseStorageService, Context) MediaUploader
}
DispatcherModule --> "injects" CoroutineDispatcher
DataModule --> "implements" DomainRepository
FirebaseModule --> "provides" PlatformServices
MediaModule --> "uses" ImageCompressor
MediaModule --> "uses" FirebaseStorageService
```

**Diagram sources**
- [DispatcherModule.kt:1-27](file://app/src/main/java/com/uit20years/app/di/DispatcherModule.kt#L1-L27)
- [DataModule.kt:1-42](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt#L1-L42)
- [FirebaseModule.kt:1-28](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt#L1-L28)
- [MediaModule.kt:1-28](file://core/core-media/src/main/java/com/uit20years/core/media/di/MediaModule.kt#L1-L28)

**Section sources**
- [DispatcherModule.kt:1-27](file://app/src/main/java/com/uit20years/app/di/DispatcherModule.kt#L1-L27)
- [DataModule.kt:1-42](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt#L1-L42)
- [FirebaseModule.kt:1-28](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt#L1-L28)
- [MediaModule.kt:1-28](file://core/core-media/src/main/java/com/uit20years/core/media/di/MediaModule.kt#L1-L28)

### Coroutine Dispatchers Abstraction
The dispatcher abstraction uses qualifiers to distinguish dispatchers and providers to supply them as singletons. This enables injecting the appropriate dispatcher for IO-bound or CPU-bound work.

```mermaid
classDiagram
class IoDispatcher
class DefaultDispatcher
class MainDispatcher
class DispatcherModule {
+providesIoDispatcher() CoroutineDispatcher
+providesDefaultDispatcher() CoroutineDispatcher
}
IoDispatcher <.. DispatcherModule : "qualifier for"
DefaultDispatcher <.. DispatcherModule : "qualifier for"
```

**Diagram sources**
- [Dispatchers.kt:1-16](file://core/core-common/src/main/kotlin/com/uit20years/core/common/dispatcher/Dispatchers.kt#L1-L16)
- [DispatcherModule.kt:1-27](file://app/src/main/java/com/uit20years/app/di/DispatcherModule.kt#L1-L27)

**Section sources**
- [Dispatchers.kt:1-16](file://core/core-common/src/main/kotlin/com/uit20years/core/common/dispatcher/Dispatchers.kt#L1-L16)
- [DispatcherModule.kt:1-27](file://app/src/main/java/com/uit20years/app/di/DispatcherModule.kt#L1-L27)

### Material 3 Theming System
The theming system defines brand colors, extended palettes, and status colors, then constructs light and dark color schemes. It exposes a single composable that sets status bar appearance and applies Material 3 typography and shapes.

```mermaid
flowchart TD
Start(["UIT20YearsTheme"]) --> Detect["Detect dark theme"]
Detect --> Choose{"Dark?"}
Choose --> |Yes| SchemeDark["Use DarkColorScheme"]
Choose --> |No| SchemeLight["Use LightColorScheme"]
SchemeDark --> ApplyTheme["Apply MaterialTheme<br/>colorScheme, typography, shapes"]
SchemeLight --> ApplyTheme
ApplyTheme --> StatusBar["Set status bar color and icon appearance"]
StatusBar --> Content["Render content"]
```

**Diagram sources**
- [Theme.kt:57-82](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Theme.kt#L57-L82)
- [Color.kt:1-31](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Color.kt#L1-L31)
- [Type.kt:1-110](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Type.kt#L1-L110)
- [Shape.kt:1-14](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Shape.kt#L1-L14)

**Section sources**
- [Theme.kt:1-83](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Theme.kt#L1-L83)
- [Color.kt:1-31](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Color.kt#L1-L31)
- [Type.kt:1-110](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Type.kt#L1-L110)
- [Shape.kt:1-14](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Shape.kt#L1-L14)

### Build Logic Consistency and Configuration Management
The root build script defers plugin application to avoid duplication. The settings script wires the build-logic include and registers all modules. The app module applies convention plugins and depends on core and feature modules, centralizing dependency declarations and build types.

```mermaid
sequenceDiagram
participant Settings as "settings.gradle.kts"
participant RootGradle as "build.gradle.kts"
participant AppGradle as "app/build.gradle.kts"
participant ConvApp as "AndroidApplicationConventionPlugin.kt"
participant ConvHilt as "AndroidHiltConventionPlugin.kt"
Settings->>Settings : includeBuild("build-logic")
Settings->>Settings : include(" : app")
Settings->>Settings : include core and feature modules
AppGradle->>ConvApp : apply convention plugin
AppGradle->>ConvHilt : apply convention plugin
ConvApp->>ConvApp : configureKotlinAndroid(...)
ConvHilt->>ConvHilt : add hilt and ksp deps
```

**Diagram sources**
- [settings.gradle.kts:1-39](file://settings.gradle.kts#L1-L39)
- [build.gradle.kts:1-12](file://build.gradle.kts#L1-L12)
- [AndroidApplicationConventionPlugin.kt:1-20](file://build-logic/convention/src/main/kotlin/AndroidApplicationConventionPlugin.kt#L1-L20)
- [AndroidHiltConventionPlugin.kt:1-19](file://build-logic/convention/src/main/kotlin/AndroidHiltConventionPlugin.kt#L1-L19)
- [app/build.gradle.kts:1-82](file://app/build.gradle.kts#L1-L82)

**Section sources**
- [settings.gradle.kts:1-39](file://settings.gradle.kts#L1-L39)
- [build.gradle.kts:1-12](file://build.gradle.kts#L1-L12)
- [app/build.gradle.kts:1-82](file://app/build.gradle.kts#L1-L82)

## Dependency Analysis
This section maps how modules depend on each other and how DI modules contribute to the runtime graph.

```mermaid
graph LR
APP["app"] --> CORE_COMMON["core:core-common"]
APP --> CORE_MODEL["core:core-model"]
APP --> CORE_DOMAIN["core:core-domain"]
APP --> CORE_DATA["core:core-data"]
APP --> CORE_FIREBASE["core:core-firebase"]
APP --> CORE_SEARCH["core:core-search"]
APP --> CORE_MEDIA["core:core-media"]
APP --> CORE_UI["core:core-ui"]
APP --> FEAT_AUTH["feature:feature-auth"]
APP --> FEAT_MOMENTS["feature:feature-moments"]
APP --> FEAT_EVENTS["feature:feature-events"]
APP --> FEAT_HERITAGE["feature:feature-heritage"]
APP --> FEAT_PROFILE["feature:feature-profile"]
APP --> FEAT_NOTIF["feature:feature-notifications"]
CORE_DATA --> CORE_DOMAIN
CORE_FIREBASE --> CORE_MODEL
CORE_MEDIA --> CORE_MODEL
CORE_SEARCH --> CORE_MODEL
CORE_UI --> CORE_MODEL
```

**Diagram sources**
- [app/build.gradle.kts:35-81](file://app/build.gradle.kts#L35-L81)
- [settings.gradle.kts:20-39](file://settings.gradle.kts#L20-L39)

**Section sources**
- [app/build.gradle.kts:35-81](file://app/build.gradle.kts#L35-L81)
- [settings.gradle.kts:20-39](file://settings.gradle.kts#L20-L39)

## Performance Considerations
- Use IO dispatchers for disk/network operations to prevent blocking the main thread.
- Prefer Binds over Provides for simple interface-to-implementation bindings to reduce overhead.
- Keep shared dependencies singleton-scoped to minimize object creation.
- Centralize compile and toolchain options in convention plugins to avoid repeated configuration and reduce build variance.

## Troubleshooting Guide
- Hilt errors: Ensure all binding modules are installed in the Singleton component and that qualifiers match injection sites.
- Dispatcher injection failures: Verify qualifier annotations and provider methods are present in the DI graph.
- Theme inconsistencies: Confirm that UIT20YearsTheme is wrapping the root composable and that color tokens are defined in the theme module.
- Build configuration drift: Reapply convention plugins in modules that diverge from the shared configuration.

**Section sources**
- [DispatcherModule.kt:1-27](file://app/src/main/java/com/uit20years/app/di/DispatcherModule.kt#L1-L27)
- [DataModule.kt:1-42](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt#L1-L42)
- [FirebaseModule.kt:1-28](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt#L1-L28)
- [Theme.kt:57-82](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Theme.kt#L57-L82)

## Conclusion
UIT20Years leverages custom Gradle convention plugins to enforce consistent build configuration, Hilt for robust dependency injection, a dispatcher abstraction for predictable threading, and a unified Material 3 theming system for cohesive UI. Together, these components simplify maintenance, improve developer productivity, and ensure scalable architecture across modules.
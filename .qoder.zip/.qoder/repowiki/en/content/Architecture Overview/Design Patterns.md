# Design Patterns

<cite>
**Referenced Files in This Document**
- [LoginViewModel.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt)
- [LoginEvent.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginEvent.kt)
- [LoginUiState.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginUiState.kt)
- [LoginScreen.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginScreen.kt)
- [LoginUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt)
- [AuthRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt)
- [AuthRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt)
- [FirebaseAuthService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt)
- [FirestoreService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt)
- [UitResult.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt)
- [FlowExt.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/FlowExt.kt)
- [AuthNavigation.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/navigation/AuthNavigation.kt)
- [Route.kt](file://app/src/main/java/com/uit20years/app/navigation/Route.kt)
- [AppNavHost.kt](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the design patterns implemented in UIT20Years, focusing on:
- Unidirectional Data Flow (UDF) in ViewModels using StateFlow and Channel effects
- Repository pattern with abstract interfaces and concrete Firebase implementations
- callbackFlow for Firebase real-time listeners integrated with Kotlin Flow
- Type-safe navigation via kotlinx.serialization and sealed classes
- Result pattern using UitResult for consistent error handling across layers

## Project Structure
The application follows a layered architecture:
- UI layer (Compose screens and ViewModels)
- Domain layer (UseCases and repository interfaces)
- Data layer (Concrete repository implementations)
- Firebase layer (Services exposing Flow-based APIs)
- Common utilities (Result types, extensions)

```mermaid
graph TB
subgraph "UI Layer"
LS["LoginScreen<br/>Collects uiState, effects"]
LVM["LoginViewModel<br/>StateFlow + Channel effects"]
end
subgraph "Domain Layer"
LUC["LoginUseCase<br/>Delegates to AuthRepository"]
AR["AuthRepository (interface)"]
end
subgraph "Data Layer"
ARI["AuthRepositoryImpl<br/>Uses FirebaseAuthService + FirestoreService"]
end
subgraph "Firebase Layer"
FBA["FirebaseAuthService<br/>callbackFlow for auth state"]
FS["FirestoreService<br/>callbackFlow for docs/collections"]
end
LS --> LVM
LVM --> LUC
LUC --> AR
AR --> ARI
ARI --> FBA
ARI --> FS
```

**Diagram sources**
- [LoginScreen.kt:30-126](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginScreen.kt#L30-L126)
- [LoginViewModel.kt:20-99](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L20-L99)
- [LoginUseCase.kt:9-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L9-L14)
- [AuthRepository.kt:7-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L7-L13)
- [AuthRepositoryImpl.kt:23-147](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L23-L147)
- [FirebaseAuthService.kt:13-37](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L13-L37)
- [FirestoreService.kt:15-107](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt#L15-L107)

**Section sources**
- [LoginViewModel.kt:20-99](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L20-L99)
- [AuthRepositoryImpl.kt:23-147](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L23-L147)

## Core Components
- Unidirectional Data Flow in LoginViewModel:
  - StateFlow for uiState updates
  - Channel for effects (navigation triggers)
  - UseCases orchestrate domain logic
- Repository pattern:
  - AuthRepository interface defines contracts
  - AuthRepositoryImpl implements with Firebase services
- callbackFlow integration:
  - FirebaseAuthService.observeAuthState uses callbackFlow
  - FirestoreService exposes observeDocument/observeCollection via callbackFlow
- Type-safe navigation:
  - Sealed Route classes with @Serializable
  - Navigation composables use typed routes
- Result pattern:
  - UitResult sealed interface with Loading/Success/Error
  - Extensions convert arbitrary flows to UitResult streams

**Section sources**
- [LoginViewModel.kt:20-99](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L20-L99)
- [AuthRepository.kt:7-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L7-L13)
- [AuthRepositoryImpl.kt:29-55](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L29-L55)
- [FirebaseAuthService.kt:29-35](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L29-L35)
- [FirestoreService.kt:30-62](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt#L30-L62)
- [UitResult.kt:3-11](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L3-L11)
- [FlowExt.kt:9-12](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/FlowExt.kt#L9-L12)
- [AuthNavigation.kt:11-18](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/navigation/AuthNavigation.kt#L11-L18)
- [Route.kt:5-12](file://app/src/main/java/com/uit20years/app/navigation/Route.kt#L5-L12)

## Architecture Overview
The system enforces unidirectional data flow from UI to UseCases to Repositories and back to UI via effects. The Repository pattern isolates platform-specific implementations behind interfaces, enabling testability and flexibility. Real-time integrations leverage callbackFlow to bridge Firebase callbacks into Kotlin Flow.

```mermaid
sequenceDiagram
participant UI as "LoginScreen"
participant VM as "LoginViewModel"
participant UC as "LoginUseCase"
participant REPO as "AuthRepositoryImpl"
participant AUTH as "FirebaseAuthService"
participant STORE as "FirestoreService"
UI->>VM : "LoginEvent.Submit"
VM->>VM : "validateAndLogin()"
VM->>UC : "invoke(email, password)"
UC->>REPO : "login(email, password)"
REPO->>AUTH : "signInWithEmail()"
AUTH-->>REPO : "AuthResult"
REPO->>STORE : "getDocument(users/{uid})"
STORE-->>REPO : "DocumentSnapshot"
REPO-->>UC : "Flow<UitResult<User>>"
UC-->>VM : "Flow<UitResult<User>>"
VM->>VM : "emit Loading/Success/Error"
VM->>VM : "send effect NavigateToHome"
VM-->>UI : "effects collectLatest"
UI->>UI : "onLoginSuccess()"
```

**Diagram sources**
- [LoginScreen.kt:30-126](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginScreen.kt#L30-L126)
- [LoginViewModel.kt:31-94](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L31-L94)
- [LoginUseCase.kt:12-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L12-L13)
- [AuthRepositoryImpl.kt:29-55](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L29-L55)
- [FirebaseAuthService.kt:17-18](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L17-L18)
- [FirestoreService.kt:19-20](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt#L19-L20)

## Detailed Component Analysis

### Unidirectional Data Flow (UDF) in LoginViewModel
- State management:
  - uiState is a StateFlow derived from MutableStateFlow
  - Events mutate uiState immutably via update
- Effects channel:
  - effects is a Flow from a Channel
  - ViewModel emits navigation effects instead of performing navigation itself
- UseCase orchestration:
  - LoginUseCase delegates to AuthRepository
  - ViewModel collects UseCase Flow and reacts to UitResult variants
- UI integration:
  - LoginScreen collects uiState and effects
  - On success, triggers navigation callback

```mermaid
flowchart TD
Start(["User taps Submit"]) --> Validate["Validate inputs<br/>and update uiState"]
Validate --> HasErrors{"Has errors?"}
HasErrors --> |Yes| ShowErrors["Emit error messages<br/>and keep uiState"]
HasErrors --> |No| CallUseCase["Call LoginUseCase"]
CallUseCase --> CollectFlow["Collect Flow<UitResult<User>>"]
CollectFlow --> IsLoading{"Loading?"}
IsLoading --> |Yes| SetLoading["Set isLoading=true"]
IsLoading --> |No| IsSuccess{"Success?"}
IsSuccess --> |Yes| EmitEffect["Emit NavigateToHome effect"]
IsSuccess --> |No| IsError{"Error?"}
IsError --> |Yes| ShowError["Set isLoading=false<br/>and show errorMessage"]
EmitEffect --> End(["UI navigates to Home"])
ShowErrors --> End
ShowError --> End
SetLoading --> End
```

**Diagram sources**
- [LoginViewModel.kt:31-94](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L31-L94)
- [LoginScreen.kt:39-47](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginScreen.kt#L39-L47)
- [UitResult.kt:3-11](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L3-L11)

**Section sources**
- [LoginViewModel.kt:25-46](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L25-L46)
- [LoginViewModel.kt:72-94](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L72-L94)
- [LoginScreen.kt:36-54](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginScreen.kt#L36-L54)

### Repository Pattern with Firebase Implementations
- Interface contract:
  - AuthRepository defines login/register/logout/observe/getCurrentUser
- Concrete implementation:
  - AuthRepositoryImpl uses FirebaseAuthService and FirestoreService
  - Emits UitResult variants for consistent UI handling
  - Uses map/catch to transform and handle exceptions
- Testability:
  - Domain depends on interface, not concrete Firebase classes
  - Mocking AuthRepository enables unit tests

```mermaid
classDiagram
class AuthRepository {
+login(email, password) Flow~UitResult~User~~
+register(email, password, displayName) Flow~UitResult~User~~
+logout() Flow~UitResult~Unit~~
+observeAuthState() Flow~User?~
+getCurrentUser() suspend User?
}
class AuthRepositoryImpl {
-firebaseAuthService : FirebaseAuthService
-firestoreService : FirestoreService
+login(...)
+register(...)
+logout()
+observeAuthState()
+getCurrentUser()
}
class FirebaseAuthService {
+signInWithEmail(...)
+createUser(...)
+signOut()
+getCurrentUser()
+observeAuthState() Flow~FirebaseUser?~
}
class FirestoreService {
+getDocument(...)
+setDocument(...)
+observeDocument(...) Flow~DocumentSnapshot~
+observeCollection(...) Flow~QuerySnapshot~
}
AuthRepository <|.. AuthRepositoryImpl
AuthRepositoryImpl --> FirebaseAuthService : "uses"
AuthRepositoryImpl --> FirestoreService : "uses"
```

**Diagram sources**
- [AuthRepository.kt:7-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L7-L13)
- [AuthRepositoryImpl.kt:24-147](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L24-L147)
- [FirebaseAuthService.kt:14-37](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L14-L37)
- [FirestoreService.kt:16-107](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt#L16-L107)

**Section sources**
- [AuthRepository.kt:7-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L7-L13)
- [AuthRepositoryImpl.kt:29-114](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L29-L114)

### callbackFlow for Firebase Real-Time Listeners
- FirebaseAuthService.observeAuthState:
  - Registers an AuthStateListener
  - Uses callbackFlow to emit current user changes
  - Closes channel and removes listener on completion
- FirestoreService.observeDocument/observeCollection:
  - Adds SnapshotListener
  - Emits snapshots via trySend
  - Closes with error or removes listener on completion

```mermaid
sequenceDiagram
participant VM as "AuthRepositoryImpl"
participant FBA as "FirebaseAuthService"
participant FS as "FirestoreService"
VM->>FBA : "observeAuthState()"
FBA->>FBA : "Add AuthStateListener"
FBA-->>VM : "Flow<FirebaseUser?> via callbackFlow"
VM->>FS : "getDocument(users/{uid})"
FS->>FS : "Add SnapshotListener"
FS-->>VM : "Flow<DocumentSnapshot> via callbackFlow"
VM-->>VM : "Map to User or null"
```

**Diagram sources**
- [FirebaseAuthService.kt:29-35](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L29-L35)
- [FirestoreService.kt:30-44](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt#L30-L44)
- [AuthRepositoryImpl.kt:100-114](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L100-L114)

**Section sources**
- [FirebaseAuthService.kt:29-35](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L29-L35)
- [FirestoreService.kt:30-62](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt#L30-L62)

### Type-Safe Navigation with kotlinx.serialization
- Route definitions:
  - Sealed Route class with @Serializable for top-level destinations
  - AuthRoute/LoginRoute/RegisterRoute with @Serializable for nested destinations
- Navigation composition:
  - AppNavHost sets startDestination to AuthRoute
  - authGraph configures nested navigation with typed routes
- UI navigation:
  - LoginScreen receives callbacks to navigate on success or switch screens

```mermaid
classDiagram
class Route {
<<sealed>>
}
class Auth
class Home
Route <|-- Auth
Route <|-- Home
class AuthRoute
class LoginRoute
class RegisterRoute
```

**Diagram sources**
- [Route.kt:5-12](file://app/src/main/java/com/uit20years/app/navigation/Route.kt#L5-L12)
- [AuthNavigation.kt:11-18](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/navigation/AuthNavigation.kt#L11-L18)

**Section sources**
- [Route.kt:5-12](file://app/src/main/java/com/uit20years/app/navigation/Route.kt#L5-L12)
- [AuthNavigation.kt:20-48](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/navigation/AuthNavigation.kt#L20-L48)
- [AppNavHost.kt:10-25](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L10-L25)

### Result Pattern with UitResult
- UitResult sealed interface:
  - Success<T>, Error(exception, message), Loading
- Helpers:
  - getOrNull/getOrThrow, onSuccess/onError, isSuccess/isError/isLoading
- Flow extension:
  - FlowExt.asUitResult converts any Flow<T> to Flow<UitResult<T>>
- Usage:
  - AuthRepositoryImpl emits Loading/Success/Error consistently
  - ViewModel reacts to UitResult variants uniformly

```mermaid
flowchart TD
A["Domain Flow<T>"] --> B["asUitResult()"]
B --> C{"Value emitted?"}
C --> |Yes| D["Emit Success<T>"]
C --> |No| E{"Exception?"}
E --> |Yes| F["Emit Error(Throwable, message)"]
E --> |No| G["Emit Loading (onStart)"]
```

**Diagram sources**
- [UitResult.kt:3-11](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L3-L11)
- [FlowExt.kt:9-12](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/FlowExt.kt#L9-L12)
- [AuthRepositoryImpl.kt:29-55](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L29-L55)

**Section sources**
- [UitResult.kt:3-37](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L3-L37)
- [FlowExt.kt:9-12](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/FlowExt.kt#L9-L12)
- [AuthRepositoryImpl.kt:29-55](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L29-L55)

## Dependency Analysis
- UI depends on ViewModel
- ViewModel depends on UseCase
- UseCase depends on AuthRepository (interface)
- AuthRepositoryImpl depends on FirebaseAuthService and FirestoreService
- Firebase services depend on Firebase SDK and expose Flow via callbackFlow

```mermaid
graph LR
UI["LoginScreen"] --> VM["LoginViewModel"]
VM --> UC["LoginUseCase"]
UC --> AR["AuthRepository (interface)"]
AR --> ARI["AuthRepositoryImpl"]
ARI --> FBA["FirebaseAuthService"]
ARI --> FS["FirestoreService"]
```

**Diagram sources**
- [LoginScreen.kt:30-126](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginScreen.kt#L30-L126)
- [LoginViewModel.kt:20-99](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L20-L99)
- [LoginUseCase.kt:9-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L9-L14)
- [AuthRepository.kt:7-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L7-L13)
- [AuthRepositoryImpl.kt:24-147](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L24-L147)
- [FirebaseAuthService.kt:14-37](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L14-L37)
- [FirestoreService.kt:16-107](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt#L16-L107)

**Section sources**
- [LoginViewModel.kt:20-99](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L20-L99)
- [AuthRepositoryImpl.kt:24-147](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L24-L147)

## Performance Considerations
- Prefer collecting StateFlow with lifecycle-aware collectors to avoid unnecessary work.
- Use map/catch in repositories to minimize UI-side branching and keep transformations centralized.
- Avoid heavy work on main thread; delegate to background dispatchers via injected Dispatchers if needed.
- Reuse callbackFlow registrations and remove listeners in awaitClose to prevent leaks.

## Troubleshooting Guide
- Authentication failures:
  - FirebaseAuthInvalidCredentialsException mapped to user-facing error message
  - FirebaseAuthUserCollisionException handled during registration
- Firestore connectivity:
  - FirebaseFirestoreException mapped to connection error message
- Null user profiles:
  - observeAuthState maps missing user documents to null safely
- UI feedback:
  - Use errorMessage and isLoading flags to inform users
  - Snackbar shows transient messages; dismiss via DismissError event

**Section sources**
- [AuthRepositoryImpl.kt:48-54](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L48-L54)
- [AuthRepositoryImpl.kt:81-87](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L81-L87)
- [AuthRepositoryImpl.kt:100-114](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L100-L114)
- [LoginViewModel.kt:83-89](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L83-L89)

## Conclusion
UIT20Years applies robust design patterns:
- UDF with StateFlow and Channel effects ensures predictable UI updates
- Repository pattern with Firebase-backed implementations enhances testability and modularity
- callbackFlow bridges Firebase listeners into Flow seamlessly
- Type-safe navigation with sealed classes and serialization reduces runtime errors
- UitResult standardizes error handling across layers

These patterns collectively deliver a maintainable, scalable, and developer-friendly architecture.
# Architecture Overview

<cite>
**Referenced Files in This Document**
- [UIT20YearsApplication.kt](file://app/src/main/java/com/uit20years/app/UIT20YearsApplication.kt)
- [AppNavHost.kt](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt)
- [Route.kt](file://app/src/main/java/com/uit20years/app/navigation/Route.kt)
- [settings.gradle.kts](file://settings.gradle.kts)
- [build.gradle.kts](file://build.gradle.kts)
- [DataModule.kt](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt)
- [AuthRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt)
- [FirebaseAuthService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt)
- [UitResult.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt)
- [FlowExt.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/FlowExt.kt)
- [LoginUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt)
- [LoginViewModel.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt)
- [AuthNavigation.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/navigation/AuthNavigation.kt)
- [SearchService.kt](file://core/core-search/src/main/java/com/uit20years/core/search/SearchService.kt)
- [MediaUploader.kt](file://core/core-media/src/main/java/com/uit20years/core/media/MediaUploader.kt)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document describes the multi-module Clean Architecture implementation of the UIT20Years Android application. The system is organized into three primary layers:
- Core modules: data, domain, model, and common
- Infrastructure modules: firebase, media, search, and ui
- Feature modules: modular screens and navigation per feature area

The architecture enforces unidirectional data flow in ViewModels, repository abstractions, Firebase callbackFlow for real-time listeners, and type-safe navigation via kotlinx.serialization. Cross-cutting concerns include dependency injection with Hilt, error handling with a unified UitResult, and asynchronous programming with Kotlin coroutines and Flow.

## Project Structure
The project is a multi-module Gradle build with a clear separation of concerns:
- app: Application shell and navigation host
- core: Shared libraries for domain logic, data access, models, infrastructure integrations, and UI primitives
- feature: Feature-specific screens and navigation graphs

```mermaid
graph TB
subgraph "App Shell"
APP["app"]
end
subgraph "Core Modules"
CORE_COMMON["core:core-common"]
CORE_MODEL["core:core-model"]
CORE_DOMAIN["core:core-domain"]
CORE_DATA["core:core-data"]
end
subgraph "Infrastructure Modules"
CORE_FIREBASE["core:core-firebase"]
CORE_MEDIA["core:core-media"]
CORE_SEARCH["core:core-search"]
CORE_UI["core:core-ui"]
end
subgraph "Feature Modules"
FEAT_AUTH["feature:feature-auth"]
FEAT_MOMENTS["feature:feature-moments"]
FEAT_EVENTS["feature:feature-events"]
FEAT_HERITAGE["feature:feature-heritage"]
FEAT_PROFILE["feature:feature-profile"]
FEAT_NOTIF["feature:feature-notifications"]
end
APP --> FEAT_AUTH
APP --> FEAT_MOMENTS
APP --> FEAT_EVENTS
APP --> FEAT_HERITAGE
APP --> FEAT_PROFILE
APP --> FEAT_NOTIF
CORE_DATA --> CORE_FIREBASE
CORE_DATA --> CORE_SEARCH
CORE_DATA --> CORE_MEDIA
FEAT_AUTH --> CORE_DOMAIN
FEAT_AUTH --> CORE_COMMON
FEAT_AUTH --> CORE_UI
```

**Diagram sources**
- [settings.gradle.kts:20-39](file://settings.gradle.kts#L20-L39)
- [AppNavHost.kt:1-26](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L1-L26)
- [DataModule.kt:1-42](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt#L1-L42)

**Section sources**
- [settings.gradle.kts:20-39](file://settings.gradle.kts#L20-L39)
- [build.gradle.kts:1-12](file://build.gradle.kts#L1-L12)

## Core Components
- Domain layer: Defines repositories and use cases. Example: LoginUseCase delegates to AuthRepository.
- Data layer: Implements repositories using infrastructure services. Example: AuthRepositoryImpl uses FirebaseAuthService and FirestoreService.
- Model layer: Shared domain entities and DTOs.
- Common layer: Cross-cutting utilities, result wrapper, and extensions.
- Infrastructure: Firebase, media, and search implementations.
- UI layer: Reusable composables and themes.

Key architectural patterns:
- Unidirectional Data Flow (UDF) in ViewModels: StateFlow for UI state, channels for effects, and Flow collection from use cases.
- Repository pattern: Abstractions in domain, implementations in data.
- Firebase callbackFlow: Real-time auth state observation.
- Type-safe navigation: kotlinx.serialization for route types.

Trade-offs and constraints:
- Centralized error handling via UitResult simplifies UI handling but requires consistent propagation.
- Repository abstractions isolate infrastructure changes; however, tight coupling to Firebase exists in current implementations.
- Type-safe navigation improves safety but requires serialization annotations across routes.

**Section sources**
- [LoginUseCase.kt:1-15](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L1-L15)
- [AuthRepositoryImpl.kt:1-147](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L1-L147)
- [FirebaseAuthService.kt:1-37](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L1-L37)
- [UitResult.kt:1-37](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L1-L37)
- [FlowExt.kt:1-13](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/FlowExt.kt#L1-L13)
- [LoginViewModel.kt:1-100](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L1-L100)

## Architecture Overview
The system follows Clean Architecture with distinct layers and explicit boundaries. The app module orchestrates navigation and depends on feature modules. The core-data module depends on infrastructure modules (firebase, media, search) to fulfill repository implementations. Domain use cases depend only on repository interfaces, preserving testability and isolation.

```mermaid
graph TB
subgraph "Presentation Layer"
VM["LoginViewModel"]
NAV["AuthNavigation"]
end
subgraph "Domain Layer"
UC["LoginUseCase"]
REPO_IF["AuthRepository (interface)"]
end
subgraph "Data Layer"
REPO_IMPL["AuthRepositoryImpl"]
FB_AUTH["FirebaseAuthService"]
FB_STORE["FirestoreService"]
end
subgraph "Infrastructure Layer"
FIREBASE["core:core-firebase"]
MEDIA["core:core-media"]
SEARCH["core:core-search"]
end
VM --> UC
UC --> REPO_IF
REPO_IMPL --> REPO_IF
REPO_IMPL --> FB_AUTH
REPO_IMPL --> FB_STORE
VM --> NAV
FIREBASE --> FB_AUTH
FIREBASE --> FB_STORE
MEDIA --> FB_STORE
SEARCH --> REPO_IMPL
```

**Diagram sources**
- [LoginViewModel.kt:1-100](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L1-L100)
- [AuthNavigation.kt:1-49](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/navigation/AuthNavigation.kt#L1-L49)
- [LoginUseCase.kt:1-15](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L1-L15)
- [AuthRepositoryImpl.kt:1-147](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L1-L147)
- [FirebaseAuthService.kt:1-37](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L1-L37)
- [MediaUploader.kt:1-52](file://core/core-media/src/main/java/com/uit20years/core/media/MediaUploader.kt#L1-L52)
- [SearchService.kt:1-10](file://core/core-search/src/main/java/com/uit20years/core/search/SearchService.kt#L1-L10)

## Detailed Component Analysis

### Authentication Feature Flow
This sequence illustrates the UDF flow from UI to repository and infrastructure.

```mermaid
sequenceDiagram
participant UI as "LoginScreen"
participant VM as "LoginViewModel"
participant UC as "LoginUseCase"
participant REPO as "AuthRepositoryImpl"
participant AUTH as "FirebaseAuthService"
participant STORE as "FirestoreService"
UI->>VM : "Submit event"
VM->>VM : "validateAndLogin()"
VM->>UC : "invoke(email, password)"
UC->>REPO : "login(email, password)"
REPO->>AUTH : "signInWithEmail()"
AUTH-->>REPO : "AuthResult"
REPO->>STORE : "getDocument(users/{uid})"
STORE-->>REPO : "UserDoc"
REPO-->>UC : "Flow<UitResult<User>>"
UC-->>VM : "Flow<UitResult<User>>"
VM->>VM : "collect result<br/>update uiState/effects"
VM-->>UI : "NavigateToHome effect"
```

**Diagram sources**
- [LoginViewModel.kt:72-94](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L72-L94)
- [LoginUseCase.kt:12-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L12-L13)
- [AuthRepositoryImpl.kt:29-55](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L29-L55)
- [FirebaseAuthService.kt:17-18](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L17-L18)

**Section sources**
- [LoginViewModel.kt:1-100](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L1-L100)
- [LoginUseCase.kt:1-15](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L1-L15)
- [AuthRepositoryImpl.kt:1-147](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L1-L147)
- [FirebaseAuthService.kt:1-37](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L1-L37)

### Repository Pattern and DI Binding
The data module binds domain repository interfaces to concrete implementations using Hilt.

```mermaid
classDiagram
class AuthRepository {
<<interface>>
+login(email, password) Flow~UitResult~User~~
+register(email, password, displayName) Flow~UitResult~User~~
+logout() Flow~UitResult~Unit~~
+observeAuthState() Flow~User?~
+getCurrentUser() suspend User?
}
class AuthRepositoryImpl {
-firebaseAuthService : FirebaseAuthService
-firestoreService : FirestoreService
+login(...)
+register(...)
+logout()
+observeAuthState()
+getCurrentUser()
}
class DataModule {
+bindAuthRepository(impl) : AuthRepository
}
AuthRepository <|.. AuthRepositoryImpl
DataModule --> AuthRepositoryImpl : "provides"
```

**Diagram sources**
- [AuthRepositoryImpl.kt:24-27](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L24-L27)
- [DataModule.kt:24-25](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt#L24-L25)

**Section sources**
- [DataModule.kt:1-42](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt#L1-L42)
- [AuthRepositoryImpl.kt:1-147](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L1-L147)

### Firebase callbackFlow for Real-Time Auth State
FirebaseAuthService exposes a Flow for auth state using callbackFlow, enabling reactive updates in the repository.

```mermaid
flowchart TD
Start(["Observe Auth State"]) --> CreateFlow["Create callbackFlow"]
CreateFlow --> AddListener["Add AuthStateListener"]
AddListener --> TrySend["trySend(currentUser)"]
TrySend --> RemoveOnClose["awaitClose remove listener"]
RemoveOnClose --> End(["End"])
```

**Diagram sources**
- [FirebaseAuthService.kt:29-35](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L29-L35)

**Section sources**
- [FirebaseAuthService.kt:1-37](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L1-L37)

### Type-Safe Navigation with kotlinx.serialization
Routes are annotated with Serializable to enable compile-time safe navigation across features.

```mermaid
classDiagram
class Route {
<<sealed @Serializable>>
}
class AuthRoute {
<<@Serializable data object>>
}
class HomeRoute {
<<@Serializable data object>>
}
Route <|-- AuthRoute
Route <|-- HomeRoute
```

**Diagram sources**
- [Route.kt:5-12](file://app/src/main/java/com/uit20years/app/navigation/Route.kt#L5-L12)

**Section sources**
- [Route.kt:1-13](file://app/src/main/java/com/uit20years/app/navigation/Route.kt#L1-L13)
- [AuthNavigation.kt:11-18](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/navigation/AuthNavigation.kt#L11-L18)

### Error Handling with UitResult
A sealed interface encapsulates Success, Error, and Loading states, enabling consistent UI handling across flows.

```mermaid
classDiagram
class UitResult {
<<sealed>>
}
class Success~T~ {
+data : T
}
class Error {
+exception : Throwable?
+message : String?
}
class Loading {
}
UitResult <|-- Success
UitResult <|-- Error
UitResult <|-- Loading
```

**Diagram sources**
- [UitResult.kt:3-11](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L3-L11)

**Section sources**
- [UitResult.kt:1-37](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L1-L37)
- [FlowExt.kt:9-12](file://core/core-common/src/main/kotlin/com/uit20years/core/common/extensions/FlowExt.kt#L9-L12)

## Dependency Analysis
Module-level dependencies:
- app depends on all feature modules and core-data
- core-data depends on core-firebase, core-search, and core-media
- feature modules depend on core-domain, core-common, and core-ui

```mermaid
graph LR
APP["app"] --> FEAT_AUTH["feature:feature-auth"]
APP --> FEAT_MOMENTS["feature:feature-moments"]
APP --> FEAT_EVENTS["feature:feature-events"]
APP --> FEAT_HERITAGE["feature:feature-heritage"]
APP --> FEAT_PROFILE["feature:feature-profile"]
APP --> FEAT_NOTIF["feature:feature-notifications"]
FEAT_AUTH --> CORE_DOMAIN["core:core-domain"]
FEAT_AUTH --> CORE_COMMON["core:core-common"]
FEAT_AUTH --> CORE_UI["core:core-ui"]
CORE_DATA["core:core-data"] --> CORE_FIREBASE["core:core-firebase"]
CORE_DATA --> CORE_SEARCH["core:core-search"]
CORE_DATA --> CORE_MEDIA["core:core-media"]
```

**Diagram sources**
- [settings.gradle.kts:20-39](file://settings.gradle.kts#L20-L39)
- [AppNavHost.kt:7-18](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L7-L18)
- [DataModule.kt:1-42](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt#L1-L42)

**Section sources**
- [settings.gradle.kts:20-39](file://settings.gradle.kts#L20-L39)
- [AppNavHost.kt:1-26](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt#L1-L26)
- [DataModule.kt:1-42](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt#L1-L42)

## Performance Considerations
- Asynchronous IO: Media uploads delegate to Dispatchers.IO via withContext to avoid blocking the main thread.
- Reactive streams: callbackFlow and Flow transformations minimize UI thread work and reduce redundant UI updates.
- Caching and offline behavior: Consider adding local caching layers for frequently accessed data to reduce network latency.
- Memory management: Ensure Flow collectors are scoped to lifecycle-aware components to prevent leaks.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and resolutions:
- Authentication errors: Inspect UitResult.Error propagation from repository to ViewModel and ensure localized messages are surfaced to the UI.
- Firestore exceptions: Wrap repository calls with catch blocks and convert exceptions to UitResult.Error for consistent handling.
- Navigation failures: Verify @Serializable annotations on route types and ensure NavGraphBuilder composable registrations match route definitions.
- Media upload failures: Validate InputStream availability and compression quality thresholds; handle exceptions during storage upload and URL retrieval.

**Section sources**
- [AuthRepositoryImpl.kt:48-54](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L48-L54)
- [UitResult.kt:5-10](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L5-L10)
- [AuthNavigation.kt:20-48](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/navigation/AuthNavigation.kt#L20-L48)
- [MediaUploader.kt:24-35](file://core/core-media/src/main/java/com/uit20years/core/media/MediaUploader.kt#L24-L35)

## Conclusion
The UIT20Years application employs a robust multi-module Clean Architecture with clear separation between presentation, domain, data, and infrastructure layers. The design leverages UDF in ViewModels, repository abstractions, Firebase callbackFlow for real-time updates, and type-safe navigation. Cross-cutting concerns such as Hilt DI, UitResult-based error handling, and Kotlin Flow ensure maintainability and scalability. Future enhancements could focus on introducing caching layers, expanding search capabilities, and refining media handling for improved performance and resilience.
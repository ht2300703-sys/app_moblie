# Module Organization

<cite>
**Referenced Files in This Document**
- [settings.gradle.kts](file://settings.gradle.kts)
- [build.gradle.kts](file://build.gradle.kts)
- [gradle/libs.versions.toml](file://gradle/libs.versions.toml)
- [app/build.gradle.kts](file://app/build.gradle.kts)
- [build-logic/convention/src/main/kotlin/AndroidApplicationConventionPlugin.kt](file://build-logic/convention/src/main/kotlin/AndroidApplicationConventionPlugin.kt)
- [build-logic/convention/src/main/kotlin/AndroidLibraryConventionPlugin.kt](file://build-logic/convention/src/main/kotlin/AndroidLibraryConventionPlugin.kt)
- [build-logic/convention/src/main/kotlin/AndroidFeatureConventionPlugin.kt](file://build-logic/convention/src/main/kotlin/AndroidFeatureConventionPlugin.kt)
- [core/core-data/build.gradle.kts](file://core/core-data/build.gradle.kts)
- [core/core-domain/build.gradle.kts](file://core/core-domain/build.gradle.kts)
- [core/core-firebase/build.gradle.kts](file://core/core-firebase/build.gradle.kts)
- [core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt)
- [core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt)
- [core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt)
- [core/core-common/src/main/kotlin/com/uit20years/core/common/constants/AppConstants.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/constants/AppConstants.kt)
- [core/core-ui/src/main/java/com/uit20years/core/ui/component/UitButton.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitButton.kt)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the multi-module architecture of UIT20Years, focusing on how modules are separated into core, infrastructure, and feature categories. It details the dependency graph, the rationale behind module boundaries, and how custom convention plugins standardize build configuration. The document also highlights how well-defined interfaces enable independent development, testing, and team collaboration while promoting code reuse and maintainability.

## Project Structure
The project organizes code into:
- app: Application module that aggregates all features and core modules.
- core: Shared libraries grouped by responsibility (common, data, domain, model, firebase, media, search, ui).
- feature: Feature modules implementing screens and navigation per feature area.
- build-logic: Convention plugins that standardize Gradle configuration across modules.

```mermaid
graph TB
subgraph "App"
APP["app"]
end
subgraph "Core Modules"
CORE_COMMON["core:core-common"]
CORE_MODEL["core:core-model"]
CORE_DOMAIN["core:core-domain"]
CORE_DATA["core:core-data"]
CORE_FIREBASE["core:core-firebase"]
CORE_SEARCH["core:core-search"]
CORE_MEDIA["core:core-media"]
CORE_UI["core:core-ui"]
end
subgraph "Feature Modules"
FEAT_AUTH["feature:feature-auth"]
FEAT_MOMENTS["feature:feature-moments"]
FEAT_EVENTS["feature:feature-events"]
FEAT_HERITAGE["feature:feature-heritage"]
FEAT_PROFILE["feature:feature-profile"]
FEAT_NOTIF["feature:feature-notifications"]
end
APP --> FEAT_AUTH
APP --> FEAT_MOMENTS
APP --> FEAT_EVENTS
APP --> FEAT_HERITAGE
APP --> FEAT_PROFILE
APP --> FEAT_NOTIF
APP --> CORE_DATA
APP --> CORE_FIREBASE
APP --> CORE_SEARCH
APP --> CORE_MEDIA
APP --> CORE_UI
APP --> CORE_DOMAIN
APP --> CORE_MODEL
APP --> CORE_COMMON
CORE_DATA --> CORE_DOMAIN
CORE_DATA --> CORE_FIREBASE
CORE_DATA --> CORE_SEARCH
CORE_DATA --> CORE_MEDIA
CORE_DATA --> CORE_MODEL
CORE_DATA --> CORE_COMMON
```

**Diagram sources**
- [settings.gradle.kts:20-39](file://settings.gradle.kts#L20-L39)
- [app/build.gradle.kts:35-52](file://app/build.gradle.kts#L35-L52)
- [core/core-data/build.gradle.kts:10-16](file://core/core-data/build.gradle.kts#L10-L16)

**Section sources**
- [settings.gradle.kts:18-39](file://settings.gradle.kts#L18-L39)
- [app/build.gradle.kts:1-82](file://app/build.gradle.kts#L1-L82)

## Core Components
This section describes the core modules and their roles:
- core-common: Shared constants, utilities, and extension functions used across modules.
- core-model: Plain Kotlin data classes representing domain entities.
- core-domain: Interfaces defining repositories and use cases; pure Kotlin module.
- core-data: Implementations of repositories and data transfer objects; depends on firebase, search, media, model, and common.
- core-firebase: Firebase service abstractions and implementations.
- core-search: Search service abstraction and implementation.
- core-media: Media compression and upload utilities.
- core-ui: Compose UI components and theming.

These modules form the foundation for feature modules and the app module, ensuring shared logic and consistent behavior.

**Section sources**
- [core/core-common/src/main/kotlin/com/uit20years/core/common/constants/AppConstants.kt:1-13](file://core/core-common/src/main/kotlin/com/uit20years/core/common/constants/AppConstants.kt#L1-L13)
- [core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt:1-23](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt#L1-L23)
- [core/core-domain/build.gradle.kts:1-11](file://core/core-domain/build.gradle.kts#L1-L11)
- [core/core-data/build.gradle.kts:1-21](file://core/core-data/build.gradle.kts#L1-L21)
- [core/core-firebase/build.gradle.kts:1-22](file://core/core-firebase/build.gradle.kts#L1-L22)

## Architecture Overview
The app module depends on all feature modules plus core modules. The core-data module depends on core-domain, core-firebase, core-search, core-media, core-model, and core-common. This layered structure enforces unidirectional dependencies and isolates infrastructure concerns.

```mermaid
graph LR
subgraph "App Layer"
APP["app"]
end
subgraph "Feature Layer"
FEAT_AUTH["feature:feature-auth"]
FEAT_MOMENTS["feature:feature-moments"]
FEAT_EVENTS["feature:feature-events"]
FEAT_HERITAGE["feature:feature-heritage"]
FEAT_PROFILE["feature:feature-profile"]
FEAT_NOTIF["feature:feature-notifications"]
end
subgraph "Core Layer"
CORE_DATA["core:core-data"]
CORE_DOMAIN["core:core-domain"]
CORE_FIREBASE["core:core-firebase"]
CORE_SEARCH["core:core-search"]
CORE_MEDIA["core:core-media"]
CORE_MODEL["core:core-model"]
CORE_COMMON["core:core-common"]
CORE_UI["core:core-ui"]
end
APP --> FEAT_AUTH
APP --> FEAT_MOMENTS
APP --> FEAT_EVENTS
APP --> FEAT_HERITAGE
APP --> FEAT_PROFILE
APP --> FEAT_NOTIF
APP --> CORE_DATA
APP --> CORE_UI
APP --> CORE_DOMAIN
APP --> CORE_MODEL
APP --> CORE_COMMON
CORE_DATA --> CORE_DOMAIN
CORE_DATA --> CORE_FIREBASE
CORE_DATA --> CORE_SEARCH
CORE_DATA --> CORE_MEDIA
CORE_DATA --> CORE_MODEL
CORE_DATA --> CORE_COMMON
```

**Diagram sources**
- [app/build.gradle.kts:35-52](file://app/build.gradle.kts#L35-L52)
- [core/core-data/build.gradle.kts:10-16](file://core/core-data/build.gradle.kts#L10-L16)

## Detailed Component Analysis

### Repository Pattern and Dependency Injection
The repository pattern separates domain logic from data sources. Domain defines interfaces; data implements them using infrastructure services.

```mermaid
classDiagram
class AuthRepository {
+login(email, password) Flow~UitResult~User~~
+register(email, password, displayName) Flow~UitResult~User~~
+logout() Flow~UitResult~Unit~
+observeAuthState() Flow~User?~
+getCurrentUser() suspend User?
}
class AuthRepositoryImpl {
-firebaseAuthService : FirebaseAuthService
-firestoreService : FirestoreService
+login(...)
+register(...)
+logout()
+observeAuthState()
+getCurrentUser()
}
AuthRepository <|.. AuthRepositoryImpl : "implements"
```

**Diagram sources**
- [core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt:1-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L1-L14)
- [core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt:1-147](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L1-L147)

**Section sources**
- [core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt:1-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L1-L14)
- [core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt:1-147](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L1-L147)

### Build Configuration via Convention Plugins
Custom convention plugins standardize Gradle configuration across modules:
- AndroidApplicationConventionPlugin: Applies Android application and Kotlin Android plugins, configures Kotlin Android options, and sets target SDK.
- AndroidLibraryConventionPlugin: Applies Android library and Kotlin Android plugins, configures Kotlin Android options.
- AndroidFeatureConventionPlugin: Applies library, compose, hilt, serialization plugins; adds core-ui, core-domain, core-model, core-common dependencies; adds navigation, lifecycle, and serialization libraries.

```mermaid
graph TB
subgraph "Convention Plugins"
ACP["AndroidApplicationConventionPlugin"]
ALP["AndroidLibraryConventionPlugin"]
AFP["AndroidFeatureConventionPlugin"]
end
subgraph "Modules"
APP["app"]
CORE_DATA["core:core-data"]
FEATURE_AUTH["feature:feature-auth"]
end
ACP --> APP
ALP --> CORE_DATA
AFP --> FEATURE_AUTH
APP --> |"applies"| ACP
CORE_DATA --> |"applies"| ALP
FEATURE_AUTH --> |"applies"| AFP
```

**Diagram sources**
- [build-logic/convention/src/main/kotlin/AndroidApplicationConventionPlugin.kt:1-20](file://build-logic/convention/src/main/kotlin/AndroidApplicationConventionPlugin.kt#L1-L20)
- [build-logic/convention/src/main/kotlin/AndroidLibraryConventionPlugin.kt:1-19](file://build-logic/convention/src/main/kotlin/AndroidLibraryConventionPlugin.kt#L1-L19)
- [build-logic/convention/src/main/kotlin/AndroidFeatureConventionPlugin.kt:1-28](file://build-logic/convention/src/main/kotlin/AndroidFeatureConventionPlugin.kt#L1-L28)

**Section sources**
- [build-logic/convention/src/main/kotlin/AndroidApplicationConventionPlugin.kt:1-20](file://build-logic/convention/src/main/kotlin/AndroidApplicationConventionPlugin.kt#L1-L20)
- [build-logic/convention/src/main/kotlin/AndroidLibraryConventionPlugin.kt:1-19](file://build-logic/convention/src/main/kotlin/AndroidLibraryConventionPlugin.kt#L1-L19)
- [build-logic/convention/src/main/kotlin/AndroidFeatureConventionPlugin.kt:1-28](file://build-logic/convention/src/main/kotlin/AndroidFeatureConventionPlugin.kt#L1-L28)

### UI Component Example
The core-ui module provides reusable Compose components. For example, a button component encapsulates styling and loading state, enabling consistent UI across features.

```mermaid
classDiagram
class UitButton {
+text : String
+onClick() : Unit
+enabled : Boolean
+isLoading : Boolean
+backgroundColor : Color
+invoke() : Unit
}
```

**Diagram sources**
- [core/core-ui/src/main/java/com/uit20years/core/ui/component/UitButton.kt:1-42](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitButton.kt#L1-L42)

**Section sources**
- [core/core-ui/src/main/java/com/uit20years/core/ui/component/UitButton.kt:1-42](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitButton.kt#L1-L42)

### Data Flow Through Repository Implementation
The repository implementation coordinates authentication and Firestore operations, emitting domain models wrapped in a unified result type.

```mermaid
sequenceDiagram
participant VM as "ViewModel"
participant Repo as "AuthRepositoryImpl"
participant Auth as "FirebaseAuthService"
participant Store as "FirestoreService"
VM->>Repo : "login(email, password)"
Repo->>Auth : "signInWithEmail(...)"
Auth-->>Repo : "AuthResult"
Repo->>Store : "getDocument(users, uid)"
Store-->>Repo : "DocumentSnapshot"
Repo-->>VM : "UitResult.Success(User)"
```

**Diagram sources**
- [core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt:29-55](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L29-L55)

**Section sources**
- [core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt:1-147](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L1-L147)

## Dependency Analysis
The dependency graph ensures clear separation of concerns:
- app depends on all feature modules and core modules.
- core-data depends on core-domain, core-firebase, core-search, core-media, core-model, and core-common.
- core-domain is a pure JVM module depending on core-model and core-common.
- core-firebase depends on core-model and core-common and brings in Firebase BOM and related libraries.

```mermaid
graph TD
APP["app"] --> FEAT_AUTH["feature:feature-auth"]
APP --> FEAT_MOMENTS["feature:feature-moments"]
APP --> FEAT_EVENTS["feature:feature-events"]
APP --> FEAT_HERITAGE["feature:feature-heritage"]
APP --> FEAT_PROFILE["feature:feature-profile"]
APP --> FEAT_NOTIF["feature:feature-notifications"]
APP --> CORE_DATA["core:core-data"]
APP --> CORE_UI["core:core-ui"]
APP --> CORE_DOMAIN["core:core-domain"]
APP --> CORE_MODEL["core:core-model"]
APP --> CORE_COMMON["core:core-common"]
CORE_DATA --> CORE_DOMAIN
CORE_DATA --> CORE_FIREBASE["core:core-firebase"]
CORE_DATA --> CORE_SEARCH["core:core-search"]
CORE_DATA --> CORE_MEDIA["core:core-media"]
CORE_DATA --> CORE_MODEL
CORE_DATA --> CORE_COMMON
CORE_DOMAIN --> CORE_MODEL
CORE_DOMAIN --> CORE_COMMON
CORE_FIREBASE --> CORE_MODEL
CORE_FIREBASE --> CORE_COMMON
```

**Diagram sources**
- [app/build.gradle.kts:35-52](file://app/build.gradle.kts#L35-L52)
- [core/core-data/build.gradle.kts:10-16](file://core/core-data/build.gradle.kts#L10-L16)
- [core/core-domain/build.gradle.kts:5-10](file://core/core-domain/build.gradle.kts#L5-L10)
- [core/core-firebase/build.gradle.kts:10-21](file://core/core-firebase/build.gradle.kts#L10-L21)

**Section sources**
- [app/build.gradle.kts:35-52](file://app/build.gradle.kts#L35-L52)
- [core/core-data/build.gradle.kts:10-16](file://core/core-data/build.gradle.kts#L10-L16)
- [core/core-domain/build.gradle.kts:5-10](file://core/core-domain/build.gradle.kts#L5-L10)
- [core/core-firebase/build.gradle.kts:10-21](file://core/core-firebase/build.gradle.kts#L10-L21)

## Performance Considerations
- Centralized dependency management via libs.versions.toml ensures consistent versions and reduces transitive dependency bloat.
- Using a single Compose BOM and Firebase BOM simplifies compatibility and improves build reproducibility.
- Pure JVM core-domain avoids Android runtime overhead, keeping domain logic portable and testable.

**Section sources**
- [gradle/libs.versions.toml:1-103](file://gradle/libs.versions.toml#L1-L103)
- [build.gradle.kts:1-12](file://build.gradle.kts#L1-L12)

## Troubleshooting Guide
- Circular dependencies: Enforce unidirectional dependencies (e.g., data depends on domain and infrastructure; app depends on features and core). Keep core-domain free of Android or infrastructure dependencies.
- Version conflicts: Use libs.versions.toml to align versions across modules; avoid overriding versions in individual modules unless necessary.
- Build failures due to missing plugins: Ensure convention plugins are applied consistently; verify plugin IDs match those declared in libs.versions.toml.
- DI wiring: Confirm that @Module and @Provides/@InstallIn bindings are correctly scoped and that feature modules depend on core-ui, core-domain, core-model, and core-common as configured by AndroidFeatureConventionPlugin.

**Section sources**
- [build-logic/convention/src/main/kotlin/AndroidFeatureConventionPlugin.kt:1-28](file://build-logic/convention/src/main/kotlin/AndroidFeatureConventionPlugin.kt#L1-L28)
- [gradle/libs.versions.toml:93-103](file://gradle/libs.versions.toml#L93-L103)

## Conclusion
UIT20Years employs a disciplined multi-module architecture that separates concerns across core, infrastructure, and feature layers. Convention plugins standardize build configuration, while well-defined interfaces and repositories enable independent development and testing. This structure improves team collaboration, code reusability, and long-term maintainability by enforcing clear boundaries and reducing coupling.
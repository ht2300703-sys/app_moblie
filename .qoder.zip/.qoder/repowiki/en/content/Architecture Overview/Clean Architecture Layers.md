# Clean Architecture Layers

<cite>
**Referenced Files in This Document**
- [LoginUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt)
- [AuthRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt)
- [AuthRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt)
- [UitResult.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt)
- [LoginViewModel.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt)
- [RegisterUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt)
- [RegisterViewModel.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt)
- [FirebaseAuthService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt)
- [FirestoreService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt)
- [DataModule.kt](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt)
- [User.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt)
- [UserDto.kt](file://core/core-data/src/main/java/com/uit20years/core/data/dto/UserDto.kt)
- [UserMapper.kt](file://core/core-data/src/main/java/com/uit20years/core/data/mapper/UserMapper.kt)
- [ObserveAuthStateUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/ObserveAuthStateUseCase.kt)
- [GetCurrentUserUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/GetCurrentUserUseCase.kt)
- [LoginScreen.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginScreen.kt)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the Clean Architecture implementation in UIT20Years across three layers:
- Presentation: Jetpack Compose UI with ViewModels
- Domain: UseCases and Repository interfaces
- Data: Repository implementations backed by Firebase services

It details how data flows unidirectionally from UI through UseCases to Repositories and back, how the Repository pattern provides abstraction and testability, and how errors are handled consistently via UitResult across layers.

## Project Structure
The project is organized into modules aligned with Clean Architecture layers and feature boundaries:
- core/core-common: Shared utilities and domain-agnostic result type
- core/core-domain: Business logic contracts (UseCases, Repository interfaces)
- core/core-data: Implementation of repositories and DTOs
- core/core-firebase: Infrastructure services (Firebase Auth, Firestore)
- core/core-model: Domain models
- feature/feature-auth: Feature-specific UI and ViewModel orchestration
- build-logic: Convention plugins for consistent module configuration

```mermaid
graph TB
subgraph "Presentation Layer"
A_LoginScreen["LoginScreen<br/>(feature-auth)"]
A_LoginVM["LoginViewModel<br/>(feature-auth)"]
A_RegisterVM["RegisterViewModel<br/>(feature-auth)"]
end
subgraph "Domain Layer"
D_LoginUC["LoginUseCase"]
D_RegUC["RegisterUseCase"]
D_ObserveUC["ObserveAuthStateUseCase"]
D_GetUserUC["GetCurrentUserUseCase"]
D_RepoIF["AuthRepository (interface)"]
end
subgraph "Data Layer"
I_RepoImpl["AuthRepositoryImpl"]
I_FireAuth["FirebaseAuthService"]
I_Firestore["FirestoreService"]
I_DTO["UserDto"]
I_Mapper["UserMapper"]
end
A_LoginScreen --> A_LoginVM
A_LoginVM --> D_LoginUC
A_RegisterVM --> D_RegUC
D_LoginUC --> D_RepoIF
D_RegUC --> D_RepoIF
D_ObserveUC --> D_RepoIF
D_GetUserUC --> D_RepoIF
D_RepoIF --> I_RepoImpl
I_RepoImpl --> I_FireAuth
I_RepoImpl --> I_Firestore
I_RepoImpl --> I_DTO
I_DTO --> I_Mapper
```

**Diagram sources**
- [LoginScreen.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginScreen.kt)
- [LoginViewModel.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt)
- [RegisterViewModel.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt)
- [LoginUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt)
- [RegisterUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt)
- [ObserveAuthStateUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/ObserveAuthStateUseCase.kt)
- [GetCurrentUserUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/GetCurrentUserUseCase.kt)
- [AuthRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt)
- [AuthRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt)
- [FirebaseAuthService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt)
- [FirestoreService.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt)
- [UserDto.kt](file://core/core-data/src/main/java/com/uit20years/core/data/dto/UserDto.kt)
- [UserMapper.kt](file://core/core-data/src/main/java/com/uit20years/core/data/mapper/UserMapper.kt)

**Section sources**
- [LoginUseCase.kt:1-15](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L1-L15)
- [AuthRepository.kt:1-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L1-L14)
- [AuthRepositoryImpl.kt:1-147](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L1-L147)
- [UitResult.kt:1-37](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L1-L37)
- [LoginViewModel.kt:1-100](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L1-L100)
- [RegisterUseCase.kt:1-18](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt#L1-L18)
- [RegisterViewModel.kt:1-140](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt#L1-L140)
- [FirebaseAuthService.kt:1-37](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L1-L37)
- [FirestoreService.kt:1-107](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt#L1-L107)
- [DataModule.kt:1-42](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt#L1-L42)
- [User.kt:1-23](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt#L1-L23)
- [UserDto.kt:1-19](file://core/core-data/src/main/java/com/uit20years/core/data/dto/UserDto.kt#L1-L19)
- [UserMapper.kt:1-29](file://core/core-data/src/main/java/com/uit20years/core/data/mapper/UserMapper.kt#L1-L29)
- [ObserveAuthStateUseCase.kt:1-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/ObserveAuthStateUseCase.kt#L1-L13)
- [GetCurrentUserUseCase.kt:1-23](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/GetCurrentUserUseCase.kt#L1-L23)
- [LoginScreen.kt:1-126](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginScreen.kt#L1-L126)

## Core Components
- Presentation layer
  - LoginViewModel and RegisterViewModel orchestrate UI events, validate inputs, and collect UitResult streams from UseCases to update state and emit effects.
  - LoginScreen renders UI and reacts to effects and state changes.
- Domain layer
  - UseCases encapsulate business logic and expose Flow<UitResult<T>> to the presentation layer.
  - AuthRepository defines the contract for authentication operations.
- Data layer
  - AuthRepositoryImpl implements the contract using Firebase services and maps DTOs to domain models.
  - FirebaseAuthService and FirestoreService provide infrastructure capabilities.
- Shared utilities
  - UitResult standardizes success, error, and loading states across layers.

Key responsibilities:
- Presentation: UI rendering, event handling, state updates, and effect emission.
- Domain: Business logic encapsulation and repository abstraction.
- Data: Concrete implementations, data mapping, and infrastructure integration.

**Section sources**
- [LoginViewModel.kt:1-100](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L1-L100)
- [RegisterViewModel.kt:1-140](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/register/RegisterViewModel.kt#L1-L140)
- [LoginUseCase.kt:1-15](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L1-L15)
- [RegisterUseCase.kt:1-18](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt#L1-L18)
- [AuthRepository.kt:1-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L1-L14)
- [AuthRepositoryImpl.kt:1-147](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L1-L147)
- [FirebaseAuthService.kt:1-37](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L1-L37)
- [FirestoreService.kt:1-107](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt#L1-L107)
- [UitResult.kt:1-37](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L1-L37)

## Architecture Overview
Clean Architecture separates concerns into layers with clear boundaries:
- Presentation depends on Domain UseCases
- Domain depends only on abstractions (Repository interfaces)
- Data implements the abstractions and depends on Infrastructure
- Infrastructure depends on external services (Firebase)

```mermaid
graph TB
P["Presentation<br/>(feature-auth)"] --> D["Domain<br/>(core-domain)"]
D --> R["Repository Interfaces<br/>(core-domain)"]
R --> I["Repository Implementations<br/>(core-data)"]
I --> F["Firebase Services<br/>(core-firebase)"]
F --> E["External Services<br/>(Firebase)"]
```

**Diagram sources**
- [LoginViewModel.kt:1-100](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L1-L100)
- [LoginUseCase.kt:1-15](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L1-L15)
- [AuthRepository.kt:1-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L1-L14)
- [AuthRepositoryImpl.kt:1-147](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L1-L147)
- [FirebaseAuthService.kt:1-37](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L1-L37)
- [FirestoreService.kt:1-107](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt#L1-L107)

## Detailed Component Analysis

### Presentation Layer: LoginViewModel and LoginScreen
- LoginViewModel
  - Maintains UI state and effects channels
  - Validates input and triggers LoginUseCase
  - Collects UitResult and updates state or emits navigation effects
- LoginScreen
  - Renders form fields and buttons
  - Collects effects to navigate on success and displays error messages via Snackbar

```mermaid
sequenceDiagram
participant UI as "LoginScreen"
participant VM as "LoginViewModel"
participant UC as "LoginUseCase"
participant Repo as "AuthRepository"
participant Impl as "AuthRepositoryImpl"
participant FA as "FirebaseAuthService"
participant FS as "FirestoreService"
UI->>VM : "Submit event"
VM->>VM : "validateAndLogin()"
VM->>UC : "invoke(email, password)"
UC->>Repo : "login(email, password)"
Repo-->>Impl : "interface bound to implementation"
Impl->>FA : "signInWithEmail()"
FA-->>Impl : "AuthResult"
Impl->>FS : "getDocument(users/{uid})"
FS-->>Impl : "DocumentSnapshot"
Impl-->>UC : "Flow<UitResult<User>>"
UC-->>VM : "Flow<UitResult<User>>"
VM->>VM : "collect result"
VM-->>UI : "navigate on Success"
```

**Diagram sources**
- [LoginScreen.kt:1-126](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginScreen.kt#L1-L126)
- [LoginViewModel.kt:1-100](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L1-L100)
- [LoginUseCase.kt:1-15](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L1-L15)
- [AuthRepository.kt:1-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L1-L14)
- [AuthRepositoryImpl.kt:1-147](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L1-L147)
- [FirebaseAuthService.kt:1-37](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L1-L37)
- [FirestoreService.kt:1-107](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt#L1-L107)

**Section sources**
- [LoginViewModel.kt:1-100](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L1-L100)
- [LoginScreen.kt:1-126](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginScreen.kt#L1-L126)

### Domain Layer: UseCases and Repository Interfaces
- LoginUseCase and RegisterUseCase
  - Thin wrappers around AuthRepository methods
  - Expose Flow<UitResult<T>> to the presentation layer
- AuthRepository
  - Defines authentication operations with typed return types and Flow semantics
- ObserveAuthStateUseCase and GetCurrentUserUseCase
  - Demonstrate additional domain operations that also rely on AuthRepository

```mermaid
classDiagram
class AuthRepository {
+login(email, password) Flow~UitResult~User~~
+register(email, password, displayName) Flow~UitResult~User~~
+logout() Flow~UitResult~Unit~~
+observeAuthState() Flow~User?~
+getCurrentUser() suspend User?
}
class LoginUseCase {
+invoke(email, password) Flow~UitResult~User~~
}
class RegisterUseCase {
+invoke(email, password, displayName) Flow~UitResult~User~~
}
class ObserveAuthStateUseCase {
+invoke() Flow~User?~
}
class GetCurrentUserUseCase {
+invoke() Flow~UitResult~User~~
}
LoginUseCase --> AuthRepository : "depends on"
RegisterUseCase --> AuthRepository : "depends on"
ObserveAuthStateUseCase --> AuthRepository : "depends on"
GetCurrentUserUseCase --> AuthRepository : "depends on"
```

**Diagram sources**
- [AuthRepository.kt:1-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L1-L14)
- [LoginUseCase.kt:1-15](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L1-L15)
- [RegisterUseCase.kt:1-18](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt#L1-L18)
- [ObserveAuthStateUseCase.kt:1-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/ObserveAuthStateUseCase.kt#L1-L13)
- [GetCurrentUserUseCase.kt:1-23](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/GetCurrentUserUseCase.kt#L1-L23)

**Section sources**
- [LoginUseCase.kt:1-15](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L1-L15)
- [RegisterUseCase.kt:1-18](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/RegisterUseCase.kt#L1-L18)
- [AuthRepository.kt:1-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L1-L14)
- [ObserveAuthStateUseCase.kt:1-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/ObserveAuthStateUseCase.kt#L1-L13)
- [GetCurrentUserUseCase.kt:1-23](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/GetCurrentUserUseCase.kt#L1-L23)

### Data Layer: Repository Implementations and Firebase Services
- AuthRepositoryImpl
  - Implements login, register, logout, observeAuthState, and getCurrentUser
  - Emits UitResult states and handles exceptions from Firebase services
  - Uses FirebaseAuthService and FirestoreService
  - Maps between UserDto and User model
- FirebaseAuthService and FirestoreService
  - Provide coroutine-friendly wrappers around Firebase SDK
  - Expose Flow-based APIs for reactive streams
- DataModule binds implementations to interfaces for DI

```mermaid
flowchart TD
Start(["AuthRepositoryImpl.login"]) --> EmitLoading["Emit Loading"]
EmitLoading --> SignIn["FirebaseAuthService.signInWithEmail"]
SignIn --> HasUser{"User present?"}
HasUser --> |No| EmitError["Emit Error"]
HasUser --> |Yes| GetUserDoc["FirestoreService.getDocument(users, uid)"]
GetUserDoc --> DocExists{"Document exists?"}
DocExists --> |No| EmitErrorNotFound["Emit Error (profile not found)"]
DocExists --> |Yes| MapModel["Map UserDto -> User"]
MapModel --> EmitSuccess["Emit Success"]
EmitError --> End(["Return"])
EmitErrorNotFound --> End
EmitSuccess --> End
```

**Diagram sources**
- [AuthRepositoryImpl.kt:1-147](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L1-L147)
- [FirebaseAuthService.kt:1-37](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L1-L37)
- [FirestoreService.kt:1-107](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt#L1-L107)
- [UserDto.kt:1-19](file://core/core-data/src/main/java/com/uit20years/core/data/dto/UserDto.kt#L1-L19)
- [UserMapper.kt:1-29](file://core/core-data/src/main/java/com/uit20years/core/data/mapper/UserMapper.kt#L1-L29)
- [User.kt:1-23](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt#L1-L23)

**Section sources**
- [AuthRepositoryImpl.kt:1-147](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L1-L147)
- [FirebaseAuthService.kt:1-37](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L1-L37)
- [FirestoreService.kt:1-107](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt#L1-L107)
- [DataModule.kt:1-42](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt#L1-L42)
- [UserDto.kt:1-19](file://core/core-data/src/main/java/com/uit20years/core/data/dto/UserDto.kt#L1-L19)
- [UserMapper.kt:1-29](file://core/core-data/src/main/java/com/uit20years/core/data/mapper/UserMapper.kt#L1-L29)
- [User.kt:1-23](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt#L1-L23)

### Unidirectional Data Flow Pattern
- UI emits events to ViewModel
- ViewModel validates and invokes UseCase
- UseCase delegates to Repository interface
- Repository implementation performs work and emits UitResult
- ViewModel updates state and emits effects
- UI observes state and effects to render

```mermaid
sequenceDiagram
participant UI as "LoginScreen"
participant VM as "LoginViewModel"
participant UC as "LoginUseCase"
participant IF as "AuthRepository (interface)"
participant IM as "AuthRepositoryImpl"
participant INF as "Firebase Services"
UI->>VM : "EmailChanged / PasswordChanged / Submit"
VM->>VM : "validateAndLogin()"
VM->>UC : "invoke(email, password)"
UC->>IF : "login(...)"
IF-->>IM : "bound implementation"
IM->>INF : "Auth / Firestore calls"
INF-->>IM : "Results"
IM-->>UC : "Flow<UitResult<User>>"
UC-->>VM : "Flow<UitResult<User>>"
VM->>UI : "State updates / Effects"
```

**Diagram sources**
- [LoginScreen.kt:1-126](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginScreen.kt#L1-L126)
- [LoginViewModel.kt:1-100](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L1-L100)
- [LoginUseCase.kt:1-15](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L1-L15)
- [AuthRepository.kt:1-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L1-L14)
- [AuthRepositoryImpl.kt:1-147](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L1-L147)
- [FirebaseAuthService.kt:1-37](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L1-L37)
- [FirestoreService.kt:1-107](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt#L1-L107)

## Dependency Analysis
- Binding and inversion of control
  - DataModule binds AuthRepositoryImpl to AuthRepository for dependency injection
- Cohesion and coupling
  - Domain UseCases depend only on interfaces, reducing coupling to infrastructure
  - Data implementations depend on Firebase services but are abstracted behind interfaces
- External dependencies
  - Firebase Auth and Firestore provide authentication and document persistence
  - Dagger Hilt manages lifecycle-scoped ViewModels and injects dependencies

```mermaid
graph LR
DM["DataModule"] --> BI["bindAuthRepository(...)"]
BI --> IF["AuthRepository (interface)"]
BI --> IM["AuthRepositoryImpl (implementation)"]
IM --> FA["FirebaseAuthService"]
IM --> FS["FirestoreService"]
```

**Diagram sources**
- [DataModule.kt:1-42](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt#L1-L42)
- [AuthRepository.kt:1-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L1-L14)
- [AuthRepositoryImpl.kt:1-147](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L1-L147)
- [FirebaseAuthService.kt:1-37](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/auth/FirebaseAuthService.kt#L1-L37)
- [FirestoreService.kt:1-107](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/firestore/FirestoreService.kt#L1-L107)

**Section sources**
- [DataModule.kt:1-42](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt#L1-L42)
- [AuthRepository.kt:1-14](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L1-L14)
- [AuthRepositoryImpl.kt:1-147](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L1-L147)

## Performance Considerations
- Reactive streams with Flow enable efficient UI updates and backpressure handling
- Mapping operations between DTOs and domain models are lightweight; avoid unnecessary conversions
- Use observeAuthState for real-time updates instead of polling
- Keep ViewModel scopes minimal to reduce memory footprint during navigation

## Troubleshooting Guide
- Error handling with UitResult
  - Presentation layer checks UitResult.Error and displays messages
  - Repository implementations convert Firebase exceptions into UitResult.Error with localized messages
- Common scenarios
  - Invalid credentials: FirebaseAuthInvalidCredentialsException mapped to UitResult.Error
  - Database connectivity issues: FirebaseFirestoreException mapped to UitResult.Error
  - Missing user profile: UitResult.Error with appropriate message
- Testing and verification
  - Replace AuthRepository with a test double to simulate success, error, and loading states
  - Verify ViewModel collects and transforms results correctly

**Section sources**
- [UitResult.kt:1-37](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L1-L37)
- [LoginViewModel.kt:1-100](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L1-L100)
- [AuthRepositoryImpl.kt:1-147](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L1-L147)

## Conclusion
UIT20Years implements Clean Architecture by enforcing strict layer boundaries:
- Presentation remains UI-focused and state-driven
- Domain encapsulates business logic and exposes stable interfaces
- Data implements those interfaces while interacting with Firebase services
- UitResult ensures consistent error handling and loading states across layers
This design improves testability, maintainability, and flexibility, enabling easy substitution of repositories and infrastructure components.
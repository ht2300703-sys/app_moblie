# Contributing Guidelines

<cite>
**Referenced Files in This Document**
- [IMPLEMENTATION_COMPLETE.md](file://IMPLEMENTATION_COMPLETE.md)
- [settings.gradle.kts](file://settings.gradle.kts)
- [build.gradle.kts](file://build.gradle.kts)
- [gradle/libs.versions.toml](file://gradle/libs.versions.toml)
- [app/build.gradle.kts](file://app/build.gradle.kts)
- [build-logic/convention/src/main/kotlin/AndroidFeatureConventionPlugin.kt](file://build-logic/convention/src/main/kotlin/AndroidFeatureConventionPlugin.kt)
- [build-logic/convention/src/main/kotlin/KotlinAndroid.kt](file://build-logic/convention/src/main/kotlin/KotlinAndroid.kt)
- [app/src/main/java/com/uit20years/app/UIT20YearsApplication.kt](file://app/src/main/java/com/uit20years/app/UIT20YearsApplication.kt)
- [app/src/main/java/com/uit20years/app/MainActivity.kt](file://app/src/main/java/com/uit20years/app/MainActivity.kt)
- [core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt)
- [core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt)
- [core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt)
- [feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt)
- [core/core-ui/src/main/java/com/uit20years/core/ui/component/UitButton.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitButton.kt)
- [core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Development Workflow](#development-workflow)
6. [Code Standards and Style Guidelines](#code-sts-and-style-guidelines)
7. [Testing Requirements](#testing-requirements)
8. [Review Process and Approval Criteria](#review-process-and-approval-criteria)
9. [Implementation Guidelines](#implementation-guidelines)
10. [Dependency Analysis](#dependency-analysis)
11. [Performance Considerations](#performance-considerations)
12. [Troubleshooting Guide](#troubleshooting-guide)
13. [Release Process and Versioning](#release-process-and-versioning)
14. [Collaboration Tools and Communication](#collaboration-tools-and-communication)
15. [Appendices](#appendices)

## Introduction
This document defines contribution standards for the UIT20Years Android application. It consolidates development workflow, branching and commit conventions, pull request processes, code style, testing, review, and release practices. The project follows Clean Architecture across core, domain, data, and feature layers, with Jetpack Compose UI, Hilt DI, Firebase integration, and type-safe navigation.

## Project Structure
The project is organized into multi-modules:
- Core modules: shared Kotlin libraries for models, domain, common utilities, UI components, Firebase, media, search, and data.
- Feature modules: UI and business logic per feature, each encapsulated behind navigation and typed routes.
- App module: application shell integrating all features and core modules.
- Build logic: convention plugins for consistent Android/Kotlin configuration and feature scaffolding.

```mermaid
graph TB
subgraph "App Shell"
APP["app"]
end
subgraph "Core Libraries"
CORE_MODEL["core:core-model"]
CORE_COMMON["core:core-common"]
CORE_DOMAIN["core:core-domain"]
CORE_UI["core:core-ui"]
CORE_FIRE["core:core-firebase"]
CORE_MEDIA["core:core-media"]
CORE_SEARCH["core:core-search"]
CORE_DATA["core:core-data"]
end
subgraph "Features"
FEAT_AUTH["feature:feature-auth"]
FEAT_MOMENTS["feature:feature-moments"]
FEAT_EVENTS["feature:feature-events"]
FEAT_HERITAGE["feature:feature-heritage"]
FEAT_PROFILE["feature:feature-profile"]
FEAT_NOTIF["feature:feature-notifications"]
end
APP --> FEAT_AUTH
APP --> FEAT_MOMENTS
APP --> FEAT_EVENTS
APP --> FEAT_HERITAGE
APP --> FEAT_PROFILE
APP --> FEAT_NOTIF
APP --> CORE_DATA
APP --> CORE_UI
APP --> CORE_DOMAIN
APP --> CORE_MODEL
APP --> CORE_COMMON
APP --> CORE_FIRE
APP --> CORE_MEDIA
APP --> CORE_SEARCH
FEAT_AUTH --> CORE_UI
FEAT_AUTH --> CORE_DOMAIN
FEAT_AUTH --> CORE_MODEL
FEAT_AUTH --> CORE_COMMON
FEAT_AUTH --> CORE_FIRE
FEAT_AUTH --> CORE_MEDIA
FEAT_AUTH --> CORE_SEARCH
CORE_DATA --> CORE_DOMAIN
CORE_DATA --> CORE_FIRE
CORE_DATA --> CORE_SEARCH
CORE_DATA --> CORE_MEDIA
CORE_DATA --> CORE_COMMON
```

**Diagram sources**
- [settings.gradle.kts:20-39](file://settings.gradle.kts#L20-L39)
- [app/build.gradle.kts:35-52](file://app/build.gradle.kts#L35-L52)

**Section sources**
- [settings.gradle.kts:18-39](file://settings.gradle.kts#L18-L39)
- [IMPLEMENTATION_COMPLETE.md:72-85](file://IMPLEMENTATION_COMPLETE.md#L72-L85)

## Core Components
- Clean Architecture layers:
  - Core model and common utilities define shared types and helpers.
  - Domain encapsulates business rules via use cases and repository interfaces.
  - Data implements repositories using Firebase and Firestore, mapping DTOs to domain models.
  - UI provides Compose components and Material 3 theming.
  - Features implement screens, navigation, and ViewModels following Unidirectional Data Flow (UDF).
- DI with Hilt across app, core, and features.
- Type-safe navigation using kotlinx.serialization.
- Consistent build configuration via convention plugins.

**Section sources**
- [IMPLEMENTATION_COMPLETE.md:72-94](file://IMPLEMENTATION_COMPLETE.md#L72-L94)
- [core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt:1-15](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/usecase/auth/LoginUseCase.kt#L1-L15)
- [core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt:1-147](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L1-L147)
- [core/core-ui/src/main/java/com/uit20years/core/ui/component/UitButton.kt:1-42](file://core/core-ui/src/main/java/com/uit20years/core/ui/component/UitButton.kt#L1-L42)
- [core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt:1-37](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L1-L37)

## Architecture Overview
Clean Architecture with layered responsibilities and unidirectional data flow:
- Domain: Use cases and repository interfaces.
- Data: Repository implementations backed by Firebase and Firestore.
- UI: Compose screens and components with Material 3 theming.
- App: Application class, Activity entry point, and navigation host.

```mermaid
graph TB
DOMAIN["core-domain<br/>Use cases, Repositories"]
DATA["core-data<br/>Repository impl, DTOs, Mappers"]
FIRE["core-firebase<br/>Auth, Firestore, Storage, FCM"]
SEARCH["core-search<br/>SearchService"]
MEDIA["core-media<br/>ImageCompressor, MediaUploader"]
UI["core-ui<br/>Components, Theme"]
MODEL["core-model<br/>Domain models"]
COMMON["core-common<br/>Extensions, Result, Dispatchers"]
FEAT_AUTH["feature-auth<br/>ViewModel, Screen, Navigation"]
APP["app<br/>Application, MainActivity, NavHost"]
FEAT_AUTH --> DOMAIN
FEAT_AUTH --> UI
FEAT_AUTH --> MODEL
FEAT_AUTH --> COMMON
APP --> FEAT_AUTH
APP --> DATA
APP --> UI
APP --> DOMAIN
APP --> MODEL
APP --> COMMON
APP --> FIRE
APP --> SEARCH
APP --> MEDIA
DATA --> DOMAIN
DATA --> FIRE
DATA --> SEARCH
DATA --> MEDIA
DATA --> COMMON
```

**Diagram sources**
- [IMPLEMENTATION_COMPLETE.md:72-85](file://IMPLEMENTATION_COMPLETE.md#L72-L85)
- [app/src/main/java/com/uit20years/app/UIT20YearsApplication.kt:1-8](file://app/src/main/java/com/uit20years/app/UIT20YearsApplication.kt#L1-L8)
- [app/src/main/java/com/uit20years/app/MainActivity.kt:1-28](file://app/src/main/java/com/uit20years/app/MainActivity.kt#L1-L28)

## Development Workflow
- Branching model:
  - main: protected, release-ready.
  - develop: integration branch for features.
  - feature/<issue-number>-short-description: feature work.
  - fix/<issue-number>-short-description: bug fixes.
  - hotfix/<issue-number>-short-description: emergency releases.
- Commit message standards:
  - Use present tense, imperative mood.
  - Prefix with module or area: core:, feature:, app:, build-logic:.
  - Include issue reference when applicable: feat(core): add result wrapper [GH-123].
- Pull Request process:
  - Open PR against develop.
  - Assign reviewers; ensure CI passes and review comments are addressed.
  - Squash and merge after approval; keep history clean.

[No sources needed since this section provides general guidance]

## Code Standards and Style Guidelines
- Kotlin best practices:
  - Prefer immutable data structures; use sealed interfaces for state machines.
  - Leverage Kotlin coroutines and Flow for reactive streams.
  - Use meaningful names; avoid abbreviations except common ones.
- Clean Architecture:
  - Keep domain free of framework dependencies.
  - Data layer depends on domain interfaces; implement in data module.
- Android conventions:
  - Follow minSdk/targetSdk as configured in convention plugins.
  - Use Material 3 theming and Compose components from core-ui.
- Naming conventions:
  - Packages: com.uit20years.<layer>.<module>
  - Classes: PascalCase; Interfaces: Name; Sealed/Abstract: Name
  - Files: Match primary class name
- Formatting:
  - Use Kotlin formatting rules enforced by IDE; align with project’s KSP and Compose compiler versions.

**Section sources**
- [build-logic/convention/src/main/kotlin/KotlinAndroid.kt:7-28](file://build-logic/convention/src/main/kotlin/KotlinAndroid.kt#L7-L28)
- [gradle/libs.versions.toml:1-103](file://gradle/libs.versions.toml#L1-L103)

## Testing Requirements
- Unit tests:
  - Test ViewModels and UseCases with coroutines and Flow assertions.
  - Use MockK for mocks and Turbine for Flow testing.
- Instrumented tests:
  - Verify navigation and basic UI flows on device/emulator.
- Test commands:
  - Build and assembleDebug.
  - Hilt DI verification via KSP tasks.
  - Install debug APK to device/emulator.

**Section sources**
- [IMPLEMENTATION_COMPLETE.md:149-160](file://IMPLEMENTATION_COMPLETE.md#L149-L160)
- [gradle/libs.versions.toml:75-79](file://gradle/libs.versions.toml#L75-L79)

## Review Process and Approval Criteria
- Review checklist:
  - Code adheres to style and architecture guidelines.
  - Tests included and passing locally.
  - No hardcoded secrets; Firebase config handled via google-services.json.
  - Changes scoped to the feature or fix; minimal diffs.
- Approval:
  - At least one maintainer approval required.
  - Ensure CI checks pass and branch protection rules are satisfied.

[No sources needed since this section provides general guidance]

## Implementation Guidelines
- New feature module:
  - Create feature/<name> module using convention plugin.
  - Add navigation graph and typed routes.
  - Implement ViewModel with UDF; expose StateFlow and effects channel.
  - Reuse core-ui components and theming.
- Extending existing modules:
  - Add use cases to core-domain; add repository interfaces to domain and implementations to core-data.
  - Map DTOs to domain models and vice versa.
  - Wire DI via @Binds in DataModule.
- Adding core modules:
  - Place shared logic in core-common, core-model, core-ui.
  - Integrate via convention plugins and module dependencies.
- Build logic plugins:
  - Use convention plugins for consistent Android/Kotlin configuration.
  - Apply uit.android.feature for feature modules; include core dependencies automatically.

**Section sources**
- [build-logic/convention/src/main/kotlin/AndroidFeatureConventionPlugin.kt:1-28](file://build-logic/convention/src/main/kotlin/AndroidFeatureConventionPlugin.kt#L1-L28)
- [core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt:1-42](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt#L1-L42)

## Dependency Analysis
- Module dependencies:
  - Core modules depend on core-common and core-model.
  - Data depends on domain, Firebase, Search, and Media.
  - Features depend on core-ui, core-domain, core-model, core-common, plus lifecycle and navigation.
  - App depends on all features and core modules.
- External dependencies:
  - Managed via version catalog; BOM for Firebase; Compose BOM for UI.

```mermaid
graph LR
CORE_COMMON["core-common"]
CORE_MODEL["core-model"]
CORE_DOMAIN["core-domain"]
CORE_UI["core-ui"]
CORE_FIRE["core-firebase"]
CORE_MEDIA["core-media"]
CORE_SEARCH["core-search"]
CORE_DATA["core-data"]
FEAT_AUTH["feature-auth"]
FEAT_MOMENTS["feature-moments"]
FEAT_EVENTS["feature-events"]
FEAT_HERITAGE["feature-heritage"]
FEAT_PROFILE["feature-profile"]
FEAT_NOTIF["feature-notifications"]
APP["app"]
CORE_UI --> CORE_COMMON
CORE_DOMAIN --> CORE_MODEL
CORE_DOMAIN --> CORE_COMMON
CORE_DATA --> CORE_DOMAIN
CORE_DATA --> CORE_FIRE
CORE_DATA --> CORE_SEARCH
CORE_DATA --> CORE_MEDIA
CORE_DATA --> CORE_COMMON
FEAT_AUTH --> CORE_UI
FEAT_AUTH --> CORE_DOMAIN
FEAT_AUTH --> CORE_MODEL
FEAT_AUTH --> CORE_COMMON
FEAT_AUTH --> CORE_FIRE
FEAT_AUTH --> CORE_MEDIA
FEAT_AUTH --> CORE_SEARCH
APP --> FEAT_AUTH
APP --> FEAT_MOMENTS
APP --> FEAT_EVENTS
APP --> FEAT_HERITAGE
APP --> FEAT_PROFILE
APP --> FEAT_NOTIF
APP --> CORE_DATA
APP --> CORE_UI
APP --> CORE_DOMAIN
APP --> CORE_MODEL
APP --> CORE_COMMON
```

**Diagram sources**
- [IMPLEMENTATION_COMPLETE.md:74-84](file://IMPLEMENTATION_COMPLETE.md#L74-L84)
- [settings.gradle.kts:20-39](file://settings.gradle.kts#L20-L39)
- [app/build.gradle.kts:35-52](file://app/build.gradle.kts#L35-L52)

**Section sources**
- [IMPLEMENTATION_COMPLETE.md:74-84](file://IMPLEMENTATION_COMPLETE.md#L74-L84)
- [settings.gradle.kts:20-39](file://settings.gradle.kts#L20-L39)

## Performance Considerations
- Minimize allocations in UI; reuse Compose components from core-ui.
- Use Flow and StateFlow efficiently; avoid unnecessary recompositions.
- Offload heavy work to IO dispatchers; avoid main thread blocking.
- Enable ProGuard/R8 in release builds; keep resources lean.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
- Build failures:
  - Verify Kotlin and KSP versions match the version catalog.
  - Ensure Compose compiler plugin and BOM versions are aligned.
- DI errors:
  - Confirm @HiltAndroidApp on Application and @AndroidEntryPoint on Activities.
  - Ensure @Binds methods are present for all repository interfaces.
- Firebase configuration:
  - Replace placeholder google-services.json with your project’s config.
- Runtime issues:
  - Use Timber for logging; verify network permissions and FCM setup.

**Section sources**
- [gradle/libs.versions.toml:1-103](file://gradle/libs.versions.toml#L1-L103)
- [app/src/main/java/com/uit20years/app/UIT20YearsApplication.kt:1-8](file://app/src/main/java/com/uit20years/app/UIT20YearsApplication.kt#L1-L8)
- [app/src/main/java/com/uit20years/app/MainActivity.kt:1-28](file://app/src/main/java/com/uit20years/app/MainActivity.kt#L1-L28)

## Release Process and Versioning
- Versioning:
  - Follow semantic versioning; update versionCode and versionName in app module.
- Release preparation:
  - Merge develop into main; tag commit with vX.Y.Z.
  - Build release APK/AAB using assembleRelease.
- Deployment:
  - Upload signed artifacts to distribution channels.
  - Update changelog and notify stakeholders.

[No sources needed since this section provides general guidance]

## Collaboration Tools and Communication
- Issue tracking: Use GitHub Issues with labels (feature, bug, refactor).
- Code reviews: Use GitHub Pull Requests with review requests.
- CI/CD: Configure automated checks for builds, lint, and tests.
- Communication: Slack/Discord channel for sync-ups; stand-ups as needed.

[No sources needed since this section provides general guidance]

## Appendices
- Setup checklist:
  - Install JDK 17; Android Studio with Compose compiler plugin.
  - Sync Gradle with libs.versions.toml.
  - Replace google-services.json with your Firebase config.
  - Run ./gradlew assembleDebug and ./gradlew installDebug.
- Quick references:
  - Login flow demonstrates UDF with ViewModel, UseCase, Repository, and UI components.
  - AuthRepositoryImpl shows repository pattern with error handling and Firebase callbacks.

**Section sources**
- [IMPLEMENTATION_COMPLETE.md:149-160](file://IMPLEMENTATION_COMPLETE.md#L149-L160)
- [feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt:1-100](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L1-L100)
- [core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt:1-147](file://core/core-data/src/main/java/com/uit20years/core/data/repository/AuthRepositoryImpl.kt#L1-L147)
- [core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt:1-37](file://core/core-common/src/main/kotlin/com/uit20years/core/common/result/UitResult.kt#L1-L37)
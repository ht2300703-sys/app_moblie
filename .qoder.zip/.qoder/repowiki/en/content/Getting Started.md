# Getting Started

<cite>
**Referenced Files in This Document**
- [settings.gradle.kts](file://settings.gradle.kts)
- [build.gradle.kts](file://build.gradle.kts)
- [gradle.properties](file://gradle.properties)
- [gradle/libs.versions.toml](file://gradle/libs.versions.toml)
- [build-logic/settings.gradle.kts](file://build-logic/settings.gradle.kts)
- [build-logic/convention/src/main/kotlin/KotlinAndroid.kt](file://build-logic/convention/src/main/kotlin/KotlinAndroid.kt)
- [build-logic/convention/src/main/kotlin/AndroidApplicationConventionPlugin.kt](file://build-logic/convention/src/main/kotlin/AndroidApplicationConventionPlugin.kt)
- [build-logic/convention/src/main/kotlin/AndroidHiltConventionPlugin.kt](file://build-logic/convention/src/main/kotlin/AndroidHiltConventionPlugin.kt)
- [app/build.gradle.kts](file://app/build.gradle.kts)
- [app/google-services.json](file://app/google-services.json)
- [app/src/main/java/com/uit20years/app/UIT20YearsApplication.kt](file://app/src/main/java/com/uit20years/app/UIT20YearsApplication.kt)
- [app/src/main/java/com/uit20years/app/MainActivity.kt](file://app/src/main/java/com/uit20years/app/MainActivity.kt)
- [app/src/main/AndroidManifest.xml](file://app/src/main/AndroidManifest.xml)
- [core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt)
- [core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt)
- [app/src/main/java/com/uit20years/app/di/DispatcherModule.kt](file://app/src/main/java/com/uit20years/app/di/DispatcherModule.kt)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Prerequisites and Environment Setup](#prerequisites-and-environment-setup)
3. [Development Environment Setup](#development-environment-setup)
4. [Cloning the Repository](#cloning-the-repository)
5. [Firebase Services Configuration](#firebase-services-configuration)
6. [Building and Running Locally](#building-and-running-locally)
7. [Verifying Hilt Dependency Injection](#verifying-hilt-dependency-injection)
8. [Project Structure Overview](#project-structure-overview)
9. [Common Issues and Troubleshooting](#common-issues-and-troubleshooting)
10. [Conclusion](#conclusion)

## Introduction
This guide helps you set up and run the UIT20Years Android application locally. It covers environment prerequisites, Android Studio configuration, Gradle and version catalog setup, Firebase configuration, and step-by-step instructions to build, test, and run the app on devices or emulators. It also includes troubleshooting tips for common setup and build issues.

## Prerequisites and Environment Setup
- Operating system: Windows, macOS, or Linux
- Android Studio: Arctic Fox or later recommended
- Android SDK: Minimum SDK 24, Compile SDK 35
- JDK: Java 17 (required for Kotlin/JVM target compatibility)
- Android Gradle Plugin (AGP): 8.7.3
- Kotlin: 2.0.21
- Hilt: 2.53.1
- Firebase BoM: 33.7.0
- Compose BOM: 2024.12.01
- KSP: 2.0.21-1.0.28

Notes:
- The project enforces AndroidX and uses non-transitive R classes.
- The project enables Gradle parallelism and caching for performance.

**Section sources**
- [gradle.properties:1-8](file://gradle.properties#L1-L8)
- [gradle/libs.versions.toml:1-18](file://gradle/libs.versions.toml#L1-L18)
- [build-logic/convention/src/main/kotlin/KotlinAndroid.kt:10-27](file://build-logic/convention/src/main/kotlin/KotlinAndroid.kt#L10-L27)

## Development Environment Setup
- Install Android Studio with the latest Android SDK and SDK Tools.
- Configure the JDK to Java 17 in Android Studio:
  - Open Android Studio > Settings > Build, Execution, Deployment > Gradle > Gradle JDK and select JDK 17.
- Ensure Android Studio uses the embedded Gradle distribution or a compatible Gradle wrapper.
- Sync the project to apply version catalogs and plugins.

Key Gradle and plugin versions used by the project:
- AGP: 8.7.3
- Kotlin: 2.0.21
- KSP: 2.0.21-1.0.28
- Compose Compiler: 2.0.21
- Hilt: 2.53.1
- Firebase BoM: 33.7.0
- Google Services Gradle Plugin: 4.4.2

**Section sources**
- [gradle/libs.versions.toml:2-17](file://gradle/libs.versions.toml#L2-L17)
- [gradle/libs.versions.toml:94-102](file://gradle/libs.versions.toml#L94-L102)
- [build-logic/convention/src/main/kotlin/KotlinAndroid.kt:17-20](file://build-logic/convention/src/main/kotlin/KotlinAndroid.kt#L17-L20)

## Cloning the Repository
- Clone the repository to your local machine using Git.
- Open the project in Android Studio.
- Allow Android Studio to sync Gradle and apply the version catalog.

Verification steps:
- Confirm that the project builds successfully after sync.
- Ensure the build-logic convention plugins are recognized.

**Section sources**
- [settings.gradle.kts:1-39](file://settings.gradle.kts#L1-L39)
- [build-logic/settings.gradle.kts:1-15](file://build-logic/settings.gradle.kts#L1-L15)

## Firebase Services Configuration
- Obtain your Firebase project configuration file from the Firebase Console.
- Replace the placeholder google-services.json in the app module with your actual configuration file.
- Ensure the package name matches com.uit20years.app.

What the app expects:
- The manifest declares internet permissions and registers the Firebase Cloud Messaging service.
- The app module includes the Google Services Gradle plugin and depends on Firebase BoM libraries.

Important note:
- The placeholder google-services.json currently contains placeholder values. Replace it with your Firebase configuration before running.

**Section sources**
- [app/google-services.json:1-30](file://app/google-services.json#L1-L30)
- [app/src/main/AndroidManifest.xml:1-40](file://app/src/main/AndroidManifest.xml#L1-L40)
- [app/build.gradle.kts:6-7](file://app/build.gradle.kts#L6-L7)
- [gradle/libs.versions.toml:51-57](file://gradle/libs.versions.toml#L51-L57)

## Building and Running Locally
- Connect an Android device via USB or start an emulator with API level 35 or higher.
- In Android Studio, select a connected device or emulator from the target device dropdown.
- Build the project:
  - From the menu: Build > Make Project.
  - Or use the Gradle task: ./gradlew assembleDebug
- Run the app:
  - Click the Run button in Android Studio.
  - Or use the Gradle task: ./gradlew :app:installDebug
- Verify the app launches and displays the main screen.

Optional verification commands:
- Clean build: ./gradlew clean
- Unit tests: ./gradlew test
- Instrumented tests: ./gradlew connectedAndroidTest
- Lint checks: ./gradlew lint

**Section sources**
- [app/src/main/java/com/uit20years/app/MainActivity.kt:14-27](file://app/src/main/java/com/uit20years/app/MainActivity.kt#L14-L27)
- [app/src/main/java/com/uit20years/app/UIT20YearsApplication.kt:6-7](file://app/src/main/java/com/uit20years/app/UIT20YearsApplication.kt#L6-L7)
- [app/src/main/AndroidManifest.xml:18-27](file://app/src/main/AndroidManifest.xml#L18-L27)

## Verifying Hilt Dependency Injection
The project uses Hilt for dependency injection across modules. To verify Hilt is working:

- Confirm the application class is annotated to initialize Hilt:
  - See [UIT20YearsApplication.kt:6-7](file://app/src/main/java/com/uit20years/app/UIT20YearsApplication.kt#L6-L7).
- Confirm the main activity is annotated as an entry point:
  - See [MainActivity.kt:14-14](file://app/src/main/java/com/uit20years/app/MainActivity.kt#L14-L14).
- Verify Hilt plugins and dependencies are applied in the app module:
  - See [app/build.gradle.kts:1-7](file://app/build.gradle.kts#L1-L7) and dependencies around lines [67-L71].
- Confirm Hilt convention plugins are configured:
  - See [AndroidHiltConventionPlugin.kt:9-16](file://build-logic/convention/src/main/kotlin/AndroidHiltConventionPlugin.kt#L9-L16).

Key DI modules present:
- Dispatcher module provides coroutine dispatchers:
  - See [DispatcherModule.kt:17-26](file://app/src/main/java/com/uit20years/app/di/DispatcherModule.kt#L17-L26).
- Data module binds domain repositories to implementations:
  - See [DataModule.kt:24-41](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt#L24-L41).
- Firebase module provides Firebase services:
  - See [FirebaseModule.kt:16-27](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt#L16-L27).

To test DI resolution:
- Add a simple injectable class in a feature or core module.
- Inject it into the main activity or a ViewModel.
- Run the app and confirm no injection errors in logs.

```mermaid
classDiagram
class UIT20YearsApplication {
+initializeHilt()
}
class MainActivity {
+@AndroidEntryPoint
+setContent()
}
class DispatcherModule {
+providesIoDispatcher()
+providesDefaultDispatcher()
}
class DataModule {
+bindAuthRepository()
+bindUserRepository()
+bindPostRepository()
+bindEventRepository()
+bindHeritageRepository()
+bindNotificationRepository()
}
class FirebaseModule {
+provideFirebaseAuth()
+provideFirebaseFirestore()
+provideFirebaseStorage()
}
UIT20YearsApplication --> MainActivity : "launches"
MainActivity --> DispatcherModule : "uses injected dispatchers"
MainActivity --> DataModule : "uses repositories"
MainActivity --> FirebaseModule : "uses Firebase services"
```

**Diagram sources**
- [app/src/main/java/com/uit20years/app/UIT20YearsApplication.kt:6-7](file://app/src/main/java/com/uit20years/app/UIT20YearsApplication.kt#L6-L7)
- [app/src/main/java/com/uit20years/app/MainActivity.kt:14-14](file://app/src/main/java/com/uit20years/app/MainActivity.kt#L14-L14)
- [app/src/main/java/com/uit20years/app/di/DispatcherModule.kt:17-26](file://app/src/main/java/com/uit20years/app/di/DispatcherModule.kt#L17-L26)
- [core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt:24-41](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt#L24-L41)
- [core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt:16-27](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt#L16-L27)

**Section sources**
- [app/src/main/java/com/uit20years/app/UIT20YearsApplication.kt:6-7](file://app/src/main/java/com/uit20years/app/UIT20YearsApplication.kt#L6-L7)
- [app/src/main/java/com/uit20years/app/MainActivity.kt:14-14](file://app/src/main/java/com/uit20years/app/MainActivity.kt#L14-L14)
- [app/build.gradle.kts:67-71](file://app/build.gradle.kts#L67-L71)
- [build-logic/convention/src/main/kotlin/AndroidHiltConventionPlugin.kt:9-16](file://build-logic/convention/src/main/kotlin/AndroidHiltConventionPlugin.kt#L9-L16)
- [app/src/main/java/com/uit20years/app/di/DispatcherModule.kt:17-26](file://app/src/main/java/com/uit20years/app/di/DispatcherModule.kt#L17-L26)
- [core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt:24-41](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt#L24-L41)
- [core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt:16-27](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt#L16-L27)

## Project Structure Overview
The project follows a modular architecture with an app module and multiple feature and core modules. The build system uses Gradle with version catalogs and convention plugins to standardize configurations.

```mermaid
graph TB
subgraph "App Module"
APP["app"]
MAIN["MainActivity"]
APPAPP["UIT20YearsApplication"]
end
subgraph "Core Modules"
CORE_COMMON["core:core-common"]
CORE_MODEL["core:core-model"]
CORE_DOMAIN["core:core-domain"]
CORE_DATA["core:core-data"]
CORE_FIREBASE["core:core-firebase"]
CORE_SEARCH["core:core-search"]
CORE_MEDIA["core:core-media"]
CORE_UI["core:core-ui"]
end
subgraph "Feature Modules"
FEAT_AUTH["feature:feature-auth"]
FEAT_MOMENTS["feature:feature-moments"]
FEAT_EVENTS["feature:feature-events"]
FEAT_HERITAGE["feature:feature-heritage"]
FEAT_PROFILE["feature:feature-profile"]
FEAT_NOTIF["feature:feature-notifications"]
end
APP --> FEAT_AUTH
APP --> FEAT_MOMENTS
APP --> FEAT_EVENTS
APP --> FEAT_HERITAGE
APP --> FEAT_PROFILE
APP --> FEAT_NOTIF
APP --> CORE_DATA
APP --> CORE_FIREBASE
APP --> CORE_SEARCH
APP --> CORE_MEDIA
APP --> CORE_UI
APP --> CORE_DOMAIN
APP --> CORE_MODEL
APP --> CORE_COMMON
MAIN --> APPAPP
```

**Diagram sources**
- [settings.gradle.kts:20-39](file://settings.gradle.kts#L20-L39)
- [app/build.gradle.kts:35-53](file://app/build.gradle.kts#L35-L53)

**Section sources**
- [settings.gradle.kts:20-39](file://settings.gradle.kts#L20-L39)
- [app/build.gradle.kts:35-53](file://app/build.gradle.kts#L35-L53)

## Common Issues and Troubleshooting
- Gradle sync fails or cannot resolve plugins:
  - Ensure the version catalog is loaded by the build-logic settings.
  - Confirm pluginManagement and repositories are correctly configured.
  - Rebuild the project after fixing catalog loading.
  - Reference: [build-logic/settings.gradle.kts:1-15](file://build-logic/settings.gradle.kts#L1-L15), [settings.gradle.kts:1-16](file://settings.gradle.kts#L1-L16)

- Java version mismatch:
  - Set Gradle JDK to Java 17 in Android Studio.
  - Verify Kotlin/JVM target aligns with Java 17.
  - Reference: [KotlinAndroid.kt:17-26](file://build-logic/convention/src/main/kotlin/KotlinAndroid.kt#L17-L26)

- Firebase configuration missing:
  - Replace the placeholder google-services.json with your Firebase configuration.
  - Ensure the package name matches com.uit20years.app.
  - Reference: [app/google-services.json:1-30](file://app/google-services.json#L1-L30), [app/src/main/AndroidManifest.xml:18-27](file://app/src/main/AndroidManifest.xml#L18-L27)

- Hilt errors at runtime:
  - Confirm @HiltAndroidApp is applied to the Application class.
  - Confirm @AndroidEntryPoint is applied to activities using DI.
  - Ensure Hilt Gradle plugin and KSP are applied in the app module.
  - Reference: [UIT20YearsApplication.kt:6-7](file://app/src/main/java/com/uit20years/app/UIT20YearsApplication.kt#L6-L7), [MainActivity.kt:14-14](file://app/src/main/java/com/uit20years/app/MainActivity.kt#L14-L14), [app/build.gradle.kts:1-7](file://app/build.gradle.kts#L1-L7)

- Build type differences:
  - Debug suffix is applied in debug builds; release enables minification.
  - Reference: [app/build.gradle.kts:20-32](file://app/build.gradle.kts#L20-L32)

- Target SDK and permissions:
  - Compile SDK is 35; minimum SDK is 24.
  - Internet and network state permissions are declared.
  - Reference: [AndroidApplicationConventionPlugin.kt:15-16](file://build-logic/convention/src/main/kotlin/AndroidApplicationConventionPlugin.kt#L15-L16), [AndroidManifest.xml:5-6](file://app/src/main/AndroidManifest.xml#L5-L6)

## Conclusion
You now have the essential steps to set up the UIT20Years project, configure Firebase, and run the app locally. Use the provided references to verify your environment and resolve common issues. For advanced customization, explore the modular structure and DI modules defined across the app and core modules.
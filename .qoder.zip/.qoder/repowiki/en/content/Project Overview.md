# Project Overview

<cite>
**Referenced Files in This Document**
- [IMPLEMENTATION_COMPLETE.md](file://IMPLEMENTATION_COMPLETE.md)
- [settings.gradle.kts](file://settings.gradle.kts)
- [build.gradle.kts](file://build.gradle.kts)
- [gradle/libs.versions.toml](file://gradle/libs.versions.toml)
- [app/src/main/java/com/uit20years/app/UIT20YearsApplication.kt](file://app/src/main/java/com/uit20years/app/UIT20YearsApplication.kt)
- [app/src/main/java/com/uit20years/app/MainActivity.kt](file://app/src/main/java/com/uit20years/app/MainActivity.kt)
- [app/src/main/java/com/uit20years/app/navigation/Route.kt](file://app/src/main/java/com/uit20years/app/navigation/Route.kt)
- [app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt](file://app/src/main/java/com/uit20years/app/navigation/AppNavHost.kt)
- [core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt)
- [core/core-data/src/main/java/com/uit20years/core/data/dto/UserDto.kt](file://core/core-data/src/main/java/com/uit20years/core/data/dto/UserDto.kt)
- [core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt)
- [core/core-ui/src/main/java/com/uit20years/core/ui/theme/Theme.kt](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Theme.kt)
- [feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt)
- [core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt)
- [core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt)
- [core/core-common/src/main/kotlin/com/uit20years/core/common/constants/AppConstants.kt](file://core/core-common/src/main/kotlin/com/uit20years/core/common/constants/AppConstants.kt)
- [build-logic/convention/src/main/kotlin/KotlinAndroid.kt](file://build-logic/convention/src/main/kotlin/KotlinAndroid.kt)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
UIT20Years is a multi-platform celebration project designed to bring together the University of Information Technology community as part of its 20-year anniversary. The Android application serves as a social networking platform tailored for students, alumni, staff, and faculty, enabling connection, sharing, and participation in campus events and heritage moments. The project follows a modern Android architecture with a strong emphasis on clean architecture, testability, and developer productivity.

Key goals:
- Provide a unified digital space for the UIT community.
- Showcase institutional milestones and stories through curated content.
- Enable secure user onboarding and engagement via authentication and notifications.
- Deliver a responsive, accessible, and visually cohesive user experience using Jetpack Compose.

## Project Structure
The project is organized into a multi-module Gradle build with a clear separation of concerns across core libraries, feature modules, and the application shell. The structure supports scalability, maintainability, and team collaboration.

Modules overview:
- Core modules (pure Kotlin or Android): Shared models, domain logic, data layer, Firebase integration, media handling, search, UI foundation, and common utilities.
- Feature modules: Independent UI and business logic for specific capabilities such as authentication, events, heritage, moments, notifications, and profiles.
- App module: Application shell integrating all features, navigation, and DI setup.

```mermaid
graph TB
subgraph "App Shell"
APP["app"]
end
subgraph "Core Libraries"
CORE_MODEL["core-model"]
CORE_COMMON["core-common"]
CORE_DOMAIN["core-domain"]
CORE_UI["core-ui"]
CORE_DATA["core-data"]
CORE_FIREBASE["core-firebase"]
CORE_MEDIA["core-media"]
CORE_SEARCH["core-search"]
end
subgraph "Features"
FEAT_AUTH["feature-auth"]
FEAT_EVENTS["feature-events"]
FEAT_HERITAGE["feature-heritage"]
FEAT_MOMENTS["feature-moments"]
FEAT_NOTIFICATIONS["feature-notifications"]
FEAT_PROFILE["feature-profile"]
end
APP --> FEAT_AUTH
APP --> FEAT_EVENTS
APP --> FEAT_HERITAGE
APP --> FEAT_MOMENTS
APP --> FEAT_NOTIFICATIONS
APP --> FEAT_PROFILE
CORE_DATA --> CORE_DOMAIN
CORE_DATA --> CORE_FIREBASE
CORE_DATA --> CORE_SEARCH
CORE_DATA --> CORE_MEDIA
CORE_UI --> CORE_COMMON
CORE_DOMAIN --> CORE_MODEL
CORE_DOMAIN --> CORE_COMMON
```

**Diagram sources**
- [settings.gradle.kts:20-39](file://settings.gradle.kts#L20-L39)
- [IMPLEMENTATION_COMPLETE.md:74-85](file://IMPLEMENTATION_COMPLETE.md#L74-L85)

**Section sources**
- [settings.gradle.kts:18-39](file://settings.gradle.kts#L18-L39)
- [IMPLEMENTATION_COMPLETE.md:72-85](file://IMPLEMENTATION_COMPLETE.md#L72-L85)

## Core Components
This section highlights the foundational building blocks that define the application’s capabilities and design.

- Authentication and user management
  - Domain repository defines login, register, logout, and auth state observation contracts.
  - Data layer implements repositories backed by Firebase services.
  - UI layer provides login and registration screens with validation and state management.

- Data models and DTOs
  - Rich domain model with roles and metadata.
  - Firestore-compatible DTOs with server timestamps and defaults for robust deserialization.

- UI foundation and theming
  - Material 3-based theme with UIT brand colors and adaptive dark/light palettes.
  - Reusable Compose components for consistent UX.

- Media and search support
  - Media compression and upload utilities.
  - Search service abstraction ready for Algolia integration.

- Navigation and routing
  - Type-safe navigation using kotlinx.serialization with sealed routes.

**Section sources**
- [core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt:7-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L7-L13)
- [core/core-data/src/main/java/com/uit20years/core/data/dto/UserDto.kt:6-18](file://core/core-data/src/main/java/com/uit20years/core/data/dto/UserDto.kt#L6-L18)
- [core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt:3-15](file://core/core-model/src/main/kotlin/com/uit20years/core/model/User.kt#L3-L15)
- [core/core-ui/src/main/java/com/uit20years/core/ui/theme/Theme.kt:15-55](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Theme.kt#L15-L55)
- [core/core-common/src/main/kotlin/com/uit20years/core/common/constants/AppConstants.kt:3-12](file://core/core-common/src/main/kotlin/com/uit20years/core/common/constants/AppConstants.kt#L3-L12)
- [app/src/main/java/com/uit20years/app/navigation/Route.kt:5-12](file://app/src/main/java/com/uit20years/app/navigation/Route.kt#L5-L12)

## Architecture Overview
The application adheres to clean architecture principles, separating concerns into layers:
- Presentation: Jetpack Compose UI with Unidirectional Data Flow (UDF) in ViewModels.
- Domain: Use cases and repository interfaces encapsulate business logic.
- Data: Repository implementations backed by Firebase, with DTOs and mappers for domain conversion.
- Infrastructure: Firebase services, media utilities, and search service abstractions.

Design patterns and practices:
- Unidirectional Data Flow: ViewModels manage UI state and emit effects for navigation and actions.
- Repository pattern: Abstractions isolate data sources and centralize error handling.
- Hilt dependency injection: Provides modules for Firebase, data repositories, and media/search services.
- Type-safe navigation: Sealed route classes with serialization for robust navigation.
- Firebase callbackFlow pattern: Real-time listeners integrated with coroutines.

```mermaid
graph TB
subgraph "Presentation"
VM["LoginViewModel"]
UI["LoginScreen<br/>RegisterScreen"]
end
subgraph "Domain"
UC["LoginUseCase<br/>RegisterUseCase"]
REPO_IF["AuthRepository (interface)"]
end
subgraph "Data"
REPO_IMPL["AuthRepositoryImpl"]
DTO["UserDto"]
MAPPER["UserMapper"]
end
subgraph "Infrastructure"
FB_AUTH["FirebaseAuthService"]
FB_STORE["FirestoreService"]
FB_STORAGE["FirebaseStorageService"]
MEDIA["MediaUploader"]
SEARCH["SearchService (Algolia stub)"]
end
UI --> VM
VM --> UC
UC --> REPO_IF
REPO_IF --> REPO_IMPL
REPO_IMPL --> DTO
DTO --> MAPPER
REPO_IMPL --> FB_AUTH
REPO_IMPL --> FB_STORE
REPO_IMPL --> FB_STORAGE
REPO_IMPL --> MEDIA
REPO_IMPL --> SEARCH
```

**Diagram sources**
- [feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt:20-99](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L20-L99)
- [core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt:7-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L7-L13)
- [core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt:20-41](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt#L20-L41)
- [core/core-data/src/main/java/com/uit20years/core/data/dto/UserDto.kt:6-18](file://core/core-data/src/main/java/com/uit20years/core/data/dto/UserDto.kt#L6-L18)
- [core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt:12-27](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt#L12-L27)

**Section sources**
- [IMPLEMENTATION_COMPLETE.md:87-94](file://IMPLEMENTATION_COMPLETE.md#L87-L94)
- [feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt:31-94](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L31-L94)

## Detailed Component Analysis

### Authentication Flow (Login)
The login flow demonstrates UDF, validation, and navigation effects. It collects results from the domain use case and updates UI state accordingly, emitting navigation effects upon success.

```mermaid
sequenceDiagram
participant User as "User"
participant Screen as "LoginScreen"
participant VM as "LoginViewModel"
participant UseCase as "LoginUseCase"
participant Repo as "AuthRepository"
participant Firebase as "FirebaseAuthService"
User->>Screen : "Enter credentials"
Screen->>VM : "LoginEvent.Submit"
VM->>VM : "validateAndLogin()"
VM->>UseCase : "invoke(email, password)"
UseCase->>Repo : "login(...)"
Repo->>Firebase : "signInWithEmailAndPassword(...)"
Firebase-->>Repo : "Result<User>"
Repo-->>UseCase : "Flow<UitResult<User>>"
UseCase-->>VM : "Flow<UitResult<User>>"
VM->>VM : "Update UI state"
VM-->>Screen : "Effect.NavigateToHome"
```

**Diagram sources**
- [feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt:31-94](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L31-L94)
- [core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt:7-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L7-L13)

**Section sources**
- [feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt:1-100](file://feature/feature-auth/src/main/java/com/uit20years/feature/auth/login/LoginViewModel.kt#L1-L100)

### Data Layer and Repositories
The data layer binds domain repositories to their implementations using Hilt. Repositories integrate Firebase services for authentication, Firestore for persistence, and storage for media.

```mermaid
classDiagram
class AuthRepository {
<<interface>>
+login(email, password) Flow~UitResult<User>~
+register(email, password, displayName) Flow~UitResult<User>~
+logout() Flow~UitResult<Unit>~
+observeAuthState() Flow~User?~
+getCurrentUser() suspend User?
}
class AuthRepositoryImpl {
+login(...)
+register(...)
+logout()
+observeAuthState()
+getCurrentUser()
}
class DataModule {
+bindAuthRepository(AuthRepositoryImpl) AuthRepository
+bindUserRepository(UserRepositoryImpl) UserRepository
+bindPostRepository(PostRepositoryImpl) PostRepository
+bindEventRepository(EventRepositoryImpl) EventRepository
+bindHeritageRepository(HeritageRepositoryImpl) HeritageRepository
+bindNotificationRepository(NotificationRepositoryImpl) NotificationRepository
}
AuthRepository <|.. AuthRepositoryImpl : "implements"
DataModule --> AuthRepositoryImpl : "binds"
```

**Diagram sources**
- [core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt:7-13](file://core/core-domain/src/main/kotlin/com/uit20years/core/domain/repository/AuthRepository.kt#L7-L13)
- [core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt:20-41](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt#L20-L41)

**Section sources**
- [core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt:1-42](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt#L1-L42)

### Firebase Integration
Firebase services are provided as singletons via Hilt modules. The authentication, Firestore, and storage services are wired into the data layer to support user management and content persistence.

```mermaid
graph LR
FM["FirebaseModule"] --> FA["FirebaseAuth"]
FM --> FF["FirebaseFirestore"]
FM --> FS["FirebaseStorage"]
DM["DataModule"] --> AR["AuthRepositoryImpl"]
AR --> FA
AR --> FF
AR --> FS
```

**Diagram sources**
- [core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt:12-27](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt#L12-L27)
- [core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt:20-41](file://core/core-data/src/main/java/com/uit20years/core/data/di/DataModule.kt#L20-L41)

**Section sources**
- [core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt:1-28](file://core/core-firebase/src/main/java/com/uit20years/core/firebase/di/FirebaseModule.kt#L1-L28)

### UI Foundation and Theming
The UI foundation defines a consistent theme and reusable components. The theme adapts to system dark mode and applies UIT brand colors across surfaces and typography.

```mermaid
flowchart TD
Start(["UIT20YearsTheme"]) --> Detect["Detect dark theme"]
Detect --> Choose{"Dark?"}
Choose --> |Yes| Dark["Apply dark color scheme"]
Choose --> |No| Light["Apply light color scheme"]
Dark --> Apply["Apply Material 3 theme"]
Light --> Apply
Apply --> StatusBar["Set status bar appearance"]
StatusBar --> End(["Render content"])
```

**Diagram sources**
- [core/core-ui/src/main/java/com/uit20years/core/ui/theme/Theme.kt:57-82](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Theme.kt#L57-L82)

**Section sources**
- [core/core-ui/src/main/java/com/uit20years/core/ui/theme/Theme.kt:1-83](file://core/core-ui/src/main/java/com/uit20years/core/ui/theme/Theme.kt#L1-L83)

## Dependency Analysis
The project leverages a version catalog for centralized dependency management and convention plugins for build consistency. The app module depends on all feature modules and the core data module, ensuring a cohesive integration of UI and backend services.

```mermaid
graph TB
V["libs.versions.toml"] --> P["build.gradle.kts"]
P --> APP["app/build.gradle.kts"]
P --> CORE_MODULES["Core modules"]
P --> FEAT_MODULES["Feature modules"]
APP --> FEAT_AUTH
APP --> FEAT_EVENTS
APP --> FEAT_HERITAGE
APP --> FEAT_MOMENTS
APP --> FEAT_NOTIFICATIONS
APP --> FEAT_PROFILE
APP --> CORE_DATA
```

**Diagram sources**
- [gradle/libs.versions.toml:1-103](file://gradle/libs.versions.toml#L1-L103)
- [build.gradle.kts:1-12](file://build.gradle.kts#L1-L12)
- [settings.gradle.kts:20-39](file://settings.gradle.kts#L20-L39)

**Section sources**
- [gradle/libs.versions.toml:1-103](file://gradle/libs.versions.toml#L1-L103)
- [build.gradle.kts:1-12](file://build.gradle.kts#L1-L12)
- [settings.gradle.kts:18-39](file://settings.gradle.kts#L18-L39)

## Performance Considerations
- Compose rendering: Leverage lazy lists and recomposition minimization for feeds and lists.
- Network and disk IO: Offload heavy operations to appropriate dispatchers and avoid blocking the main thread.
- Memory usage: Use image loading libraries efficiently and recycle resources when necessary.
- Offline resilience: Implement caching strategies and optimistic updates for better responsiveness.
- Build performance: Keep KSP and Compose compiler versions aligned with Kotlin to reduce incremental compilation overhead.

## Troubleshooting Guide
Common checks and configurations:
- Build verification: Assemble debug builds and run Hilt KSP tasks to validate DI setup.
- Device/emulator deployment: Install the debug APK to ensure runtime behavior.
- Firebase configuration: Replace the placeholder configuration file with the official Firebase project settings.
- SDK and toolchain: Confirm min SDK, compile SDK, and JVM target align with convention plugin settings.

Verification commands:
- Build check: ./gradlew assembleDebug
- Hilt DI verification: ./gradlew app:kspDebugKotlin
- Run on device/emulator: ./gradlew installDebug

Known configuration notes:
- Kotlin 2.0.21 with Compose compiler plugin.
- KSP 2.0.21-1.0.28 matching Kotlin version.
- Navigation Compose 2.8.5 with type-safe routes.
- Firebase BOM 33.7.0 for consistent Firebase versions.
- DTOs include default parameter values for Firestore compatibility.
- Min SDK 24 / Target SDK 35 enforced by convention plugin.

**Section sources**
- [IMPLEMENTATION_COMPLETE.md:149-170](file://IMPLEMENTATION_COMPLETE.md#L149-L170)
- [build-logic/convention/src/main/kotlin/KotlinAndroid.kt:7-28](file://build-logic/convention/src/main/kotlin/KotlinAndroid.kt#L7-L28)

## Conclusion
UIT20Years delivers a solid foundation for a community-focused social networking platform. The multi-module architecture, clean separation of concerns, and modern Android tooling position the project for rapid iteration and scalable feature delivery. With Firebase integration, Jetpack Compose UI, and Hilt DI, the application is structured to evolve toward a full-featured social platform while maintaining code quality and developer productivity.

## Appendices

### Completion Status and Roadmap
- Status: Implementation complete with scaffolding and core modules fully realized.
- Next steps:
  - Replace placeholder Firebase configuration.
  - Implement remaining repositories for posts, events, heritage, and notifications.
  - Add the home screen with bottom navigation.
  - Implement feature modules for moments, events, heritage, profile, and notifications.
  - Integrate Algolia search.
  - Add unit tests for ViewModels and use cases.

**Section sources**
- [IMPLEMENTATION_COMPLETE.md:132-148](file://IMPLEMENTATION_COMPLETE.md#L132-L148)

### Technology Stack
- Language and framework: Kotlin, Jetpack Compose, Android SDK.
- Architecture and DI: Clean architecture, Hilt dependency injection.
- Backend and cloud: Firebase (Authentication, Firestore, Cloud Storage, FCM).
- UI and UX: Material 3 theming, Compose components.
- Tooling: Gradle with version catalog, convention plugins, KSP, Compose compiler plugin.
- Navigation: Type-safe navigation with kotlinx.serialization.

**Section sources**
- [IMPLEMENTATION_COMPLETE.md:162-170](file://IMPLEMENTATION_COMPLETE.md#L162-L170)
- [gradle/libs.versions.toml:24-91](file://gradle/libs.versions.toml#L24-L91)

### Application Entry Points
- Application class: Initializes Hilt for dependency injection.
- Main activity: Sets up edge-to-edge layout, applies the UIT theme, and hosts the navigation graph.

**Section sources**
- [app/src/main/java/com/uit20years/app/UIT20YearsApplication.kt:4-7](file://app/src/main/java/com/uit20years/app/UIT20YearsApplication.kt#L4-L7)
- [app/src/main/java/com/uit20years/app/MainActivity.kt:14-27](file://app/src/main/java/com/uit20years/app/MainActivity.kt#L14-L27)
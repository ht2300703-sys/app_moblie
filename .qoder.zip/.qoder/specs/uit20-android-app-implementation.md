# UIT20Years Android App — Implementation Plan

## Context

We've designed a comprehensive multi-module Android application for UIT university's 20th anniversary — a social/event management platform. The previous analysis produced architecture diagrams covering Frontend components, Backend services, FE-BE linkage, and user flows.

The project directory (`d:\new_project`) is empty. This plan scaffolds the **entire multi-module project** and **fully implements** all core modules + feature-auth (login/register), providing a solid foundation for all subsequent features.

**Scope**: Core + Auth first. Other features (Moments, Events, Heritage, Profile, Notifications) are included as stub modules.

---

## Tech Stack Summary

| Component | Version |
|---|---|
| Gradle | 8.9 |
| AGP | 8.7.3 |
| Kotlin | 2.0.21 |
| KSP | 2.0.21-1.0.28 |
| Compose BOM | 2024.12.01 |
| Hilt | 2.53.1 |
| Navigation Compose | 2.8.5 |
| Firebase BOM | 33.7.0 |
| Coroutines | 1.9.0 |
| Min SDK | 24 / Target SDK 35 |

---

## Implementation Phases (7 phases, ~121 files)

### Phase 1: Gradle Scaffolding (~23 files)

Build the foundation: root build files, Gradle wrapper, version catalog, and convention plugins.

**Convention plugins** (in `build-logic/convention/`) eliminate build file duplication across 14+ modules:

| Plugin ID | Purpose |
|---|---|
| `uit.android.application` | AGP App + Kotlin Android config |
| `uit.android.library` | AGP Library + Kotlin Android config |
| `uit.android.compose` | Compose compiler plugin + BOM deps |
| `uit.android.hilt` | Hilt plugin + KSP + hilt deps |
| `uit.android.feature` | Composes library+compose+hilt + auto-wires core deps |
| `uit.jvm.library` | Pure Kotlin/JVM modules (no Android) |

**Files:**
```
build.gradle.kts                          # Root: plugin aliases with apply false
settings.gradle.kts                       # includeBuild("build-logic") + all modules
gradle.properties                         # JVM args, nonTransitiveRClass, caching
.gitignore
gradle/libs.versions.toml                 # ALL ~50 deps, ~8 plugins, bundles
gradle/wrapper/gradle-wrapper.properties  # Gradle 8.9
build-logic/settings.gradle.kts
build-logic/convention/build.gradle.kts
build-logic/convention/src/main/kotlin/
  KotlinAndroid.kt                        # Shared helper: configureKotlinAndroid()
  AndroidApplicationConventionPlugin.kt
  AndroidLibraryConventionPlugin.kt
  AndroidComposeConventionPlugin.kt
  AndroidHiltConventionPlugin.kt
  AndroidFeatureConventionPlugin.kt
  JvmLibraryConventionPlugin.kt
```

### Phase 2: Pure Kotlin Modules (~16 files)

No Android dependencies — pure Kotlin/JVM.

**core-common** (`uit.jvm.library`):
```
core/core-common/build.gradle.kts
  result/UitResult.kt              # sealed interface: Success<T>, Error, Loading
  dispatcher/Dispatchers.kt        # @Qualifier annotations: @IoDispatcher, @DefaultDispatcher
  extensions/FlowExt.kt            # Flow<T>.asUitResult(), onSuccess{}, onError{}
  extensions/StringExt.kt          # Email validation
  extensions/DateExt.kt            # Timestamp formatting
  constants/FirestorePaths.kt      # Collection path constants
  constants/AppConstants.kt        # Pagination limits, image sizes
```

**core-model** (`uit.jvm.library`):
```
core/core-model/build.gradle.kts
  User.kt                          # uid, email, displayName, avatarUrl, bio, faculty, graduationYear
  Post.kt                          # id, authorId, content, mediaUrls, likeCount, commentCount
  Comment.kt                       # id, postId, authorId, content
  Event.kt                         # id, title, description, location, startTime, endTime
  Heritage.kt                      # id, title, content, category, year, tags
  Notification.kt                  # id, userId, title, body, type, isRead
  Reaction.kt                      # userId, type: ReactionType
```

### Phase 3: Domain Layer (~12 files)

**core-domain** (`uit.jvm.library`) — depends only on core-model + core-common:
```
core/core-domain/build.gradle.kts
  repository/
    AuthRepository.kt              # login, register, logout, observeAuthState
    UserRepository.kt              # getUser, updateProfile
    PostRepository.kt              # getPosts, createPost, likePost
    EventRepository.kt             # getEvents, registerEvent
    HeritageRepository.kt          # getHeritageItems, searchHeritage
    NotificationRepository.kt      # getNotifications, markAsRead
  usecase/auth/
    LoginUseCase.kt                # invoke(email, password): Flow<UitResult<User>>
    RegisterUseCase.kt             # invoke(email, password, name): Flow<UitResult<User>>
    LogoutUseCase.kt               # invoke(): Flow<UitResult<Unit>>
    ObserveAuthStateUseCase.kt     # invoke(): Flow<User?>
  usecase/GetCurrentUserUseCase.kt
```

### Phase 4: Firebase & Infrastructure (~15 files)

**core-firebase** (`uit.android.library` + `uit.android.hilt`):
```
core/core-firebase/build.gradle.kts
  auth/FirebaseAuthService.kt      # signIn, createUser, signOut, observeAuthState (callbackFlow)
  firestore/FirestoreService.kt    # Generic CRUD + observeDocument/Collection (callbackFlow)
  storage/FirebaseStorageService.kt# upload, delete, getDownloadUrl (suspend)
  fcm/UitMessagingService.kt       # onNewToken, onMessageReceived
  di/FirebaseModule.kt             # @Provides FirebaseAuth, Firestore, Storage instances
```

**core-search** (`uit.android.library` + `uit.android.hilt`):
```
core/core-search/build.gradle.kts
  SearchService.kt                 # interface
  AlgoliaSearchServiceImpl.kt      # Algolia Kotlin client wrapper
  di/SearchModule.kt               # @Binds
```

**core-media** (`uit.android.library` + `uit.android.hilt`):
```
core/core-media/build.gradle.kts
  ImageCompressor.kt               # compress bitmap to ByteArray
  MediaUploader.kt                 # compress + upload to Storage
  di/MediaModule.kt                # @Provides
```

### Phase 5: Data Layer (~13 files)

**core-data** (`uit.android.library` + `uit.android.hilt`):
```
core/core-data/build.gradle.kts
  dto/
    UserDto.kt                     # Firestore document shape, all fields have defaults
    PostDto.kt, CommentDto.kt, EventDto.kt, HeritageDto.kt, NotificationDto.kt
  mapper/
    UserMapper.kt                  # UserDto.toDomain() / User.toDto()
    PostMapper.kt, EventMapper.kt
  repository/
    AuthRepositoryImpl.kt          # FULL: Firebase Auth + Firestore user profile
    UserRepositoryImpl.kt          # FULL: Firestore user CRUD
    PostRepositoryImpl.kt          # STUB (NotImplementedError)
    EventRepositoryImpl.kt         # STUB
    HeritageRepositoryImpl.kt      # STUB
    NotificationRepositoryImpl.kt  # STUB
  di/DataModule.kt                 # @Binds all Repository interfaces → Impls
```

### Phase 6: UI Foundation + Feature Auth (~22 files)

**core-ui** (`uit.android.library` + `uit.android.compose`):
```
core/core-ui/build.gradle.kts
  theme/Color.kt                   # UIT Blue #0066B3, Gold #FFB300
  theme/Type.kt                    # Material 3 typography
  theme/Shape.kt                   # Rounded corners
  theme/Theme.kt                   # UIT20YearsTheme composable
  component/
    UitButton.kt, UitTextField.kt, UitTopBar.kt
    LoadingIndicator.kt, ErrorView.kt, EmptyView.kt
```

**feature-auth** (`uit.android.feature`):
```
feature/feature-auth/build.gradle.kts
  navigation/AuthNavigation.kt     # @Serializable routes + NavGraphBuilder.authGraph()
  login/
    LoginUiState.kt                # data class: email, password, isLoading, errorMessage
    LoginEvent.kt                  # sealed interface: EmailChanged, PasswordChanged, Submit
    LoginViewModel.kt              # @HiltViewModel, StateFlow + onEvent() + side-effect Channel
    LoginScreen.kt                 # Stateless Composable
  register/
    RegisterUiState.kt, RegisterEvent.kt
    RegisterViewModel.kt, RegisterScreen.kt
```

### Phase 7: App Shell + Feature Stubs (~20 files)

**5 stub features** (Moments, Events, Heritage, Profile, Notifications) — each has:
```
feature/feature-{name}/build.gradle.kts
  navigation/{Name}Navigation.kt   # Route + navGraph extension
  {Name}Screen.kt                  # "Coming Soon" placeholder
```

**app module**:
```
app/build.gradle.kts
app/google-services.json            # Placeholder (user replaces)
app/src/main/AndroidManifest.xml
  com/uit20years/app/
    UIT20YearsApplication.kt       # @HiltAndroidApp
    MainActivity.kt                 # @AndroidEntryPoint, setContent { Theme + NavHost }
    navigation/Route.kt             # Top-level route sealed hierarchy
    navigation/AppNavHost.kt        # Wires all feature graphs
    di/DispatcherModule.kt          # @Provides IO/Default/Main dispatchers (Hilt)
```

---

## Key Design Patterns

### UDF (Unidirectional Data Flow) in ViewModels
```
Screen collects StateFlow<UiState> from ViewModel
Screen sends events via onEvent(Event)
ViewModel processes event → calls UseCase → updates StateFlow
One-time effects (navigation) via Channel → receiveAsFlow()
```

### Firebase callbackFlow Pattern
```kotlin
fun observeCollection(path: String): Flow<QuerySnapshot> = callbackFlow {
    val listener = firestore.collection(path)
        .addSnapshotListener { snapshot, error ->
            if (error != null) { close(error); return@addSnapshotListener }
            if (snapshot != null) { trySend(snapshot) }
        }
    awaitClose { listener.remove() }
}
```

### Repository Error Handling
```
Firebase exceptions → UitResult.Error with user-friendly messages
FirebaseAuthInvalidCredentialsException → "Email hoac mat khau khong dung"
FirebaseNetworkException → "Khong co ket noi mang"
```

### DTO Deserialization Safety
All DTOs use default parameter values for Firestore `toObject()` compatibility:
```kotlin
data class UserDto(val uid: String = "", val email: String = "", ...)
```

---

## Module Dependency Rules

```
core-model, core-common     → Pure Kotlin (uit.jvm.library)
core-domain                  → Pure Kotlin, depends on core-model + core-common only
core-data                    → Android, depends on core-domain + core-firebase + core-search + core-media
feature-*                    → Android+Compose, depends on core-domain + core-ui + core-model + core-common
app                          → Depends on ALL feature-* + core-data (for Hilt wiring)
```

---

## Verification

After implementation, verify with:

1. **Build check**: `gradlew assembleDebug` — must compile without errors
2. **Dependency enforcement**: Verify core-model and core-common have ZERO Android imports
3. **Hilt graph**: `gradlew app:kspDebugKotlin` — verifies all DI bindings resolve
4. **Manual test**: Replace `google-services.json` with real file → run on emulator → login/register flow works
5. **Architecture check**: No feature module imports another feature module; no core-domain imports Firebase classes

---

## Known Pitfalls to Watch

| Issue | Mitigation |
|---|---|
| Kotlin 2.0 Compose compiler | Use `org.jetbrains.kotlin.plugin.compose` NOT old `kotlinCompilerExtensionVersion` |
| KSP version must match Kotlin | `2.0.21-1.0.28` matches Kotlin `2.0.21` |
| Hilt missing bindings | `app` must depend on `core-data` to see all `@Binds` modules |
| Firestore DTO no-arg constructor | All DTO fields need default values |
| `google-services.json` missing | Placeholder included; user replaces with real one |
| Navigation type-safe routes | Requires `kotlinx-serialization` plugin on modules with `@Serializable` routes |
| Windows long paths | Package depth is manageable but monitor |

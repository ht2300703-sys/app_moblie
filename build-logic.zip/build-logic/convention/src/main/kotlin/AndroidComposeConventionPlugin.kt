import com.android.build.api.dsl.CommonExtension
import org.gradle.api.Plugin
import org.gradle.api.Project
import org.gradle.kotlin.dsl.apply
import org.gradle.kotlin.dsl.dependencies
import org.gradle.kotlin.dsl.findByType

class AndroidComposeConventionPlugin : Plugin<Project> {
    override fun apply(target: Project) {
        with(target) {
            apply(plugin = "org.jetbrains.kotlin.plugin.compose")

            // Use pluginManager.withPlugin to ensure CommonExtension is registered
            // before we try to configure buildFeatures { compose = true }
            val configureCompose: () -> Unit = {
                val extension = extensions.findByType<CommonExtension<*, *, *, *, *, *>>()
                extension?.buildFeatures {
                    compose = true
                }

                val bom = libs.findLibrary("compose-bom").get()
                dependencies {
                    add("implementation", platform(bom))
                    add("implementation", libs.findBundle("compose").get())
                    add("debugImplementation", libs.findLibrary("compose-ui-tooling").get())
                }
            }

            pluginManager.withPlugin("com.android.application") { configureCompose() }
            pluginManager.withPlugin("com.android.library") { configureCompose() }
        }
    }
}

// Helper extension to access version catalog from convention plugins
internal val Project.libs
    get(): org.gradle.api.artifacts.VersionCatalog =
        extensions.getByType(org.gradle.api.artifacts.VersionCatalogsExtension::class.java).named("libs")
